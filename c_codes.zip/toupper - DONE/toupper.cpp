// Addition of two numbers using two dimensional array
// November 1, 2018  Thursday
// Author: Mr. Jake R. Pomperada,MAED-IT
// www.jakerpomperada.com
// jakerpomperada@gmail.com
// jakerpomperada@jakerpomperada.com
// Product of Bacolod City, Negros Occidental Philippines

#include <iostream>

using namespace std;

int main()
{
	int a[1][1];
	char reply;
	
	int sum=0;
	
do {

	cout <<"\n\n";
	cout << "Addition of Two Numbers Using Two Dimensional Array in C++";
	cout <<"\n\n";
	cout << "Enter first number : ";
	cin >> a[0][0];
	cout <<"Enter second number : ";
	cin >> a[0][1];
	
	sum = (a[0][0]) + (a[0][1]);
	
	cout <<"\n\n";
	cout << "The total sum is " << sum <<".";
	cout <<"\n\n";
	cout <<"Do you want to continue? Y/N : ";
	cin >> reply;
} while(toupper(reply)=='Y');
	cout <<"\n\n";
	cout <<"\tEnd of Program";
	cout <<"\n\n";
}
