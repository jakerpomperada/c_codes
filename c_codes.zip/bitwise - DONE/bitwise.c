/* bitwise.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 19, 2018  Monday 2:38 PM
   Location : Bacolod City, Negros Occidental
   Website  : http://www.jakerpomperada.com
   Emails   : jakerpomperada@jakerpomperada.com
              jakerpomperada@gmail.com
              jakerpomperada@yahoo.com
              jakerpomperada@aol.com
*/

#include <stdio.h>

int main() 
{ 
 int x=0, y=0; 
 printf("\n\n");
 printf("\tBitwise Operators Demonstration");
 printf("\n\n");
 printf("\tGive two integers: ");
 scanf("%d%d",&x,&y);
 printf("\n\n");
 printf("\t%d & %d =  %d\n",x,y,(x & y)); 
 printf("\t%d | %d = %d\n",x,y,(x | y)); 
 printf("\t%d ^ %d = %d\n",x,y,(x ^ y));
 printf("\t~%d = %d\n",x,~x); 
 printf("\t%d << %d = %d\n",x,2,(x << 2));
 printf("\t%d >> %d = %d\n",x,2,(x >> 2));
 printf("\n\n");
 printf("\tEnd of Program");
 printf("\n\n");
}


