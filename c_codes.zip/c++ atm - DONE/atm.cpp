#include <iostream>

// Created By Mr. Jake R. Pomperada, MAED-IT
// C++   October 19, 2018
// www.jakerpomperada.com

using namespace std;


int main()

{
		int bill500=0, bill200=0, bill100=0, total_balance=0;
		int withdraw=0, money_left=0;
		int reciv500=0, reciv200=0, reciv100=0;
		char withdraw_again[2] = "N";
		 
		 system("COLOR F0");  
	     cout <<"\n\n";
         cout <<"\t Automatic Teller Machine Simulation in C++";
		 cout <<"\n\n";
		 cout <<"\tHow many P500 bills: ";
		 cin >>bill500;
		 cout <<"\tHow many PHP 200 bills: ";
		 cin >>bill200;
		 cout <<"\tHow many PHP 100 bills: ";
		 cin >> bill100;
		 total_balance = 	(bill500 * 500 + (bill200 * 200 +  (bill100 * 100)) );

		 cout <<"\tTotal Balance: PHP :" << total_balance;

	 do

	 {
		 cout <<"\n";
		 cout <<"\n";

		 cout <<"\tEnter amount to withdraw: PHP ";
		 cin >>withdraw;
		 money_left = withdraw ;

		 if  (withdraw > total_balance)
				{
				cout <<"\tWithdraw amount greater than total balance.  ";
				cout <<"\n";
				}
		 if (withdraw < total_balance)
		 {
		 if  (money_left >= 500) 
				{
				 reciv500 = int(money_left / 500);
				 if (reciv500 > bill500)  reciv500 = bill500;

				 money_left = money_left - (reciv500 * 500);
				 bill500 = bill500 - reciv500;
				}

		 if (money_left >= 200) 
			 {
				 reciv200 = int(money_left / 200);
				 if (reciv200 > bill200)  reciv200 = bill200;
				 money_left = money_left - (reciv200 * 200);
				 bill200 = bill200 - reciv200;
			 }

		 if (money_left >= 100) 
			  {
				 reciv100 = int(money_left / 100);
				 if (reciv100 > bill100)  reciv100 = bill100;
				 money_left = money_left - (reciv100 * 100);
				 bill100 = bill100 - reciv100;
				}

				cout <<"\n";
				cout <<"\n";
				cout <<"\tYou will receive:";
				cout <<"\n";
				cout <<"\t  PHP 500 bill : " << reciv500;
				cout <<"\n";
				cout <<"\t  PHP 200 bill : " << reciv200;
				cout <<"\n";
				cout <<"\t  PHP 100 bill : " << reciv100;
				cout <<"\n";


				total_balance = total_balance - withdraw;

				cout <<"\tYour current balance is: PHP " <<total_balance;
				cout <<"\n";
				cout <<"\n";
				cout <<"\tYou only have balance of:";
				cout <<"\n";
				cout <<"\t PHP 500 bill   : "  << bill500;
				cout <<"\n";
				cout <<"\t  PHP 200 bill  : " << bill200;
				cout <<"\n";
				cout <<"\t  PHP 100 bill  : " << bill100;
				cout <<"\n"; 
 				cout <<"\n\n";
				cout <<"\tAnother Withdraw Again ? Y/N : ";
				cin >>withdraw_again;

		 }

	 }  while (withdraw_again == "Y" || withdraw_again == "y");
     cout <<"\n\n";
     cout <<"\tEnd of Program";
     cout <<"\n\n";
}

