/* global_local.c
  Local Variable Program
  Author   : Kristine Trogani Soberano,Ph.D.
  Faculty, Northern Negros State College of Science and Technology
  Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
  Email    : missKsoberano@gmail.com
  Tool     : Dev C++ Version 5.11
  Date    : November 19, 2018   Monday  7:07 AM
*/

#include <stdio.h>

// Global variable declaration
int a = 100;

int main()
{
     // Local variable declaration
    printf("\n\n");
    int a = 50;
    printf("\tThe value is %d.",a);
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
    return 0;
}

