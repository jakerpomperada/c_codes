/* odd_even.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 26, 2018  Monday  9:07 AM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/
#include<stdio.h>
int main()
{
   int num=0;
   int *ptr;
   printf("\n\n");
   printf("\tOdd and Even Number Checker");
   printf("\n\n");
   printf("\tEnter a Number : ");
   scanf("%d",&num);
   ptr = &num; 
  if (*ptr%2==0) {
  	     printf("\n");
         printf("\tThe given number %d is an EVEN number.",num);
     }
    else {
    	 printf("\n");
	     printf("\tThe given number %d is an ODD number.",num);
   }
  printf("\n\n");
  printf("\tEND OF PROGRAM");
  printf("\n\n");
}

