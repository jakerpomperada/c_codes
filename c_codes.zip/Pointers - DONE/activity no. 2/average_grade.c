/* average_grade.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 26, 2018  Monday  9:07 AM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/
#include <stdio.h>
int main()
{
 float solve_average=0.00;
 float prelim=0.00,midterm=0.00,final=0.00;
 float *prelim_p, *midterm_p, *final_p;
 
 printf("\n\n");
 printf("\tAverage Grade Solver");
 printf("\n\n");
 printf("\tGive Prelim Grade   : ");
 scanf("%f",&prelim);
 printf("\tGive Midterm Grade  : ");
 scanf("%f",&midterm);
 printf("\tGive Final Grade    : ");
 scanf("%f",&final);
  
 prelim_p = &prelim;
 midterm_p = &midterm;
 final_p = &final;
  
solve_average =(*prelim_p+*midterm_p+*final_p)/3;
 
printf("\n\n");
printf("\t===== DISPLAY RESULTS =====");
printf("\n\n");
printf("\tThe student average grade is %.2f.",solve_average);
printf("\n\n");
printf("\tEND OF PROGRAM");
printf("\n\n");
}
