/*highest.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 26, 2018  Monday 2:31 PM
*/
#include<stdio.h>
int main()
{
  int x=0, y=0, z=0;
  int *a, *b, *c;
  
  printf("\n\n");
  printf("\tLargest of Three Numbers");
  printf("\n\n");
  printf("\tEnter Three Numbers : ");
  scanf("%d%d%d",&x, &y, &z);
  a = &x;
  b = &y;
  c = &z;
  if(*a > *b)
  {
    if(*a > *c)
    {
      printf("\n\n");
	  printf("\t%d is larger than %d and %d.", *a, *b, *c);
    }
    else
    {
      printf("\n\n");
	  printf("\t%d is larger than %d and %d.", *c, *a, *b);
    }
  } 
  else
  {
     if(*b > *c)
     {
        printf("\n\n");
		printf("\t%d is larger than %d and %d.", *b, *a, *c);
     }
     else
     {
        printf("\n\n");
		printf("\t%d is larger than %d and %d", *c, *a, *b);
     }
  }
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
} 
