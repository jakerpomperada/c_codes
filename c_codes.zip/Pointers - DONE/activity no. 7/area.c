/* area_circle.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 26, 2018  Monday  2:19 PM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/

#include<stdio.h>

void solve_area( int r, float *a, float *p )
{
*a = 3.14 * r * r ;
*p = 2 * 3.14 * r ;
}

int main( )
{
int radius=0;
float area=0.00, perimeter=0.00 ;

printf("\n\n");
printf("\tArea of the Circle");
printf("\n\n");
printf ("\tEnter Radius of a Circle : " ) ;
scanf ( "%d", &radius ) ;

solve_area(radius, &area, &perimeter ) ;

printf("\n\n");
printf("\t===== DISPLAY REPORT =====");
printf("\n\n");
printf ( "\tThe Area = %.2f.", area ) ;
printf ( "\tThe Perimeter = %.2f.", perimeter ) ;
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
}
