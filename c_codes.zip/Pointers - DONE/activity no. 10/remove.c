/*highest.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 26, 2018  Monday 2:57 PM
*/
#include<stdio.h>
#include<string.h>
 
int main() {
    char arr1[100], temp[100], c;
    char *ptr;
    int count=0, j = 0;
    printf("\n\n");
  	printf("\tRemove Vowels in a String");
  	printf("\n\n");
    printf("\tEnter A String : ");
    gets(arr1);
    ptr = arr1;
    for(count = 0;count < strlen(ptr);count++) {
        c = ptr[count];
        if(c != 'a' && c != 'e' && c != 'i' && c != 'o' && c != 'u' && c != 'A' && c != 'E' && c != 'I' && c != 'O' && c != 'U') {
            temp[j] = c;
            j++;
        }
    }
    printf("\n\n");
    printf("\tOriginal String:");
    printf("\n\n");
    printf("\t%s",arr1);
    printf("\n\n");
    printf("\tAfter Eliminating Vowels From String:");
    printf("\n\n\n");
    printf("\t");
    for(count = 0;count < j;count++) {
	
         printf("%c",temp[count]);
    }
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}
