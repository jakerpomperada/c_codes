/*palindrome.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 26, 2018  Monday 9:50 AM 
*/
#include <stdio.h>
 
void stringUpr(char *s);
void stringLwr(char *s);
 
int main()
{
char string[100];
char *ptr,*rev;
printf("\n\n");
printf("\tPalindrome Program ");
printf("\n\n");
printf("\tGive a String : ");
gets(string);
ptr=string;
stringUpr(ptr);
   while(*ptr!=NULL){
      ++ptr;
       }
      --ptr;
for(rev=string; ptr>=rev;){
   if(*ptr == *rev)
       {
        --ptr;
        rev++;
      }
    else
	break;
    }

if(rev>ptr) {
	printf("\n\n");
	stringUpr(string);
    printf("\tThe given string %s is Palindrome.",string);
     }
 else {
 	  printf("\n\n");
 	  stringUpr(string);
      printf("\tThe given string %s is Not a Palindrome.",string);
}
  printf("\n\n");
  printf("\tEND OF PROGRAM");
  printf("\n\n");
}

void stringLwr(char *s)
{
    int i=0;
    while(s[i]!='\0')
    {
        if(s[i]>='A' && s[i]<='Z'){
            s[i]=s[i]+32;
        }
        ++i;
    }
}
 
void stringUpr(char *s)
{
    int i=0;
    while(s[i]!='\0')
    {
        if(s[i]>='a' && s[i]<='z'){
            s[i]=s[i]-32;
        }
        ++i;
    }
    
}
