/* swap.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 26, 2018  Monday  3:09 PM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/
#include <stdio.h>

void swap(int *num1, int *num2);

int main()
{
    int num1=0, num2=0;
    printf("\n\n");
  	printf("\tSwap Two Numbers");
  	printf("\n\n");
    printf("\tEnter Two Numbers : ");
    scanf("%d%d", &num1, &num2);
    printf("\n\n");
    printf("\tBefore swapping in main");
    printf("\n\n");
    printf("\tValue of num1 = %d \n", num1);
    printf("\tValue of num2 = %d \n\n", num2);
    swap(&num1, &num2);
    printf("\n");
    printf("\tEnd of Program");
    printf("\n\n");
  
}

void swap(int * num1, int * num2)
{
    int temp;
    temp = *num1;
    *num1= *num2;
    *num2= temp;

    printf("\tAfter swapping in swap function ");
    printf("\n\n");
    printf("\tValue of num1 = %d. \n", *num1);
    printf("\tValue of num2 = %d. \n\n", *num2);
}
