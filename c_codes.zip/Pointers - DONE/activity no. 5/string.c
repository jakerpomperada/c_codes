/* consonants_vowels.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 26, 2018  Monday  11:22 AM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/
#include <stdio.h>
int main()
{
    char str[100];
    char *ptr;
    int  cntV,cntC;
    printf("\n\n");
	printf("\tCount Vowels and Consonants");
	printf("\n\n");
    printf("\tGive a String: ");
    gets(str);
    ptr=str;
    cntV=cntC=0;
    while(*ptr!='\0')
    {
        if(*ptr=='A' ||*ptr=='E' ||*ptr=='I' ||*ptr=='O' 
		||*ptr=='U' ||*ptr=='a' ||*ptr=='e' ||*ptr=='i' 
		||*ptr=='o' ||*ptr=='u')
            cntV++;
        else
            cntC++; 
        ptr++;
    }
    printf("\n\n");
    printf("\t===== DISPLAY REPORT =====");
    printf("\n\n");
    printf("\tTotal number of VOWELS: %d, CONSONANT: %d\n",cntV,cntC);        
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}
