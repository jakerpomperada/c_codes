/* add_subtract.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 27, 2018  Monday  9:21 PM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/
#include <stdio.h>
 
int main()
{
   int first=0, second=0;; 
   int *a,*b;
   int sum=0;
   int difference=0;
   printf("\n\n");
   printf("\tSum and Difference of Two Numbers");
   printf("\n\n");
   printf("\tGive Two Numbers : ");
   scanf("%d%d",&first,&second);
   a = &first;
   b = &second;
  sum = (*a + *b);
  difference = (*a - *b);
  printf("\n\n");
  printf("\t===== DISPLAY RESULTS =====");
  printf("\n\n");
  printf("\tThe sum of %d and %d is %d."
          ,first,second,sum);
  printf("\n\n");   
  printf("\tThe difference between %d and %d is %d."
          ,first,second,difference);     
  printf("\n\n");
  printf("\tEND OF PROGRAM");
  printf("\n\n");
 }
