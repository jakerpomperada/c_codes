/*word_count.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 26, 2018   Friday 1:22 PM
*/

#include <stdio.h>
int main()
{
char str[200],*ptr;
int a=1;
printf("\n\n");
printf("\tCount Words in a String");
printf("\n\n");
printf("\tGive a String : ");
gets(str);
ptr=str;
for(;*ptr!='\0';ptr++)
{
if(*ptr==' ')
a+=1;
}
printf("\n\n");
printf("\t===== DISPLAY REPORT =====");
printf("\n\n");
printf("\tTotal Numbers of Words : %d.",a);
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
}

