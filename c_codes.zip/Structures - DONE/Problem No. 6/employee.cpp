/*employee_info.c
 Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
 Date      : December 1, 2018  Saturday 9:49 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define CLEARBUF() {char ch1; if(!feof(stdin)){ ch1=getc(stdin);}}

struct employee {
    char name[100],work[100];
    int age;
    char gender;
    float salary;
};

main() {

    employee person;
    char reply;

do {
    printf("\n\n");
    printf("\t\t Employees Information System Version 1.0");
    printf("\n\n");
    CLEARBUF();
    printf("\tEmployees Name     : ");
    gets(person.name);
    printf("\tEmployees Work     : ");
    gets(person.work);
    CLEARBUF();
    printf("\tEmployees Age      : ");
    scanf("%d",&person.age);
    CLEARBUF();
    printf("\tEmployees Gender   : ");
    scanf("%c",&person.gender); 
    printf("\tEmployees Salary   : PHP ");
    scanf("%f",&person.salary);
    printf("\n\n");
    printf("\t\t Summary of Report");
    printf("\n\n");
    printf("\n\tName        : %s ",person.name);
    printf("\n\tWork        : %s ",person.work);
    printf("\n\tAge         : %d ",person.age);
    printf("\n\tGender      : %c ",person.gender);
    printf("\n\tSalary      : PHP %.2f " ,person.salary);
    printf("\n\n");
    printf("\tDo you want to continue y/n : ");
    scanf("%s",&reply);
    if (toupper(reply) == 'N') {
        printf("\n\n");
        printf("\t\t Thank You For Using This Software !!!");
        break;
    }
    } while (toupper(reply!='Y'));
    printf("\n\n");
    system("pause");
}
