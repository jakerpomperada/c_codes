/*add.c
 Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
 Date      : December 1, 2018  Saturday 7:41 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

struct add {
  int value1,value2;
    int addition()
    {
        return(value1+value2);
    }
};

int main() {
    add math;
    char reply;
do {
    printf("\n\n");
    printf("\t\tAddition of Two Numbers");
    printf("\n\n");
    printf("\tEnter the first value  : ");
    scanf("%d",&math.value1);
    printf("\n");
    printf("\tEnter the second value : ");
    scanf("%d",&math.value2);
    printf("\n\n");
    printf("\tThe sum of %d and %d is %d."
	,math.value1,math.value2, math.addition());
	printf("\n\n");
    printf("\tDo you want to continue y/n? : ");
    scanf("%s",&reply);
    if (toupper(reply) == 'N') {
     printf("\n\n");
     printf("\tThank You For Using This Software !!!");
     break;
    }
    } while (toupper(reply!='Y'));
    printf("\n\n");
	printf("\t\tEnd of Program");
	printf("\n\n");
	system("pause");
}






