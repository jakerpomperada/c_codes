/*demo.c
 Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
 Date      : December 1, 2018  Saturday 11:55 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct employee {
  char employees_name[200];
  char position[200];
  int id_number;
  float salary;
};

int main(){
	struct employee person;
	printf("\n\n");
	printf("\tStructure Demonstration in C");
    person.id_number =12345;
    strcpy(person.employees_name,"Jake Rodriguez Pomperada");
    strcpy(person.position,"Software Quality Assurance Engineer");
    person.salary = 75650.50;
    printf("\n\n");
    printf("\t===== DISPLAY RESULTS =====");
    printf("\n\n");
    printf("\tEMPLOYEE'S ID NUMBER  :  %d ",person.id_number);
    printf("\n");
    printf("\tEMPLOYEE'S NAME       :  %s ",person.employees_name);
    printf("\n");
    printf("\tEMPLOYEE'S POSITION   :  %s ",person.position);
    printf("\n");
    printf("\tEMPLOYEE'S SALARY     :  PHP %.2f",person.salary);
    printf("\n\n");
    printf("\tThank you for Using This Software.");
    printf("\n\n");
    system("PAUSE");
}
    
    
