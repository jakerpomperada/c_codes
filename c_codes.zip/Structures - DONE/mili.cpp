Snippet




      /********************************************************
   3.
      Program: military time.cpp
   4.
      Programmer: Gloria Silva (gjs@drexel.edu)
   5.
      Last Modified: 10/30/06
   6.
      Purpose: This program asks the user for the military time
   7.
                  and convert it to twelve hour notation
   8.
      *********************************************************/

      #include <iostream>

      using namespace std;



      void input ( int & hours,char & colon, int  & minutes);

      void calculation ( int & hours, int & reg_hours, char & ampm);

      void output(int & reg_hours, char & colon, int  & minutes, char & ampm);

      void  main ()
       {

           int hours, minutes, reg_hours;

           char ampm, colon, ans='y';
            do{

      //--call the input function which asks the user to input the military time----

                input( hours, colon, minutes);

      //--call the calculation function which converts the military time to time in twelve hour notation---

                calculation( hours, reg_hours, ampm);

      //--call the output function which display the time in twelve hour notation--



                output ( reg_hours, colon, minutes,  ampm);


                cout<<"\nWould you like to check it again?\n"
                      <<"\nDo you want to go again?(Y/N):\n";

                cin>>ans;



           }while (ans=='y'|| ans=='Y');



           cout<<"\nGood-bye"<<endl;





      }



      void input (int & hours, char & colon, int  & minutes)

      {

      // --------- read in military time -------



           cout<<"\nEnter the time using the following format(hour:minutes)";

           cin>>hours>>colon>>minutes;

      }



      //----------calculates the time convertion----------------

      void calculation(int &hours, int & reg_hours, char & ampm)

      {

           if ((hours>0)&&(hours<=11))

           {

                reg_hours= hours;

                ampm='A';

           }

           if ((hours>=13)&&(hours<=23))

           {
            reg_hours=hours-12;

                ampm='P';

           }



           if((hours>=0)&&(hours<1))

           {

                reg_hours=12;

                ampm= 'A';

           }

           if (hours==12)

           {

                reg_hours=12;
  69.
                ampm='P';
        }



      }


     void output(int & reg_hours, char & colon, int & minutes, char & ampm)

      {

      // --------- prints out the time in twelve hour notation -------

      cout<<"\nThe time in twelve hour notation is: " <<reg_hours<<colon<<minutes<<ampm<<"M"<<endl;

      }

      // --------- end program ------





