/*employees.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : December 1, 2018  Saturday 6:08 PM
*/
#include <stdio.h>
#include <stdlib.h>

#define CLEARBUF() {char ch1; if(!feof(stdin)){ ch1=getc(stdin);}}

struct contact_details    // structure tag
{
    char address[200];
	int telephone;
    int mobile;
    char email[200];
};
struct emp             /* structure tag */
{
	int empno;
	char name[200];
	char position[200];
	contact_details user;
	/* See, user is a structure variable itself (of type
      contact_details) and it is member of another structure,
   the emp structure. */
	double basic;
};
int main()
{
	emp user_details;   /* create structure variable */
	printf("\n\n");
	printf("\tNested Structure Demonstration in C");
	printf("\n\n");
	printf("\tEmployee Number  : ");
	scanf("%d",&user_details.empno);
	CLEARBUF();
	printf("\tEmployee Name    : ");
	gets(user_details.name); 
	printf("\tPosition         : ");
	gets(user_details.position); 
	printf("\tBasic Salary     : PHP ");
	scanf("%lf",&user_details.basic);
	CLEARBUF();
	printf("\tHome Address     : ");
	gets(user_details.user.address);
	printf("\tEmail Address    : ");
	gets(user_details.user.email); 
	printf("\tTelephone Number : ");
	scanf("%d",&user_details.user.telephone);
    printf("\tMobile Number    : ");
	scanf("%d",&user_details.user.mobile);
	printf("\n\n");
	printf("\tEMPLOYEE DISPLAY RECORD");
    printf("\n\n");
	printf("\n\tEmployee Number     : %d ",user_details.empno);
    printf("\n\tEmployee Name       : %s ",user_details.name);
	printf("\n\tPosition            : %s ",user_details.position);
	printf("\n\tHome Address        : %s ",user_details.user.address);
    printf("\n\tEmail Address       : %s ",user_details.user.email);
	printf("\n\tTelephone Number    : %d ",user_details.user.telephone);
	printf("\n\tMobile Number       : %d ",user_details.user.mobile);
	printf("\n\tBasic Salary Pay    : PHP %.2lf",user_details.basic);
    printf("\n\n");
	printf("\tThank you for Using This Software.");
	printf("\n\n");
    system("pause");
}
