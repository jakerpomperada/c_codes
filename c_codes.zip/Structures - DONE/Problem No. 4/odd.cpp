// odd.cpp
// Author    : Mr. Jake R. Pomperada, BSCS,MAED-IT
// Date      : September 4, 2018   Tuesday  9:56 AM
// Location  : Bacolod City, Negros Occidental Philippines.
// Website   : http://www.jakerpomperada.com
// Email     : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
// Tool      : Dev C++ Version 5.11

#include <iostream>
#include <iomanip>

using namespace std;

struct odd {

int n;

  int odd_even() {

  if (n % 2 == 0)
        {
        cout <<"\t"<<n<<" Number is EVEN!\n";
        }
        else
        {
        cout <<"\t"<<n<< " Number is ODD!\n";
        }
   return(n);

  }

};

main() {
   odd value;
   system("COLOR F0"); 
   cout <<"\n\n";
   cout << "\t\t ODD and Even Number Determiner";
   cout << "\n\n";
   cout << "\tEnter a Number : ";
   cin >> value.n;
   cout << "\n\n";
   value.odd_even();
   cout << "\n\n";
   system("pause");
}


