/*cube.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : December 1, 2018  Saturday 9:03 PM
*/
#include <stdio.h>
#include <stdlib.h>
struct cube{
  int value;

  int solve()
    {
        return(value * value * value);
    }
  };

  main() {
      cube val;
      printf("\n\n");
	  printf("\t\tCube Root Solver 1.0");
	  printf("\n\n");
      printf("\tEnter a Number : ");
      scanf("%d",&val.value);
      printf("\n");
      printf("\tThe Cube Root Value of %d is %d. ",val.value,val.solve());
      printf("\n\n");
	  printf("\t\tEnd of Program");
	  printf("\n\n");
      system("pause");
  }


