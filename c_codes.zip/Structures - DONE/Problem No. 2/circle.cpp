/*circle.c
 Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
 Date      : December 1, 2018  Saturday 9:01 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

struct circle {
  char name[100];
  float radius;
  float area;
};

int main() {
    circle test;
    char reply;
    float area=0.00;
do {
    printf("\n\n");
    printf("\t\tArea of the Circle Version 1.0");
    printf("\n\n");
    printf("\tEnter the name of the Circle          : ");
    gets(test.name);
    printf("\n");
    printf("\tEnter the given Radius of the Circle  : ");
    scanf("%f",&test.radius);
    printf("\n");
    printf("\t\tSummary of Report");
    printf("\n");
    area = (3.14 * test.radius * test.radius);
    printf("\n\tName of the Circle         : %s ",test.name);
    printf("\n");
    printf("\n\tThe Area of the Circle is  : %.2f ",area);
    printf("\n\n");
    printf("\tDo You Want to Continue y/n? : ");
    scanf("%s",&reply);
    if (toupper(reply) == 'N') {
        printf("\n\n");
        printf("\t\t Thank You For Using This Software !!!");
        break;
    }
    } while (toupper(reply!='Y'));
    printf("\n\n");
    system("pause");
}
