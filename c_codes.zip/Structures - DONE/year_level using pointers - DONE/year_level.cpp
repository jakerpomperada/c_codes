/*leap_year.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : December 1, 2018  Saturday 12:30 PM
*/
#include <stdio.h>
#include <stdlib.h>
struct check_year_level {
   int year_level;
}; 

int  main()
{
check_year_level *ptr,a;
ptr = &a;
printf("\n\n"); 
printf("\tYear Level Checker Using Structure and Pointers in C");
printf("\n\n"); 
printf("\tEnter Year Level : ");
scanf("%d",&(*ptr).year_level);
printf("\n\n"); 
if ( (*ptr).year_level== 1) {
  printf("\tYou are belong to Freshmen.");
}
else if ((*ptr).year_level == 2) {
  printf("You are belong to Sophomore.");
}
else if ((*ptr).year_level == 3) {
  printf("\tYou are belong to Juniors.");
}
else if ((*ptr).year_level == 4)
  {
  printf("\tYou are belong to Seniors.");
}
else {
 printf("\tInvalid Option Try Again");
}
printf("\n\n");
printf("\tThank you for Using This Software.");
printf("\n\n");
system("pause");
}

