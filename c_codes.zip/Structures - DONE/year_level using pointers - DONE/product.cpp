#include <iostream>
using namespace std;

struct product
{
  int a,b;
};

int main()
{
    product *ptr,val;
    int product=0;
    
	ptr = &val;
    
    cout <<"\n\n";   
    cout <<"Product of Two Numbers Using Pointers and Structures";
    cout <<"\n\n";
    cout << "Give First Value  : ";
	cin >> (*ptr).a;
    cout << "Give Second Value : ";
    cin >> (*ptr).b;
 
    product = (*ptr).a * (*ptr).b;
    cout <<"\n\n";
    cout <<"\tThe product of " << (*ptr).a
         << " and " <<(*ptr).b << " is" 
         << product <<".";
    cout <<"\n";
    return 0;
}
