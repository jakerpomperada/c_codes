/*grade.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : December 1, 2018  Saturday 9:14 PM
*/
#include <stdio.h>
#include <stdlib.h>
struct student {
    char name[200];
    int age;
    float prelim,midterm,endterm;
};
float compute_grade(float *prelim,
                   float *midterm,
                   float *endterm)
{
  float solve=0.00;
  char *remarks[100]={"PASSED","FAILED"};
  char *display;
  
  solve = (*prelim * 0.30) +
          (*midterm * 0.30) +
          (*endterm * 0.40);

 if (solve >= 75.00)  {
     display = remarks[0];
 }
 else {
     display = remarks[1];
 }
 printf("\n\n\tThe student grade is %.2f \tRemarks: %s",solve,display);
 return(solve);
}

 int main() {
     student user;
     float *mypointer;
     printf("\n\n");
     printf("\t\tSimple Grade Solver 1.0");
     printf("\n\n");
     printf("\tEnter the Name of the Student : ");
     gets(user.name);
     printf("\n");
     printf("\tEnter the Age of the Student  : ");
     scanf("%d",&user.age);
     printf("\n");
     printf("\tEnter the Prelim Grade : ");
     scanf("%f",&user.prelim);
     mypointer = &user.prelim;
     printf("\n");
     printf("\tEnter the Midterm Grade : ");
     scanf("%f",&user.midterm);
     mypointer = &user.midterm;
     printf("\n");
     printf("\tEnter the Endterm Grade : ");
     scanf("%f",&user.endterm);
	 mypointer = &user.endterm;
     printf("\n\n");
     printf("\t ===== GENERATED REPORT =====");
     printf("\n\n");
     printf("\n\tStudent Name : %s ",user.name);
     printf("\n\tStudent Age  : %d ",user.age);
     compute_grade(&user.prelim,&user.midterm,&user.endterm);
     printf("\n\n");
     system("pause");
 }




