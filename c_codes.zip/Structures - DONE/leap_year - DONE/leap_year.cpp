/*leap_year.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : December 1, 2018  Saturday 12:22 PM
*/
#include <stdio.h>
#include <stdlib.h>

struct leap_year {
    int year;
};

int main()
{
struct leap_year years;
printf("\n\n");
printf("\tLeap Year Checker Using Structure in C");
printf("\n\n");
printf("\tGive a Year : ");
scanf("%d",&years.year);
printf("\n\n");

if(years.year%4==0)
{
if(years.year%100==0)
{
if(years.year%400==0)
printf("\tThe Given Year %d is a Leap Year. ",years.year);
else
printf("\tThe Given Year %d is Not a Leap Year. ",years.year);
}
else
printf("\tThe Given Year %d is a Leap Year. ",years.year);
}
else {
printf("\tThe Given Year %d is Not a Leap Year. ",years.year);
}
printf("\n\n");
printf("\tThank you for Using This Software.");
printf("\n\n");
system("PAUSE");
}





