/* legal_age.c
  Enum Example Program
  Author   : Kristine Trogani Soberano,Ph.D.
  Faculty, Northern Negros State College of Science and Technology
  Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
  Email    : missKsoberano@gmail.com
  Tool     : Dev C++ Version 5.11
  Date    : November 19, 2018   Monday  10:57 AM
*/

#include <stdio.h>

   int main() {
   		int age=0;
        
		printf("\n\n");
        printf("\tLegal Age Checker");
        printf("\n\n");
        printf("\tWhat is your Age? : ");
        scanf("%d",&age);
        
        if (age>=18) {
            printf("\n\n");
            printf("\tYou are %d Years Old.\n\n",age);
            printf("\tYour are already an Adult.");
            printf("\n\n");
        } 
 		else {
  			printf("\n\n");
            printf("\tYou are %d Years Old.\n\n",age);
            printf("\tSorry you are still a Minor.");
            printf("\n\n");
     }
     printf("\n\n");
     printf("\tEnd of Program");
     printf("\n\n");
}
