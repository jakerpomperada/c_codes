/* escape_sequence.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 19, 2018   6:59 AM
   Location : Bacolod City, Negros Occidental
   Website  : http://www.jakerpomperada.com
   Emails   : jakerpomperada@jakerpomperada.com
              jakerpomperada@gmail.com
              jakerpomperada@yahoo.com
              jakerpomperada@aol.com
*/

#include <stdio.h>
 
int main()
{
printf("\n\tThis\n\tis\n\ta\n\ttest\n\tonly.\n\n\tJake said, \"How are you Julianna?\"");
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
}

