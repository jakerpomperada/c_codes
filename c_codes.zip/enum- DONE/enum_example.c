/* enum_example.c
  Enum Example Program
  Author   : Kristine Trogani Soberano,Ph.D.
  Faculty, Northern Negros State College of Science and Technology
  Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
  Email    : missKsoberano@gmail.com
  Tool     : Dev C++ Version 5.11
  Date    : November 19, 2018   Monday  10:25 AM
*/

#include <stdio.h>

int main()
{
	enum MONTH {Jan=0,Feb,Mar};
	enum MONTH month = Mar;
	
	 printf("\n\n");
     printf("\tEnum Program Demonstration");
     printf("\n\n");

  	if (month == 0) {
		printf("\tValue of January.");
	} else if (month == 1) {
		printf("\tMonth is February.");
	}
	if (month == 2) {
		printf("\tMonth is March.");
	}
	 printf("\n\n");
     printf("\tEnd of Program");
     printf("\n\n");
}
