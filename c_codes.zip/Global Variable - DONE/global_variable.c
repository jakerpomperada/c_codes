/* global_variable.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 19, 2018   6:59 AM
   Location : Bacolod City, Negros Occidental
   Website  : http://www.jakerpomperada.com
   Emails   : jakerpomperada@jakerpomperada.com
              jakerpomperada@gmail.com
              jakerpomperada@yahoo.com
              jakerpomperada@aol.com
*/


#include <stdio.h>

// Global variable declaration.
int sum=0;

int main()
{
     // Local variable declaration.
     int a=0, b=0;
    // Actual variable initialization.
    a = 5;
    b = 10;
    sum = (a + b);
    printf("\n\n");
    printf("\tGlobal Variable Declaration Program");
    printf("\n\n");
    printf("\tThe sum of %d and %d is %d.",a,b,sum);
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
   return 0;
}

