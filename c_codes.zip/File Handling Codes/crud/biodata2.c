/*student_grading.c
 Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
 Date      : December 2, 2018  Sunday 1:27 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>

int main( )
{
	FILE  *fp, *ft ;
	char  another, choice ;
	struct student
	{
		char  name[100];
		char  course[100];
		char  sex;
		int   age;
		char  address[100];
		char  email[100];
		char  subject[100];
		float prelim,midterm,endterm,final_grade;
	} ;
	struct student info ;
	char student_name[100];
	long int  recsize ;

	fp = fopen ( "BIODATA.DAT", "rb+" ) ;

	if ( fp == NULL )
	{
		fp = fopen ( "BIODATA.DAT", "wb+" ) ;

		if ( fp == NULL )
		{
			puts ( "Cannot open file" ) ;
			exit(0) ;
		}
	}

	recsize = sizeof ( info ) ;

	while ( 1 )
	{
        system("CLS");
        printf("\n");
        printf("\n\t========================================");
        printf("\n\t STUDENT INFORMATION AND GRADING SYSTEM ");
        printf("\n\t========================================");
		printf("\n\n");
		printf ( "\t1. ADD STUDENT RECORDS" ) ;
		printf("\n");
		printf ( "\t2. DISPLAY STUDENT RECORDS" ) ;
	    printf("\n");
		printf ( "\t3. UPDATE STUDENT RECORDS" ) ;
		printf("\n");
		printf ( "\t4. DELETE STUDENT RECORDS" ) ;
		printf("\n");
		printf ( "\t5. QUIT PROGRAM" ) ;
	    printf("\n\n");
		printf ( "\tSELECT YOUR CHOICE : " ) ;
		fflush ( stdin ) ;
		choice = getche( ) ;
		switch ( choice )
		{
			case '1' :

				fseek ( fp, 0 , SEEK_END ) ;
				another = 'Y' ;

				while ( another == 'Y' )
				{
					system("cls");
					printf("\n\n");
                    printf("=== Add New Student Record in the Database ===");
                    printf("\n\n");
					printf("Enter Student Name           : ");
					scanf("%s",&info.name);
					printf("Enter Course                 : ");
					scanf("%s",&info.course);
				    printf("Enter Gender M/F             : ") ;
                    info.sex = toupper(getche());
                    printf("\n");
                    printf("Enter Age                    : ") ;
                    scanf("%d",&info.age);
                    printf("Enter Home Address           : ");
					scanf("%s",&info.address);
					printf("Enter Email Address          : ");
					scanf("%s",&info.email);
					printf("Enter Subject                  : ");
					scanf("%s",&info.subject);
					printf("Enter Prelim Grade           : ");
					scanf("%f",&info.prelim);
					printf("Enter Midtem Grade           : ");
					scanf("%f",&info.midterm);
					printf("Enter Endterm Grade           : ");
					scanf("%f",&info.endterm);
					info.final_grade = (info.prelim * 0.20) + (info.midterm * 0.30) + (info.endterm * 0.50);
					printf("\n");
                    printf("\n Final Grade         : %2.0f",info.final_grade);
					fwrite ( &info, recsize, 1, fp ) ;
					printf("\n\n");
					printf ( "\nAdd another Record (Y/N) " ) ;
					fflush ( stdin ) ;
					another = toupper(getche()) ;
				}

				break ;

			case '2' :
	            system("cls");
				rewind ( fp );
				printf("\n\n");
                printf("=== View the Records in the Database ===");
                printf("\n\n");
				while ( fread ( &info, recsize, 1, fp ) == 1 ) {
                    printf("\n");
                    printf("\n Name                : %s",info.name);
                    printf("\n Course              : %s",info.course);
                    printf("\n Gender              : %c",info.sex);
                    printf("\n Age                 : %d",info.age);
                    printf("\n Home Address        : %s",info.address);
                    printf("\n Email Address       : %s",info.email);
                    printf("\n Subject             : %s",info.subject);
                    printf("\n Prelim Grade        : %2.0f",info.prelim);
                    printf("\n Midterm Grade       : %2.0f",info.midterm);
                    printf("\n Endterm Grade       : %2.0f",info.endterm);
                    printf("\n");
                    info.final_grade = (info.prelim * 0.20) + (info.midterm * 0.30) + (info.endterm * 0.50);
                    printf("\n Final Grade         : %2.0f",info.final_grade);
                }
				printf("\n\n");
                system("pause");
				break ;

			case '3' :

				another = 'Y' ;
				while ( another == 'Y' )
				{
	   			    system("cls");
                    printf("=== Update Student Records in the Database ===");
                    printf("\n\n");
					printf( "\nEnter Student Name: " ) ;
					scanf( "%s",&student_name) ;
					printf("\n");


					rewind ( fp ) ;
					while ( fread ( &info, recsize, 1, fp ) == 1 )
					{
						if ( strcmp ( info.name, student_name ) == 0 )
						{
							printf("Enter Student Name     : ");
                            scanf("%s",&info.name);
                            printf("Enter Course           : ");
                            scanf("%s",&info.course);
                            printf("Enter Gender M/F       : ") ;
                            info.sex = toupper(getche());
                            printf("\n");
                            printf("Enter Age              : ") ;
                            scanf("%d",&info.age);
                            printf("Enter Home Address     : ");
                            scanf("%s",&info.address);
                            printf("Enter Email Address    : ");
                            scanf("%s",&info.email);
                            printf("Enter Subject          : ");
					        scanf("%s",&info.subject);
					        printf("Enter Prelim Grade     : ");
					        scanf("%f",&info.prelim);
					        printf("Enter Midtem Grade     : ");
                            scanf("%f",&info.midterm);
                            printf("Enter Endterm Grade    : ");
					        scanf("%f",&info.endterm);

                            printf("\n");
                            info.final_grade = (info.prelim * 0.20) + (info.midterm * 0.30) + (info.endterm * 0.50);
                            printf("\n Final Grade         : %2.0f",info.final_grade);
							fseek ( fp, - recsize, SEEK_CUR ) ;
							fwrite ( &info, recsize, 1, fp ) ;
							break ;
						}
						else {

                            printf("Sorry No such record in the database.");
                            break;
						}
					}
                    printf("\n\n");
					printf ( "\nUpdate Another Record (Y/N) : " ) ;
					fflush ( stdin ) ;
					another = toupper(getche());
				}

				break ;

			case '4' :

				another = 'Y' ;
				while ( another == 'Y' )
				{
					system("cls");
                    printf("=== Delete Student Records in the Database ===");
                    printf("\n\n");
					printf( "\nEnter Student Name To Be Deleted : " ) ;
					scanf( "%s",&student_name) ;
					printf("\n");
     				ft = fopen ( "TEMP.DAT", "wb" ) ;
					rewind ( fp ) ;
					while ( fread ( &info, recsize, 1, fp ) == 1 )
					{
						if ( strcmp ( info.name, student_name ) != 0 ) {
							fwrite ( &info, recsize, 1, ft ) ;
							printf("Record Successfully Deleted From the Database.");
							break;
						}
						else {
                            printf("Sorry No such record in the database.");

                            break;
						}
					}

					fclose ( fp ) ;
					fclose ( ft ) ;
					remove ( "BIODATA.DAT" ) ;
					rename ( "TEMP.DAT", "BIODATA.DAT" ) ;

					fp = fopen ( "BIODATA.DAT", "rb+" ) ;

                    printf("\n\n");
					printf( "Delete Another Record (Y/N) " ) ;
					fflush ( stdin ) ;
					another = toupper(getche());
				}
				break ;

			case '5' :
				fclose ( fp ) ;
				printf("\n\n");
				printf("\t\tThank You For Using This Program");
				printf("\n\n");
				system("PAUSE");
				exit(0);

		}
	}
} // End of Code
