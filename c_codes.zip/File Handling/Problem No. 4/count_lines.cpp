#include <iostream>
#include <fstream>
using namespace std;

int main() {
   ifstream f1;
   char c;
   int numchars, numlines;

   f1.open("test.txt");

   numchars = 0;
   numlines = 0;
   system("COLOR F0");
   cout <<"\n\n";
   cout <<"\tCount number of lines, words, characters from a file";
   cout <<"\n\n";
   f1.get(c);
   while (f1) {
     while (f1 && c != '\n') {
       numchars = numchars + 1;
       f1.get(c);
     }
     numlines = numlines + 1;
     f1.get(c);
   }
   cout << "\tThe file has " << numlines << " lines and " 
     << numchars << " characters.";
   cout <<"\n\n"; 
   cout <<"\tEnd of Program";
   cout <<"\n\n";  
   system("pause");
   
}
