// .cpp
// Author   : Mr. Jake R. Pomperada, BSCS, MAED-IT
// Date     : August 15, 2018  Wednesday
// Location : Bacolod City, Negros Occidental
// Website  : http://www.jakerpomperada.com
// Email    : jakerpomperada@jakerpomperada.com


#include <fstream>
#include <iostream>

using namespace std;

int main()
{
  ofstream out_file;

  //create the file
  out_file.open( "example.txt" );       
  
  //write a string to the file
  out_file <<"C++ Text File Demonstration\n";
  out_file <<"This text will now be inside of example.txt";
  
  //close the file
  out_file.close();
  
  system("pause");
  return 0;
}
