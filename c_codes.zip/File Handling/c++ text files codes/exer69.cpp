#include <fstream>
#include <iostream>
using namespace std;

int main()
{
  ofstream out_file;
 
  //open file in append mode
  out_file.open("file.txt", ios::app);
  
  out_file<<"\nNew data 1";		
  out_file<<"\nNew data 2";
  
  out_file.close();
  
  system("pause");
  return 0;
}
