#include <fstream>
#include <iostream>
#include <string>
using namespace std;
int main()
{
  string str1,str2,str3;
  char c1;
  ifstream in_file;
  in_file.open( "example.txt" );    //open the file
  
  in_file>> str1;                   //read 1 string
  in_file>> str2;                   //read 1 string       
  in_file>> c1;                     //read 1 char       
  in_file>> str3;
  cout<<"str1 = "<< str1 <<"\n";
  cout<<"str2 = "<< str2 <<"\n";
  cout<<"str3 = "<< str3 <<"\n";
  cout<<"c1 = "<< c1 <<"\n";
  
  in_file.close();                  //close the file
  system("pause");
  return 0;
}
