#include <fstream>
#include <iostream>
#include <string>
using namespace std;
int main()
{
  string str;  
  ofstream out_file;
  ifstream in_file;
  out_file.open("file.txt");
  out_file<<"This is the first line\n";
  out_file<<"This is the second line\n";
  out_file<<"This is the third line\n";
  out_file.close();
  in_file.open("file.txt");
  getline(in_file,str);    //read first line to str
  cout<<str<<endl;                      
  getline(in_file,str);    //read second line to str             
  cout<<str<<endl;                      
  getline(in_file,str);    //read third line to str
  cout<<str<<endl;                      
  in_file.close();
  system("pause");
  return 0;
}
