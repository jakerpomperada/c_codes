#include <fstream>
#include <iostream>
#include <string>
using namespace std;
int main()
{
  string str;  
  ifstream in_file;
  in_file.open("file.txt");
  // is_open checks if the file has been opened successfully
  if( in_file.is_open() )
  {
      in_file>>str;    //read 1 string
      cout<<str<<endl; 
  }
  else
  {
      cout<<"file not found\n";
  }
  system("pause");
  return 0;
}
