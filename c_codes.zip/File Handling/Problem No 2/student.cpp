// student.cpp
// Written By Mr. Jake R. Pomperada, BSCS, MAED-IT
// July 26, 2018  Thursday
// Bacolod City, Negros Occidental Philippines
// Website : http://www.jakerpomperada.com
// Email Address : jakerpomperada@jakerpomperada.com and jakerpomperada@aol.com

#include <iostream>
#include <iomanip>
#include <cmath>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>

using namespace std;
 
 
int main( )
{
	FILE *fp, *ft ;
	char another, choice ;
	struct student
	{
		char stud_id_no[300];
		char name[300];
		char course[300];
		char subject[300];
		float prelim,midterm,endterm,final_grade;
	} ;
	struct student grade;
	char student_id[300];
	long int recsize;
    int flag=0;
	fp = fopen ("GRADE_DB.DAT", "rb+" ) ;
	if ( fp == NULL )
	{
		fp = fopen ( "GRADE_DB.DAT", "wb+" ) ;
		if ( fp == NULL )
		{
			puts ( "Cannot open file" ) ;
			exit(0) ;
		}
	}
	recsize = sizeof ( grade ) ;
	while ( 1 )
	{
        system("CLS");
        system("COLOR F0"); 
		setprecision(0);
        cout <<"\n";
		cout << "\n\t==========================================";
		cout <<"\n";
		cout <<"\n\t STUDENT GRADING DATABASE SYSTEM IN C++";
		cout <<"\n\n";
		cout << "\tCreated By Mr. Jake R. Pomperada,MAED-IT";
		cout <<"\n\t==========================================";
		cout <<"\n\n";
		cout << "\t[1] INSERT STUDENT RECORD";
		cout <<"\n";
		cout << "\t[2] BROWSE STUDENT RECORD";
		cout <<"\n";
		cout << "\t[3] EDIT STUDENT RECORDS" ;
		cout <<"\n";
		cout  <<"\t[4] FIND STUDENT RECORDS";
		cout <<"\n";
		cout << "\t[5] REMOVE STUDENT RECORDS";
		cout <<"\n";
		cout  << "\t[6] QUIT PROGRAM" ;
		cout <<"\n\n";
		cout  <<"\tSELECT YOUR OPTION :=> ";
		fflush (stdin) ;
		choice = getche() ;
		switch ( choice )
		{
			case '1' :
				fseek ( fp, 0 , SEEK_END ) ;
				another = 'Y' ;
				while ( another == 'Y' )
				{
					system("cls");
					cout <<"\n\n";
					cout << "\t=== INSERT NEW STUDENT GRADE RECORD ===";
					cout <<"\n\n";
					cout <<"\tEnter Student ID Number : ";
                    cin >> grade.stud_id_no;
					cout << "\tEnter Student Name: ";
					fflush (stdin) ;
					gets(grade.name);
					cout <<"\tEnter Course : ";
					fflush (stdin) ;
					gets(grade.course);
                    cout <<"\tEnter Subject : ";
					fflush (stdin) ;
					gets(grade.subject);
					cout <<"\tEnter Prelim Grade: ";
					cin >> grade.prelim;
					cout << "\tEnter Midtem Grade: ";
					cin >> grade.midterm;
					cout << "\tEnter Endterm Grade: ";
					cin >> grade.endterm;
					grade.final_grade = (grade.prelim * 0.30) + (grade.midterm * 0.30) + (grade.endterm * 0.40);
					cout << "\n";
                    cout << "\n\tStudent Final Grade : "  << round(grade.final_grade);
					fwrite (&grade, recsize, 1, fp ) ;
					cout << "\n\n";
					cout  << "\n\tAdd New Student Record (Y/N) : " ;
					fflush (stdin) ;
					another = toupper(getche()) ;
				}
				break ;
			case '2' :
        	system("cls");
				rewind ( fp );
				cout << "\n\n";
                cout <<"\t=== VIEW STUDENT GRADE RECORD ===";
                cout <<"\n\n";
		while ( fread ( &grade, recsize, 1, fp ) == 1 )
        {
       cout <<"\n";
       cout <<"\n\t  ID Number        : " <<grade.stud_id_no;
       cout <<"\n\t  Name             : " <<grade.name;
       cout <<"\n\t  Course           : " <<grade.course;
       cout <<"\n\t  Subject          : " << grade.subject;
       cout <<"\n\t  Prelim Grade     : " <<grade.prelim;
       cout <<"\n\t  Midterm Grade    : " <<grade.midterm;
       cout <<"\n\t  Endterm Grade    : " <<grade.endterm;
       cout <<"\n";
       grade.final_grade = (grade.prelim * 0.30) + (grade.midterm * 0.30) + (grade.endterm * 0.40);
       cout <<"\n\t Student Final Grade : " <<round(grade.final_grade);
	  }
          cout <<"\n\n";
         system("pause");
				break ;
			case '3' :
			another = 'Y' ;
				while ( another == 'Y' )
				{
				system("cls");
	         	cout <<"\t=== EDIT STUDENT GRADE RECORD ===";
		        cout <<"\n\n";
	     	    cout <<"\tEnter Student ID Number : ";
                cin >> student_id;
			    rewind ( fp ) ;
					cout <<"\n";
					while ( fread ( &grade, recsize, 1, fp ) == 1 )
					{
						if ( strcmp ( grade.stud_id_no, student_id) == 0 )
						{
							cout <<"\tEnter Student ID Number : ";
                            fflush (stdin) ;
                            gets(grade.stud_id_no);
							cout <<"\tEnter Student Name : ";
							fflush ( stdin ) ;
							gets(grade.name);
					        cout <<"\tEnter Course: ";
							fflush ( stdin ) ;
							gets(grade.course);
							cout <<"\tEnter Subject : ";
							fflush ( stdin ) ;
							gets(grade.subject);
							cout <<"\tEnter Prelim Grade : ";
							cin >> grade.prelim;
							cout <<"\tEnter Midtem Grade : ";
							cin >> grade.midterm;
							cout <<"\tEnter Endterm Grade: ";
							cin >> grade.endterm;
							cout <<"\n";
							grade.final_grade = (grade.prelim * 0.20) + (grade.midterm * 0.30) + (grade.endterm * 0.50);
							cout <<"\n\tStudent Final Grade : " << round(grade.final_grade);
							fseek ( fp, - recsize, SEEK_CUR ) ;
							fwrite ( &grade, recsize, 1, fp ) ;
							break ;
						}
					}
			 if (strcmp(grade.stud_id_no,student_id) != 0 )
                 {  
                   cout <<"\n\n";
                   cout <<"\tNo Student Record in the Database.";
                   cout <<"\n";
                   system("pause");
                   break;
                   }
                 cout <<"\n\n";
			     cout  <<"\n\tEdit Another Student Record (Y/N) : ";
					fflush ( stdin ) ;
					another = toupper(getche());
				}
				break ;
     	case '4' :
	   rewind ( fp ) ;
	   another = 'Y' ;
				while ( another == 'Y' )
				{
				system("cls");
		        cout <<"\t=== Find Student Records ===";
		        cout <<"\n\n";
			     cout <<"\tEnter Student ID Number : ";
                 cin >>student_id;
					cout <<"\n";
					rewind ( fp ) ;
					while ( fread ( &grade, recsize, 1, fp ) == 1 )
					{
						if ( strcmp (grade.stud_id_no,student_id) == 0 )
						{
                    cout <<"\n";
					cout <<"\n\tID Number      : " <<grade.stud_id_no;
					cout <<"\n\tName           : " << grade.name;
					cout <<"\n\tCourse         :  " <<grade.course;
	 	            cout <<"\n\tSubject        : " <<grade.subject;
                    cout <<"\n\tPrelim Grade   :  " <<grade.prelim;
                   cout <<"\n\tMidterm Grade  :  " <<grade.midterm;
                   cout <<"\n\tEndterm Grade  : " << grade.endterm;
                   cout <<"\n";
       grade.final_grade = (grade.prelim * 0.30) + (grade.midterm * 0.30) + (grade.endterm * 0.40);
       cout <<"\n\tStudent Final Grade : " << round(grade.final_grade);
       cout <<"\n\n";
       system("pause");
       break;
	}
}
      if (strcmp(grade.stud_id_no,student_id) != 0 )
          {
            cout <<"\n\n";
            cout <<"\tNo Student Record found in the Database.";
            cout <<"\n";
            system("pause");
            break;
           }
                    cout  <<"\n\n";
					cout  <<"\n\tFind Another Student Record (Y/N) : " ;
					fflush ( stdin ) ;
					another = toupper(getche());
				}
				break ;
			case '5' :
				another = 'Y' ;
				while ( another == 'Y' )
				{
					system("cls");
                    cout <<"\t=== REMOVE STUDENT GRADE RECORD ===";
                    cout <<"\n\n";
					cout <<"\tEnter Student ID Number : ";
                    cin >> student_id;
					cout <<"\n";
					ft = fopen ( "TEMP.DAT", "wb" ) ;
					rewind ( fp ) ;
					while ( fread ( &grade, recsize, 1, fp ) == 1 )
					{
						if ( strcmp (grade.stud_id_no, student_id) != 0 )
							fwrite ( &grade, recsize, 1, ft ) ;
                 else
                flag=1;
                  }
					fclose ( fp ) ;
					fclose ( ft ) ;
					remove ( "GRADE_DB.DAT" ) ;
					rename ( "TEMP.DAT", "GRADE_DB.DAT" ) ;
				    fp = fopen ( "GRADE_DB.DAT", "rb+" ) ;
       if(flag==1) {
         cout <<"\n\n";
         cout <<"\tRecord Successfully Deleted From the Database.";
         cout <<"\n";
         system("pause");
         }
		else if (flag!=1) {
             cout <<"\n\n";
             cout <<"\tRecord Not Found in the Database.";
             cout <<"\n";
            system("pause");
             }
                    cout <<"\n\n";
					cout << "\tRemove Another Student Record (Y/N) : " ;
					fflush (stdin) ;
					another = toupper(getche());
				}
				break ;
			case '6' :
				fclose ( fp ) ;
				cout <<"\n\n";
				cout <<"\tEND OF PROGRAM";
				cout <<"\n\n";
				cout << "\tThank You Very Much For Using This Software.";
				cout <<"\n\n";
				system("PAUSE");
				exit(0);
		}
	}
} // End of Code
