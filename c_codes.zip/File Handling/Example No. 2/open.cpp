// open_textfile.cpp
// Author   : Mr. Jake Rodriguez Pomperada,BSCS, MAED-IT
// Date     : September 7, 2018  Friday  11:53 AM
// Location : Bacolod City, Negros Occidental
// Website  : http://www.jakerpomperada.com
// Email    : jakerpomperada@jakerpomperada.com
// Tool     : Dev C++ Version 5.11

#include <fstream>
#include <iostream>
#include <string>

using namespace std;
int main()
{
  string line;
  system("color F0");
  cout <<"\n\n";
  cout <<"\tOpening a Text File in C++";
  cout <<"\n\n";
  ifstream myfile ("example.txt");
  if (myfile.is_open())
  {
    while ( getline (myfile,line) )
    {
      cout <<"\t"<<line << '\n';
    }
    myfile.close();
  }

  else {
   cout << "Unable to open file"; 
  }
}

