// open_textfile.cpp
// Author   : Mr. Jake Rodriguez Pomperada,BSCS, MAED-IT
// Date     : September 7, 2018  Friday  11:53 AM
// Location : Bacolod City, Negros Occidental
// Website  : http://www.jakerpomperada.com
// Email    : jakerpomperada@jakerpomperada.com
// Tool     : Dev C++ Version 5.11

#include <fstream>
#include <iostream>
#include <string>

using namespace std;
int main()
{
  string str1,str2;

  ifstream in_file;
  in_file.open( "example.txt" );    //open the file
 // system("color F0");
  in_file>> str1;                   //read 1 string
  in_file>> str2;                   //read 1 string       
  cout<<"str1 = "<< str1 <<"\n";
  cout<<"str2 = "<< str2 <<"\n";
    
  in_file.close();                  //close the file
  system("pause");
  return 0;
}

