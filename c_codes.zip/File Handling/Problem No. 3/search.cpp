// search.cpp
// Author   : Mr. Jake R. Pomperada,BSCS,MAED-IT
// Address  : Bacolod City, Negros Occidental Philippines
// Date     : September 6, 2018      Thursday   8:75 AM
// Website  : jakerpomperada.com
// Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@aol.com
// Tool     : Dev C++ Version 5.11

#include <iostream>
#include <fstream>

using namespace std;

int search (char a[]) 
{
char *search = a ; 
int offset;
string line;
ifstream Myfile;
Myfile.open("demo.txt");
if(Myfile.is_open())
{
while(!Myfile.eof())
{
getline(Myfile,line);
if ((offset = line.find(search,0)) != string::npos) 
   {
 cout <<"\n\n";            
 cout << "\tThe name "<< search <<" is FOUND in the text file.";
 cout <<"\n\n";
 goto terminate;
  } 
}
cout <<"\n\n";    
cout << "\tThe name "<< search <<" is NOT FOUND in the text file.";
cout <<"\n\n";
Myfile.close();
}
else 
cout<<"Unable to open this file."<<endl;
terminate:
cout <<"\n";    
cout << "\tThank you for Using This Software.";
cout <<"\n\n";          
system("pause");
}

int main()
{
    char name[100];
    system("COLOR F0");
    cout <<"\n\n";
    cout <<"\tSearch a Name in the Text File in C++";
    cout <<"\n\n";
    cout<<"\tEnter name to search : ";
    fflush(stdin);
    cin.getline(name,50);
    search(name);
}
