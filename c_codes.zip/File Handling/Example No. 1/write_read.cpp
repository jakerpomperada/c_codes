/*open_write_read.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : December 2, 2018  Sunday 6:30 AM 
*/

/* Open, write and close a file : */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
 
int main()
{
  FILE *fp ;
  char data[100];
    
  printf("\n\n");
  printf("\tText File Opening, Write and Read Example in C");
  printf("\n\n");
    // opening an existing file
    printf( "\tOpening the file write.txt in write mode" ) ;
    printf("\n\n");
    fp = fopen("write.txt", "w") ;
    if ( fp == NULL )
    {
        printf( "Could not open file write.txt" ) ;
        return 1;
    }
    printf("\tEnter some text from keyboard to write in the file write.txt" );  
	printf("\n\n"); 
			  /* getting input from user */
    while ( strlen ( gets( data ) ) > 0 )
    {
        /* writing in the file */
        fputs(data, fp) ;   
        fputs("\n", fp) ;
    }
    /* closing the file */
  printf("\n");  
  printf("\tClosing the file write.txt") ;
  fclose(fp);
  printf("\n");
  printf("\tData have been written successfully.");
  printf("\n\n");
  printf("\tEND OF PROGRAM");
  printf("\n\n");
  system("pause");
 
}
