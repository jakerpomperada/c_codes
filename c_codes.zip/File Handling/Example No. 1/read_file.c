/*read_file.c
 Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
 Date      : December 2, 2018  Sunday 11:26 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
#include <stdlib.h> /* For exit() function */
#include <stdlib.h> /* For system("pause"); statement */
int main()
{
    char c[1000];
    FILE *fptr;
    if ((fptr = fopen("write.txt", "r")) == NULL)
    {
        printf("Error! opening file");
        /* Program exits if file pointer returns NULL. */
        exit(1);         
    }
    /* reads text until newline */
    fscanf(fptr,"%[^\n]", c);
    printf("\n");
    printf("\tReading Data from the file:\n\n%s", c);
    fclose(fptr);
    printf("\n\n");
 	printf("\tEND OF PROGRAM");
 	printf("\n\n");
  	system("pause");
}

