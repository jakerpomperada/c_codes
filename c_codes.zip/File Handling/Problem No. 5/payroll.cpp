// payroll.cpp
// Author   : Mr. Jake R. Pomperada,BSCS,MAED-IT
// Address  : Bacolod City, Negros Occidental Philippines
// Date     : September 9, 2018      Sunday   7:05 PM
// Website  : jakerpomperada.com
// Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@aol.com
// Tool     : Dev C++ Version 5.11

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <conio.h>
#include <string.h>

using namespace std;
int some (string s){
    istringstream buffer(s);
    int some_int;
    buffer>>some_int;
    return some_int;
}

 int start();

main() {
     char pass2[20],user[20];
        char ch;
        // Admin Account
        int pass=0,user2=0;
        // User Account
        int pass1=0,user1=0;
        // Employee Account
        int pass3=0,user3=0;

     do {
         system("COLOR F0");
         cout << "\t\t\n=====================================";
         cout << "\t\t\n        PASSWORD SECURITY            ";
         cout << "\t\t\n====================================";
         cout << "\n\n";
         cout << "Enter User Name     : ";
         cin >> pass2;
         cout << "Enter your Password : ";
         cin >> user;
        // Admin Account
        user2=strcmp(pass2,"admin");
        pass=strcmp(user,"admin");
       // User Account
        user1=strcmp(pass2,"user");
        pass1=strcmp(user,"user");
      // Employee Account
        user3=strcmp(pass2,"emp");
        pass3=strcmp(user,"emp");
         // For Admin Account
        if (pass==0 && user2==0) {
            cout << "\t \n Welcome to the System! Administrator";
            cout << "\n\n";
            start();
         }

         // For user account
        if (pass1==0 && user1==0) {
            cout << "\t \n Welcome to the System! Users";
            cout << "\n\n";
            start();
         }

         // For Employee account
        if (pass3==0 && user3==0) {
            cout << "\t \n Welcome to the System! Employees";
            cout << "\n\n";
            start();
         }


         else {
            cout << "\t \n Intruder Detected Try Again.";
            cout << "\n\n";
           system("pause");
        }

     } while (pass != 0 && user2!=0 || pass1!=0 && user1!=0
              || pass3==0 && user3==0);
       cout << "\n\n";
       system("pause");
}

int start() {
    ofstream output ("dtr.txt", ios::app);
    ofstream payslip ("payslip.txt", ios::app);
    ifstream read_file ("employee.txt");
    string id, display;
    string day[]= {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
    string time_in[5], time_out[5];
    int time_in_conversion[5], time_out_conversion[5];
    int lunch_break = 1;
    int total_hrs = 0;
    float sss =0.00;
    float pilhealth= 0.00,widtax= 0.00,pagibig = 0.00;
    float net_income =0.00, gross_income=0.00;
    float  gsis = 0.00;
    float  rate_per_hr ;
    float tax = 0.00;
    int regular_time;
    float deduction = 0.00;

    cin.ignore();
    cout<<"Enter Employee ID Code: ";
    getline(cin, id);
   output << "\n";
   output << id << setw(3) << ":";
    while (!read_file.eof()){
        getline(read_file, display);

        if (id==display){

            cout<<"Welcome Employee No     : "<<id << setw(10);
            getline (read_file, display);
            cout << "\n\n";
            cout<<setw(5) <<"Name          : " << setw(2) << display<<endl;
            payslip << "\n";
            payslip<<"Name        : "<<setw(2) <<display<<endl;
            getline (read_file, display);
            cout<<setw(8) <<"Position       : " << setw(2) << display<<endl;
            payslip<<"\nPosition    : "<<setw(2) <<display <<endl;
            getline (read_file, display);
            cout<<setw(10) <<"Department   : " << setw(2) << display<<endl;
            payslip<<"\nDepartment  : "<<setw(2)<< display<<endl;
            for (int a = 0; a<5 ; a++){
            cout << "\n";
          cout <<setw(5) << day[a];
            cout << "\n";
            cout<<"\tTime in: ";
            cin>>time_in[a];
            cout<<"\tTime out: ";
            cin>>time_out[a];
            output<<  day[a] << setw(8);
            output<<setw(6) << time_in[a] <<"AM"<< "-";
            output<<setw(4) <<time_out[a]<<"PM ";
            time_in_conversion[a] = some (time_in[a]);
            time_out_conversion[a] = some (time_out[a]);
            total_hrs +=((time_out_conversion[a] - time_in_conversion[a])-lunch_break);
            cout<<"\n\tTotal Hours: "<<total_hrs;
            }
cout<<"\n\t Total Worked Hours: "<<total_hrs;
cout<<"\n\t Enter rate per hour Php : ";
cin>>rate_per_hr;
cout<<"\n\t Enter SSS : ";
cin>>sss;
cout<<"\n\t Enter PagIBIG : ";
cin>>pagibig;
cout<<"\n\t Enter Philhealth: ";
cin>>pilhealth;
cout<<"\n\t Enter Withholding tax: ";
cin>>widtax;
    gross_income = total_hrs*rate_per_hr;
    net_income = gross_income - (pilhealth+widtax+pagibig+sss);
    deduction =(pilhealth+widtax+pagibig+sss);
cout << setprecision(2) << fixed;
cout<<"\nRate per hour       : Php "<<rate_per_hr;
cout<<"\nGross Income        : Php "  <<gross_income;
cout<<"\nTotal deductions    : Php " <<deduction;
cout<<"\nNet Income          : Php "    <<net_income;
payslip << setprecision(2) << fixed;
payslip<<"\n***********Deductions*************";
payslip<<"\n\nSSS            : Php "<<sss;
payslip<<"\nPhilhealth       : Php "<<pilhealth;
payslip<<"\nPagIBIG          : Php "<<pagibig;
payslip<<"\nWitholding tax   : Php "<<widtax;
payslip<<"\n__________________________________";
payslip<<"\n          total  : Php "<<deduction<<endl;
payslip<<"\n\nGross pay      : Php "<<gross_income;
payslip<<"\n Net Income     : Php " <<net_income;
payslip<<"\n\n";
payslip<<"\n*******************************";
output<<"\nTotal hours: "<<total_hrs;
output<<"\n";
output.close();
payslip.close();
    }
    }
cout << "\n\n";
system("pause");
return 0;
} // End of Code
