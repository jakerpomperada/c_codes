/*read_lines.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : December 2, 2018  Sunday  12:49 PM
 */
#include <stdio.h>
#include <stdlib.h>

#define FILENAME "programming.txt"

int main()
{
	FILE *fp;
	char ch;
	int linesCount=0;
 	fp=fopen(FILENAME,"r");
	if(fp==NULL)
	{
		printf("\tFile \"%s\" does not exist!!!\n",FILENAME);
		return -1;
	} 
	while((ch=fgetc(fp))!=EOF)
	{
		if(ch=='\n') {
			linesCount++;
		}
	}
	fclose(fp);
	printf("\n\n");
	printf("\t===== DISPLAY REPORT =====");
	printf("\n\n");
	printf("\tTotal number of lines are: %d.\n",linesCount);
	printf("\n");
	printf("\tEnd of Program");
	printf("\n\n");
    system("pause");	
}
