// addition.c
// Author    : Mr. Jake R. Pomperada, BSCS,MAED-IT
// Date      : November 28, 2018   Wednesday  10:13 AM
// Location  : Bacolod City, Negros Occidental Philippines.
// Website   : http://www.jakerpomperada.com
// Email     : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com

#include <stdio.h>

int addition(int num1, int num2);

int main()
{
	int a=5,b=10;
	int result=0;
	printf("\n\n");
 	printf("\tFunction Demonstration");
  	printf("\n");
	result = addition(a,b);
    printf("\n\n");
	printf("\tThe sum of %d and %d is %d.",a,b,result);	
	printf("\n\n");
	printf("\tEnd of Program");
    printf("\n\n");
}

// function returing the sum of the two numbers

int addition(int num1, int num2)
{
	return(num1+num2);
}
