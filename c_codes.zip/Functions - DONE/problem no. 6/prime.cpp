/*prime.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 28,2018  Wednesday 3:42 PM
*/
#include <stdio.h>
// function prototype
int check_prime(int);
int  main(){
int values=0;
printf("\n\n");
printf("\t\tPrime Number Generator Version 1.0");
printf("\n\n");
printf("\tGive a Number : ");	    
scanf("%d",&values);	   
check_prime(values);
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n"); 
}
// function declaration
int check_prime(int x)
 {
 int var1=0,var2=0,flag=0;
 printf("\n\n");
 printf("\tList of Prime Numbers");
 printf("\n\n");
 printf("\t");
 for(var1 = 2; var1 <= x; var1++){
		flag = 1;
		for(var2 = 2; var2 < var1; var2++){
			if((int)var1 % (int)var2 == 0){
				flag = 0;
			}
		}

		if(flag == 1){
			printf("%d ",var2);
		}
	}
 }
