/* grade.c
   Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date      : November 28,2018  Wednesday  3:58 PM
   Location  : Bacolod City, Negros Occidental Philippines.
   Website  : http://www.jakerpomperda.com 
   Emails   : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/ 
#include <stdio.h>
int grade_check(int grade)
{
    char remarks[][100] ={"You Passed the Subject.",
	                        "You Failed the Subject."};
	char *display_remarks;                      
	if (grade >=75) {
		display_remarks =remarks[0];
		printf("\n");
		printf("\tStudent Grade  : %d " ,grade);
		printf("\n");
		printf("\tRemarks        : %s " ,display_remarks);
		printf("\n\n");
	}
	else
	{
		display_remarks =remarks[1];
		printf("\n");
		printf("\tStudent Grade  : %d " ,grade);
		printf("\n");
		printf("\tRemarks        : %s " ,display_remarks);
		printf("\n");
	}
}

int main()
{
char subject_name[100];
int grade=0;
printf("\n\n");
printf("\t\tSubject Grade Checker");
printf("\n\n");
printf("\tSubject Name  : ");
gets(subject_name);
printf("\tSubject Grade  : ");
scanf("%d",&grade);
printf("\n\n");
printf("\t===== DISPLAY RESULT ======");
printf("\n\n");
printf("\tSubject Name   : %s ",subject_name);
grade_check(grade);
printf("\n");
printf("\tEnd of Program");
printf("\n\n"); 	
}

