// call_by_address.c
// Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
// Date      : November 28, 2018  Wednesday   2:23 PM
// Location  : Bacolod City, Negros Occidental Philippines.
// Website   : http://www.jakerpomperada.com
// Email     : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
#include <stdio.h>
int cube (int *);
int main()
{
int a=10;
int b=a;
int display=0;
printf("\n\n");
printf("\tCall By Address/Pointer");
display = cube(&a);
printf("\n\n");	
printf("\tThe given value is %d. The result is %d.",b,display);
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
}
int cube(int *b)
{
	*b = (*b) * (*b)* (*b);
	return(*b);
}
