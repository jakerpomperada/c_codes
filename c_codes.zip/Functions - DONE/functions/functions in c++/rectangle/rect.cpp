#include <iostream>

using namespace std;


double area_solve(double width, double longer)
{
    double area=0, perimeter=0;

    area=width*longer;
    perimeter=2*(width+longer);

    cout<<"The area is : "<<area << "\n\n";
    cout<<"The perimeter is : "<<perimeter<<"\n\n";
}


main()
{
    double width=0,longer=0;
    cout << "\t\t Area of The Rectagle Solver 1.0";
    cout << "\n\n";
    cout<<"Type the width : ";
    cin>>width;
    cout<<"Type the longer : ";
    cin>>longer;
    cout << "\n\n";
    area_solve(width, longer);
    cout << "\n\n";
    system("pause");

}
