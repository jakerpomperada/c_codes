#include <iostream>
#include <iomanip>

using namespace std;

 int bill_solve(int amt) {
   int compute_1000=0,solve_1000=0;
    int solve_500, solve_200=0,solve_100=0;
    int solve_50, solve_20=0;

    int compute_500=0,compute_200=0,compute_100=0;
    int compute_50=0,compute_20=0;

    // 1000 php, 500php, 200php, 100php, 50php, and 20


     compute_1000 = amt / 1000;
     solve_1000 = compute_1000 % 1000;

     compute_500 = amt / 500;
     solve_500 = compute_500 % 500;


     compute_200 = amt / 200;
     solve_200 = compute_200 % 200;


     compute_100 = amt / 100;
     solve_100 = compute_100 % 100;

     compute_50 = amt / 50;
     solve_50 = compute_50 % 50;


     compute_20 = amt / 20;
     solve_20 = compute_20 % 200;


// 1 = 50php bill
// 2 = 20 php bill

  cout << "\n\n";
    cout <<"\n" << solve_1000 << setw(2) <<  "=  1000 PHP Bill ";
    cout <<"\n" << solve_500 <<  setw(2) << " = 500 PHP Bill ";
    cout <<"\n" << solve_200 <<  setw(2) << " =  200 PHP Bill ";
    cout <<"\n" << solve_100 <<  setw(2) << " =  100 PHP Bill ";
    cout <<"\n" << solve_50  <<  setw(2) << " =   50 PHP Bill ";
    cout <<"\n" << solve_20  <<  setw(2) <<  " =   20 PHP Bill ";
    cout << "\n\n";
}


main() {
     int amt=0;

    cout << "\t\tMONEY BILL DETERMINER";
    cout << "\n\n";
    cout << "Enter Amount :=> ";
    cin >> amt;
    bill_solve(amt);
    system("PAUSE");
}
