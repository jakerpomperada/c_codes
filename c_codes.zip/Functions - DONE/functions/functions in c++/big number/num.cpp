#include <iostream>

using namespace std;

int big_number(int a, int a);

int big_number(int a, int b)
{
    int big_value =0;

    if (a> b) {
        big_value = a;
        cout << "\n\n";
        cout << "The Big Value is "
             << big_value << ".";
    }
    else if (b> a) {
        big_value = b;
        cout << "\n\n";
        cout << "The Big Value is "
             << big_value << ".";
    }
    else if (a == b) {
        cout << "\n\n";
        cout << "They have the same value";
    }
}

 main() {
     int c=0,d=0;

     cout << "\t\t Big Number Checker Version 1.0 ";
     cout << "\n\n";
     cout << "Enter two numbers : ";
     cin >> c >> d;
     big_number(c,d);
     cout << "\n\n";
     system("pause");
 }


