#include<iostream>
using namespace std;

int swap_numbers(int a, int b)
{
    int temp=0;

    temp=a;
    a=b;
    b=temp;

    cout<<"The value of a is "<<a << ".\n";
    cout<<"The value of b is "<<b<< ".\n";

}

int main()
{
int a=0,b=0;

cout<<"Type the value of a : ";cin>>a;
cout<<"Type the value of b : ";cin>>b;
cout << "\n\n";
 swap_numbers(a,b);
cout << "\n\n";
 system("pause");

}
