#include <iostream.h>

using namespace std;

int high_number(int value1,int value2, int value3) {

  int high_value=0,low_value=0,middle_value=0;

   // Check For Higher Number

  if (value1 >= value2 && value1 >= value3) {
        high_value = value1;

    }

    else if (value2 >= value1 && value2 >= value3) {
        high_value = value2;
    }

    else if (value3 >= value1 && value3 >= value2) {
        high_value = value3;
    }


// Check For Low Number

  if (value1 <= value2 && value1 <= value3) {
        low_value = value1;
    }

    else if (value2 <= value1 && value2 <= value3) {
        low_value = value2;
    }
    else if (value3 <= value1 && value3 <= value2) {
        low_value = value3;
    }


 // Check For Middle Value
 
  if (value1 <= value2 && value1 >= value3 ) 
         {
        
        middle_value = value1;
    }
else  if (value2 <= value1 && value2 >= value3) 
      
         {
        
        middle_value = value2;
    }
else  if (value3 <= value1 && value3 >= value2) 
         {
        
        middle_value = value3;
    }

// Code for check all the possible arrangement of values

 // Check for 1 value   
else  if (value1 >= value2 && value1 <= value3) 
         {
        
        middle_value = value1;
    }

 // Check for 2 value   
else  if (value2 >= value1 && value2 <= value3) 
         {
        
        middle_value = value2;
    }


 // Check for 3 value   
else  if (value3 >= value1 && value3 <= value2) 
         {
        
        middle_value = value3;
    }

    cout << "\n\n";
    cout <<"\n" << high_value << " is the biggest number.";
   cout <<"\n" << middle_value << " is the middle number.";
   cout << "\n" << low_value << " is the lowest number.";
    cout << "\n\n";
}

main() {

    int a=0,b=0,c=0;

    cout << "\t High, Middle and Low Number Determiner 1.0";
    cout << "\n\n \t Created By: Mr. Jake R. Pomperada,MAED-IT";
    cout << "\n\n"; 
    cout << "Enter a Number : ";
    cin >> a;
    cout << "Enter a Number : ";
    cin >> b;
    cout << "Enter a Number : ";
    cin >> c;
    high_number(a,b,c);
    system("PAUSE");

}
