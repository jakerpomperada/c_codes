#include <iostream>
#include <iomanip>

using namespace std;

int square(int val[5])
{
    cout << "\n\n";
    cout << "Value" << setw(8) << "SQUARE"
    << setw(12) << "CUBE ROOT";
        cout << "\n";
  for (int v=0; v<5; v++){
      cout <<"\n" <<setw(2) << v[val]
          << setw(8) << v[val] * v[val]
         << setw(12) << v[val] * v[val] * v[val];
      }
}

main() {

int x[5];
   cout << "\t Square and Cube Root of the Number";
   cout << "\n\n";
   for (int list=0; list <5; list++) {
       cout << "Enter a Number : " ;
       cin >> list[x];
       }
        square(x);
cout << "\n\n";
system("PAUSE");
}
