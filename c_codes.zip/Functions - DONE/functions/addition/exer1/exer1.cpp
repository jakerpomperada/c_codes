#include <cstdlib>
#include <iostream>

using namespace std;

int addition(int a,int b, int c)
{
    int sum=0;
    sum = (a+b+c);

}

int main(int argc, char *argv[])
{
   int val1=0,val2=0,val3=0;
cout << "\t\tADDITION OF VALUES USING FUNCTION";
cout << "\n\n";
cout << "\t   Created By: Mr. Jake R. Pomperada, MAED-IT";
cout << "\n\n";
cout << "Enter First Value  : ";
cin >> val1;
cout << "Enter Second Value : ";
cin >> val2;
cout << "Enter Third Value  : ";
cin >> val3;
cout << "\n\n";
cout << "The sum of " << val1 << ", " <<
    val2 << " and " << val3 << " is " <<
    addition(val1,val2,val3) << ".";
cout << "\n\n";
    system("PAUSE");
    return EXIT_SUCCESS;
}
