#include <cstdlib>
#include <iostream>

using namespace std;

int addition(int a,int b, int c,int d, int e)
{
    int sum=0;
    sum = (a+b+c+d+e);

}

int main(int argc, char *argv[])
{
   
   cout << "The  total sum is" 
    " "<< addition(1,2,3,4,5) << ".";
   cout << "\n\n";
 
 
    system("PAUSE");
    return EXIT_SUCCESS;
}
