#include <iostream>

 using namespace std;

int age(int a)
{
    if (a >= 18) {
        cout << "\n\n";
        cout << "You are already an Adult.";
    }
    else {
        cout << "\n\n";
        cout << "You are still a Minor.";
    }
}

 main() {
   char reply;
   do {

     int x_age=0;
     system("cls");
     cout << "\t\t Age Determiner Version 1.0";
     cout << "\n\n";
     cout << "Enter Your Age :";
     cin >> x_age;
     age(x_age);
     cout << "\n\n";
     cout << "Do you want to repeat y/n : ";
     cin >> reply;
    } while (reply == 'Y' || reply == 'y');
 }
