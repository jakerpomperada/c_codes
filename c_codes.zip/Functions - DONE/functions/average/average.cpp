#include <iostream>
#include <iomanip>

using namespace std;

 float average(float prelim, float midterm, float final)
  {
      float compute=0;
      bool value;

      compute = (prelim * 0.30) +
                (midterm * 0.30) +
                (final * 0.40);

       if (compute >= 75.00) {
         value = true;
       }
       else
       {
           value = false;
       }

       switch(value) {

           case true : cout << "You Passed !!!";
                       break;
           case false : cout << "You Failed";
                       break;
       }
       cout << "\n\n";
       return(compute);
  }

  main() {
      float pre=0,mid=0,fin=0;

  cout << "\t Grade Solver 1.0";
  cout << "\n\n";
  cout << "Enter Prelim Grade :=> ";
  cin >> pre;
  cout << "Enter Midterm Grade :=> ";
  cin >> mid;
  cout << "Enter Final Grade :=> ";
  cin >> fin;
  cout << "\n\n";
  cout << fixed << setprecision(2);
  cout << "Your average grade is "
       <<average(pre,mid,fin)<<".";

  cout << "\n\n";
  system("PAUSE");
  }


