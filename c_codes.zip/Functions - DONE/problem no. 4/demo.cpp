// numbers.cpp
// Author    : Mr. Jake R. Pomperada, BSCS,MAED-IT
// Date      : August 26, 2018   Sunday  5:25 PM
// Location  : Bacolod City, Negros Occidental Philippines.
// Website   : http://www.jakerpomperada.com
// Email     : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com

#include <iostream>

using namespace std;

// function prototype declaration  
int high_number(int,int,int);

int main() {

    int a=0,b=0,c=0;

    cout << "\n\n"; 
    cout << "\tHigh, Middle and Low Number Determiner 1.0";
    cout << "\n\n\tCreated By: Mr. Jake R. Pomperada,MAED-IT";
    cout << "\n\n"; 
    cout << "\tEnter a Number : ";
    cin >> a;
    cout << "\tEnter a Number : ";
    cin >> b;
    cout << "\tEnter a Number : ";
    cin >> c;
    high_number(a,b,c);
    system("PAUSE");
}

// function high_number
int high_number(int value1,int value2, int value3) {

  int high_value=0,low_value=0,middle_value=0;

   // Check For Higher Number

  if (value1 >= value2 && value1 >= value3) {
        high_value = value1;

    }

    else if (value2 >= value1 && value2 >= value3) {
        high_value = value2;
    }

    else if (value3 >= value1 && value3 >= value2) {
        high_value = value3;
    }


// Check For Low Number

  if (value1 <= value2 && value1 <= value3) {
        low_value = value1;
    }

    else if (value2 <= value1 && value2 <= value3) {
        low_value = value2;
    }
    else if (value3 <= value1 && value3 <= value2) {
        low_value = value3;
    }


 // Check For Middle Value
 
  if (value1 <= value2 && value1 >= value3 ) 
         {
        
        middle_value = value1;
    }
else  if (value2 <= value1 && value2 >= value3) 
      
         {
        
        middle_value = value2;
    }
else  if (value3 <= value1 && value3 >= value2) 
         {
        
        middle_value = value3;
    }

// Code for check all the possible arrangement of values

 // Check for 1 value   
else  if (value1 >= value2 && value1 <= value3) 
         {
        
        middle_value = value1;
    }

 // Check for 2 value   
else  if (value2 >= value1 && value2 <= value3) 
         {
        
        middle_value = value2;
    }


 // Check for 3 value   
else  if (value3 >= value1 && value3 <= value2) 
         {
        
        middle_value = value3;
    }
   cout << "\n\n";
   cout <<"\t===== DISPLAY RESULT =====";
   cout << "\n";
   cout <<"\n\t" << high_value << " is the biggest number.";
   cout <<"\n\t" << middle_value << " is the middle number.";
   cout << "\n\t" << low_value << " is the lowest number.";
   cout << "\n\n";
}
