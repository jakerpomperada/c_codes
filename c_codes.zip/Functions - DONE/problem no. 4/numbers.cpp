/* numbers.c
   Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date      : November 28,2018  Wednesday  3:13 PM
   Location  : Bacolod City, Negros Occidental Philippines.
   Website  : http://www.jakerpomperda.com 
   Emails   : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/  
#include <stdio.h>
// function prototype declaration  
int high_number(int,int,int);
int main() {
int a=0,b=0,c=0;
printf("\n\n");
printf("\tHigh, Middle and Low Number Determiner 1.0");
printf("\n\n"); 
printf("\tEnter First Number  : ");
scanf("%d",&a);
printf("\tEnter Second Number : ");
scanf("%d",&b);
printf("\tEnter Third Number  : ");
scanf("%d",&c);    
high_number(a,b,c);
}
/* function high_number */
int high_number(int value1,int value2, int value3) {
  int high_value=0,low_value=0,middle_value=0;
   /* Check For Higher Number */
  if (value1 >= value2 && value1 >= value3) {
        high_value = value1;
    }
    else if (value2 >= value1 && value2 >= value3) {
        high_value = value2;
    }
    else if (value3 >= value1 && value3 >= value2) {
        high_value = value3;
    }

/* Check For Low Number */
  if (value1 <= value2 && value1 <= value3) {
        low_value = value1;
    }
    else if (value2 <= value1 && value2 <= value3) {
        low_value = value2;
    }
    else if (value3 <= value1 && value3 <= value2) {
        low_value = value3;
    }

 /*Check For Middle Value */
   if (value1 <= value2 && value1 >= value3 ) 
         {
        
        middle_value = value1;
    }
else  if (value2 <= value1 && value2 >= value3) 
      
         {
        
        middle_value = value2;
    }
else  if (value3 <= value1 && value3 >= value2) 
         {
        
        middle_value = value3;
    }

/* Code for check all the possible arrangement of values */
 /* Check for first value   */
else  if (value1 >= value2 && value1 <= value3) 
         {
       middle_value = value1;
    }
 /* Check for second value  */  
else  if (value2 >= value1 && value2 <= value3) 
         {
    
        middle_value = value2;
    }
 /* Check for third value */   
else  if (value3 >= value1 && value3 <= value2) 
         {
  middle_value = value3;
    }
printf("\n\n");
printf("\t===== DISPLAY RESULT =====");
printf("\n\n");
printf("\t%d is the Biggest number.",high_value);
printf("\n");
printf("\t%d is the Middle number.",middle_value);
printf("\n");
printf("\t%d is the Lowest number.",low_value);
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n"); 
}
