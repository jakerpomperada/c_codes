/*bills.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 28,2018  Wednesday 3:27 PM
*/
#include <stdio.h>
// function prototype
int bill_solve(int); 
int main() {
int amt=0;
printf("\n\n");  
printf("\t\tMONEY BILL DETERMINER");
printf("\n\n");  
printf("\tKindly give the amount : ");
scanf("%d",&amt);
bill_solve(amt);
}
int bill_solve(int amt) 
 {
    int compute_1000=0,solve_1000=0;
    int solve_500, solve_200=0,solve_100=0;
    int solve_50, solve_20=0;
    int compute_500=0,compute_200=0,compute_100=0;
    int compute_50=0,compute_20=0;
    /* 1000 php, 500php, 200php, 100php, 50php, and 20php */
     compute_1000 = amt / 1000;
     solve_1000 = compute_1000 % 1000;
     compute_500 = amt / 500;
     solve_500 = compute_500 % 500;
     compute_200 = amt / 200;
     solve_200 = compute_200 % 200;
     compute_100 = amt / 100;
     solve_100 = compute_100 % 100;
     compute_50 = amt / 50;
     solve_50 = compute_50 % 50;
     compute_20 = amt / 20;
     solve_20 = compute_20 % 200;
/* 1 = 50php bill
/ 2 = 20 php bill */
printf("\n\n");
printf("\t===== DISPLAY RESULT =====");
printf("\n\n");
printf("\n\t%d = 1000 PHP Bill",solve_1000);
printf("\n\t%d = 500 PHP Bill",solve_500);
printf("\n\t%d = 200 PHP Bill",solve_200);
printf("\n\t%d = 100 PHP Bill",solve_100);
printf("\n\t%d = 50 PHP Bill",solve_50);
printf("\n\t%d = 20 PHP Bill",solve_20);   
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n"); 
}


