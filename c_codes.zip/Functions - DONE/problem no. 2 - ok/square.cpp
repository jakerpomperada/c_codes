/*square.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 28,2018  Wednesday 2:58 PM
*/
#include <stdio.h>
/* function prototype declaration  */
int square(int);  
int main()
{  
int num_input=0;
int solve=0;
printf("\n\n");
printf("\tSquare a Number Solver");
printf("\n\n");
printf("\tGive a Number : ");
scanf("%d",&num_input);
solve= square(num_input);   
printf("\n\n"); 
printf("\tSquare of %d is %d.",num_input,solve);                                  
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n"); 
}
/* function square */
int square(int a)
{
int compute;
compute = a * a;
return(compute);
}
