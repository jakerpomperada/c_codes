// cube.cpp
// Author    : Mr. Jake R. Pomperada, BSCS,MAED-IT
// Date      : August 26, 2018   Sunday  4:30 PM
// Location  : Bacolod City, Negros Occidental Philippines.
// Website   : http://www.jakerpomperada.com
// Email     : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com


#include<iostream>
#include<conio.h>

using namespace std;

 // function prototype declaration  
int cube(int);  


int main()
{  
                
int num_input=0;
int solve=0;

cout <<"\n\n"
cout <<"\tCube a Number Solver";
cout <<"\n\n"
cout<<"\tGive a Number : ";
cin>>num_input;
solve=cube(num_input);   
cout <<"\n\n";                                      
cout<<"\tCube of "<<num_input<<" is "<<solve<<".";
cout <<"\n\n";
cout << "\tEnd of Program";
cout <<"\n\n"; 
getch();
}

// function square

int square(int a)
{
int compute;
compute = a * a;
return(compute);
}
