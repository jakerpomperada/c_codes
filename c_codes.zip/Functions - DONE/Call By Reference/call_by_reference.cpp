/*call_by_reference.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 28,2018  Wednesday 2:30 PM
*/
#include <stdio.h>

int cube (int &);

int main()
{
int a=5;
int b=a;
int display=0;
printf("\n\n");
printf("\tCall By Reference");
display = cube(a);
printf("\n\n");
printf("\tThe given value is %d. The result is %d.",b,display);
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
}

int cube(int &b)
{
	b = b * b * b;
	return(b);
}
