/* fibonacci.c
   Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date      : November 28,2018  Wednesday  3:49 PM
   Location  : Bacolod City, Negros Occidental Philippines.
   Website  : http://www.jakerpomperda.com 
   Emails   : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/ 
#include <stdio.h>
// function prototype 
int fibonacci(int);
int main()
{
int n=0,i=0;
int display_result=0;
printf("\n\n");
printf("\t\tFibonacci Number Generator");
printf("\n\n");
printf("\tGive a Number : ");
scanf("%d",&n);
printf("\n\n"); 
printf("\t===== Fibonacci Series is as follows =====\n");
printf("\n\n");
printf("\t");
while(i<n)
   {
        display_result=fibonacci(i);
        printf(" %d ",display_result);
        i++;
   }
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n"); 
}
  // function declaration
int fibonacci(int n)
{
    if((n==1)||(n==0))
    {
        return(n);
    }
    else
    {
        return(fibonacci(n-1)+fibonacci(n-2));
    }
}
