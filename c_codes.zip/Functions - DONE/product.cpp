/* product.c
   Author     : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date       : November 28, 2018 Wednesday  2:39 PM
  Location   : Bacolod City, Negros Occidental Philippines.
  Website    : http://www.jakerpomperada.com
  Email     : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/
#include <stdio.h> 
int product(int a, int b = 10) 
{
   int result;
   result = (a * b);
   return (result);
}
int main () {
/* local variable declaration: */
int a = 20;
int b = 40;
int result=0;
printf("\n\n"); 
printf("\tCalling of the Same Functions in C");
printf("\n\n"); 
/* calling a function to compute the product. */
result = product(a, b);
printf("\tTotal values is : %d. ",result);
/* calling a function again as follows. */
result = product(a);
printf("\n\n");  
printf("\tTotal value is %d.",result);
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
}


