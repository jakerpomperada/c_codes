/* factorial.c
   Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date      : November 28,2018  Wednesday  3:05 PM
   Location  : Bacolod City, Negros Occidental Philippines.
   Website  : http://www.jakerpomperda.com 
   Emails   : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/   
#include <stdio.h>
 // function prototype declaration  
int factorial(int);  
int main()
{                  
int num_input=0;
int solve=0;
printf("\n\n"); 
printf("\tFactorial a Number Solver");
printf("\n\n"); 
printf("\tGive a Number : ");
scanf("%d",&num_input);
solve= factorial(num_input);   
printf("\n\n");     
printf("\tThe factorial value of %d is %d.",num_input,solve);                               
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n"); 
}
/* function factorial */
int factorial(int a)
{
	int fact=1;
	while(a>=1)
	{
		fact=fact*a;
		a--;
	}
	return fact;
}

 

