/*temperature.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 28,2018  Wednesday 2:48 PM
*/
#include <stdio.h>
float celsius(float temp) 
{
   float result;
   result = (temp - 32) * 5 / 9;
  return (result);
}
int main () {printf("\n\n")
float temp_given=0.00;
float display_result=0.00;
printf("\n\n");
printf("\tFahrenheit into Celsius Converter");
printf("\n\n");  
printf("\tGive Temperature in Fahrenheit : ");
scanf("%f",&temp_given);
display_result = celsius(temp_given);
printf("\n\n");
printf("\tThe temperature in Celsius is %.2f\370C.",display_result);
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
}
   
   
