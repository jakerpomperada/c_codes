/*call_by_value.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 28,2018  Wednesday 10:24 AM
*/
#include <stdio.h>

int cube (int b);

int main()
{
int a=2;
int display=0;
printf("\n\n");	
printf("\tCall By Value");
display = cube(a);
printf("\n\n");	
printf("\tThe given value is %d. The result is %d.",a,display);
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
}

int cube(int b)
{
	b = b * b * b;
	return(b);
}
