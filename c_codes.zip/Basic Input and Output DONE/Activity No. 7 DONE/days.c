/* days.c
Convert days to years weeks and days
Author   : Kristine Trogani Soberano,Ph.D.
Faculty, Northern Negros State College of Science and Technology
Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
Email    : missKsoberano@gmail.com
Tool     : Dev C++ Version 5.11
Date    : November 12, 2018  Monday  6:15 AM
*/

#include <stdio.h>

int main()
{
   int days=0, years=0, weeks=0;

   system("COLOR F0");
   printf("\n\n");
   printf("\tConvert Days to Years, Weeks and Days");
   printf("\n\n");
   printf("\tHow Many Days : ");
   scanf("%d", &days);

    /* Conversion in this portion */
    years = (days / 365);   /* Ignoring leap year */
    weeks = (days % 365) / 7;
    days  = days - ((years * 365) + (weeks * 7));

    printf("\n\n");
    printf("\tDisplay Results");
    printf("\n\n");
    printf("\tNumber of Years : %d\n", years);
    printf("\tNumber of Weeks : %d\n", weeks);
    printf("\tNumber of Days  : %d", days);
 	printf("\n\n\n");
    printf("\tEND OF PROGRAM");
    printf("\n\n");
    }

