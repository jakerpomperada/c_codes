// swap.c
// Swap Two Numbers
// Author   : Kristine Trogani Soberano,Ph.D.
// Faculty, Northern Negros State College of Science and Technology
// Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
// Tool     : Dev C++ Version 5.11
// Email    : missKsoberano@gmail.com
// Date    : November 11, 2018   Sunday  10.40 PM

#include <stdio.h>

int main() 
 {
   int a=0,b=0, temp=0;
	
   system("COLOR F0");
   printf("\n\n");
   printf("\tSwap Two Numbers");
   printf("\n\n");
   printf("\tGive First Value  : ");
   scanf("%d", &a);
   printf("\n");
   printf("\tGive Second Value : ");
   scanf("%d", &b);
   printf("\n\n");
   printf("\tBefore Swapping");
   printf("\n\n");
   printf("\tA = %d and B = %d",a,b);
   
   // Swapping of values here
   temp = a;
   a = b;
   b = temp;
   
   printf("\n\n\n");
   printf("\tAfter Swapping");
   printf("\n\n");
   printf("\tA = %d and B = %d",a,b);
      
   printf("\n\n\n");
   printf("\tEND OF PROGRAM");
   printf("\n\n");
}
