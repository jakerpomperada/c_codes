// add_product.c
// Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
// Date     : November 11, 2018  Sunday 11:02 PM
// Location : Bacolod City, Negros Occidental
// Tool     : Dev C++ Version 5.11
// Website  : http://www.jakerpomperada.com
// Email    : jakerpomperada@jakerpomperada.com

#include <stdio.h>

int main() 
 {
 	
   int a=0,b=0,sum=0,product=0;
	
   system("COLOR F0");
   printf("\n\n");
   printf("\tSum and Product of Two Numbers");
   printf("\n\n");
   printf("\tGive First Number  : ");
   scanf("%d", &a);
   printf("\n");
   printf("\tGive Second Number : ");
   scanf("%d", &b);
   
   // Compute the sum and product
   sum = (a+b);
   product = (a*b);
   
   printf("\n");
   printf("\tThe sum of %d and %d is %d.",a,b,sum);
   printf("\n\n");
   printf("\tThe product of %d and %d is %d.",a,b,product);
   printf("\n\n\n");
   printf("\tEND OF PROGRAM");
   printf("\n\n");
}
