/* time.c
  Seconds to Hours,Minutes and Seconds Converter
  Author   : Kristine Trogani Soberano,Ph.D.
  Faculty, Northern Negros State College of Science and Technology
  Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
  Email    : missKsoberano@gmail.com
  Tool     : Dev C++ Version 5.11
  Date    : November 13, 2018   Tuesday  9:23 PM
*/

#include <stdio.h>

int main()
{

int time=0, hours=0, minutes=0, seconds=0;

system("COLOR F0");
printf("\n\n");
printf("\tSeconds to Hours,Minutes and Seconds Converter");
printf("\n\n");
printf("\tHow many seconds : ");
scanf("%d", &time);

/* Conversion starts here */

hours = time / 3600;
minutes = (time % 3600) / 60;
seconds = ((time % 3600) % 60);

printf("\n\n");
printf("\t===== DISPLAY RESULTS =====");
printf("\n\n");
printf("\tHour(s)   : %d ",hours);
printf("\n");
printf("\tMinute(s) : %d ",minutes);
printf("\n");
printf("\tSecond(s) : %d ",seconds);
printf("\n\n");
printf("\tEND OF PROGRAM");
printf("\n\n");
}
