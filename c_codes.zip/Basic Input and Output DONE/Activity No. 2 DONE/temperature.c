// temperature.c
// Temperature Converter 
// Author   : Kristine Trogani Soberano,Ph.D.
// Faculty, Northern Negros State College of Science and Technology
// Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
// Email    : missKsoberano@gmail.com
// Tool     : Dev C++ Version 5.11
// Date    : November 11, 2018   Sunday  9:16 PM

#include <stdio.h>

int main() 
 {
   float celsius=0.00,fahrenheit=0.00;
	
   system("COLOR F0");
   printf("\n\n");
   printf("\tTemperature Converter");
   printf("\n\n");
   printf("\tGive the temperature in Fahrenheit  : ");
   scanf("%f", &fahrenheit);
   
   celsius = (fahrenheit-32) * 5 / 9;
      
   printf("\n\n");
   printf("\tThe temperature in Celsius is %.2f\370C.",celsius);
   printf("\n\n");
   printf("\tEND OF PROGRAM");
   printf("\n\n");
}
