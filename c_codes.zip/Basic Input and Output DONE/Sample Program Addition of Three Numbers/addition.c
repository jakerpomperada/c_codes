/* addition.c
 Addition of Three Numbers
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 15, 2018   Thursday  6:37 AM
*/

#include <stdio.h>

int main() 
 {
	
  int a=0,b=0,c=0;
  int sum=0;
   
   system("COLOR F0");
   printf("\n\n");
   printf("\tAddition of Three Numbers");
   printf("\n\n");
   printf("\tGive Three Numbers : ");
   scanf("%d%d%d",&a,&b,&c);
 
   sum = (a+b+c);
  
   printf("\n");
   printf("\tThe total sum of %d, %d and %d is %d.",a,b,c,sum);
   printf("\n\n");
   printf("\tEnd of Program");
   printf("\n\n");
  
}
