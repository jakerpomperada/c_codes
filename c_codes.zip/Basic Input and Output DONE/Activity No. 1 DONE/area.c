// area.c
// Area of the Circle Solver
// Author   : Kristine Trogani Soberano,Ph.D.
// Faculty, Northern Negros State College of Science and Technology
// Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
// Tool     : Dev C++ Version 5.11
// Date    : November 11, 2018   Sunday  8:18 PM

#include <stdio.h>

#define PI  3.14

int main() 
 {
	
   float radius=0.00, area=0.00;
   
   system("COLOR F0");
   printf("\n\n");
   printf("\tArea of the Circle Solver in C");
   printf("\n\n");
   printf("\tGive the radius of Circle : ");
   scanf("%f", &radius);
 
   area = (PI * radius * radius);

   printf("\n\n");
   printf("\tThe Area of Circle is %.2f.",area);
   printf("\n\n");
   printf("\tEnd of Program");
   printf("\n\n");
  
}
