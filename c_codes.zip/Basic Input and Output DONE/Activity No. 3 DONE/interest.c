// interest.c
// Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
// Date     : November 11, 2018   9:49 PM
// Location : Bacolod City, Negros Occidental
// Website  : http://www.jakerpomperada.com
// Email    : jakerpomperada@jakerpomperada.com

#include <stdio.h>

int main()
{
    float principal=0.00, time=00;
	float rate=0.00, solve_interest=0.00;
    
	system("COLOR F0");
	printf("\n\n");
    printf("\tLoan Interest Solver");
	printf("\n\n");
    printf("\tEnter Principal Amount PHP : ");
    scanf("%f",&principal);
    printf("\n");
    printf("\tEnter No. of Years  : ");
    scanf("%f",&time);
    printf("\n");
    printf("\tEnter Percent Rate % : ");
    scanf("%f",&rate);
     
    solve_interest = (principal * time * rate) / 100;

 	printf("\n\n");
    printf("\tThe Interest is PHP %.2f.",solve_interest);
    printf("\n\n");
	printf("\tEnd of Program"); 
	printf("\n\n");
  }


