// power.c
// Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
// Date     : November 11, 2018   Sunday 10:25 PM
// Location : Bacolod City, Negros Occidental
// Website  : http://www.jakerpomperada.com
// Email    : jakerpomperada@jakerpomperada.com

#include <stdio.h>
#include <math.h>

int main()
{
    double base=0.00, exponent=0.00, result=0.00;
    
    system("COLOR F0");
	printf("\n\n");
    printf("\tPower of a Number");
    printf("\n\n");
    printf("\tEnter a Base Number : ");
    scanf("%lf", &base);
    printf("\n\n");
    printf("\tEnter an Exponent : ");
    scanf("%lf", &exponent);

    // calculates the power of the number
    result = pow(base, exponent);

	printf("\n\n");
	printf("\tDISPLAY RESULT");
	printf("\n\n");
    printf("\t%.1lf^%.1lf = %.2lf", base, exponent, result);
    printf("\n\n");
	printf("\tEnd of Program"); 
	printf("\n\n");
}
