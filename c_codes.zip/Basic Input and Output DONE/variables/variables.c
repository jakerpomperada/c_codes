/* variables.c
   Written By      : Mr. Jake R. Pomperada,BSCS, MAED-IT
   Date           : November 18, 2018    Sunday  7:53 PM
   Tool           : Dev C++ 5.11
   Location      :  Bacolod City, Negros Occidental
   Email         : jakerpomperada@yahoo.com and jakerpomperada@gmail.com
*/

#include <stdio.h>

int main() {
	
	char full_name[200];
	char position[200];
	int age=0;
	float wage=0.00;
    double yearly_salary=0.00;
	char gender,ch;
	
	printf("\n\n");
	printf("\t Bacolod Software Inc. Employee's Information System"); 
	printf("\n\n");
	printf("\tGive Employee's Name             : ");
	fgets(full_name,200, stdin);
	printf("\tGive Employee's Age              : ");
	scanf("%d",&age);
	ch = getchar (); 
	printf("\tGive Employee's Position         : ");
    fgets(position,200, stdin);
	printf("\tWhat is Employee's Wage          : ");
	scanf("%f",&wage);
	printf("\tWhat is Employee's Yearly Salary : ");
	scanf("%lf",&yearly_salary);
	ch = getchar (); 
	printf("\tWhat is Employee's Gender        : ");
    scanf("%c",&gender);
	
	printf("\n\n");
	printf("\t ===== DISPLAY RESULT =====");
	printf("\n\n");
	printf("\t Employee's Name           : %s",strupr(full_name));
	printf("\t Employee's Age            : %d\n " ,age);
	printf("\t Employee's Position       : %s" ,strupr(position));
	printf("\t Employee's Wage           : PHP %.2f\n" ,wage);
	printf("\t Employee's Yearly Salary  : PHP %.2lf\n" ,yearly_salary);
	printf("\t Employee's Gender         : %c\n" ,toupper(gender));
    printf("\n\n");
	printf("\t ===== END OF PROGRAM =====");
    printf("\n\n");
	return 0;
}


