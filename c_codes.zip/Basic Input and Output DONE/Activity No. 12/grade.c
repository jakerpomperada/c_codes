/* grade.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 13, 2018  Tuesday 9:44 PM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com
*/

#include <stdio.h>

int main() 
 {
  float solve_average=0.00;
  float prelim=0.00,midterm=0.00,final=0.00;
  
  system("COLOR F0");
  printf("\n\n");
  printf("\tAverage Grade Solver");
  printf("\n\n");
  printf("\tGive Prelim Grade   : ");
  scanf("%f",&prelim);
  printf("\tGive Midterm Grade  : ");
  scanf("%f",&midterm);
  printf("\tGive Final Grade    : ");
  scanf("%f",&final);

  solve_average =(prelim+midterm+final)/3;

  printf("\n\n");
  printf("\t===== DISPLAY RESULTS =====");
  printf("\n\n");
  printf("\tThe student average grade is %.2f.",solve_average);
  printf("\n\n");
  printf("\tEND OF PROGRAM");
  printf("\n\n");
}



