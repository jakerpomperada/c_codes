
/* amount.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 13, 2018  Tuesday 6:22 AM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com
*/

#include <stdio.h>

int main() 
 {
 	
  int amt=0,thousand=0,five_hund=0,two_hundreds=0;
  int hundreds=0,fifty=0,twentys=0;
	
   system("COLOR F0");
   printf("\n\n");
   printf("\tMoney Denomination Determiner");
   printf("\n\n");
   printf("\tGive the amount of money : PHP "); 
   scanf("%d",&amt);
   printf("\n");
 
   /* Conversion start here */
   
  thousand = amt/1000;
  amt = amt%1000;
  five_hund = amt/500;
  amt = amt%500;
  two_hundreds = amt/200;
  amt = amt%200;
  hundreds = amt/100;
  amt = amt%100;
  fifty = amt/50;
  amt = amt%50;
  twentys = amt/20;
  amt = amt%20;
   
   printf("\t===== DISPLAY RESULT =====");
   printf("\n\n");
   printf("\tNumber of 1000 Pesos notes: %d.\n",thousand);
   printf("\tNumber of 500 Pesos notes: %d.\n",five_hund);
   printf("\tNumber of 200 Pesos notes: %d.\n",two_hundreds);
   printf("\tNumber of 100 Pesos notes: %d.\n",hundreds);
   printf("\tNumber of 50 Pesos notes: %d.\n",fifty);
   printf("\tNumber of 20 Pesos notes: %d.\n",twentys);
   printf("\n\n");
   printf("\tEND OF PROGRAM");
   printf("\n\n");
}
