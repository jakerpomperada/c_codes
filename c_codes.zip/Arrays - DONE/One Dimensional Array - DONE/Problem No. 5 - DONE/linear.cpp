 /* linear.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 29, 2018  Thursday  9:36 PM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/
#include <stdio.h>
 
int main()
{
	int arr[10],b=0;
	int num_input=0;
    int c=0, pos=0;
    printf("\n\n");
    printf("\t\tLinear Search in C");
    printf("\n\n");
	printf("\tEnter the array size : ");
	scanf("%d",&num_input);
    printf("\n");
	printf("\tEnter Array Elements : ");
	for(b=0; b<num_input; b++)
	{
	    scanf("%d",&arr[b]);
	}
    printf("\n\n"); 
	printf("\tEnter the number to be search : ");
	scanf("%d",&num_input);
	for(b=0; b<num_input; b++)
	{
		if(arr[b]==num_input)
		{
			c=1;
			pos=b+1;
			break;
		}
	}
	if(c==0)
	{
	printf("\n\n");
	printf("\tSorry the number %d is not found from the list.",num_input);
	}
	else
	{
		printf("\n\n");
	    printf("\tThe number %d found at position %d.",num_input,pos);
	}
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
  } // End of Code
