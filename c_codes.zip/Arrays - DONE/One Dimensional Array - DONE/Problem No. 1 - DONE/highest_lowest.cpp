/* highest_lowest.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 29, 2018  Thursday  3:35 PM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/
#include <stdio.h>
int main ()
{
    int arr[20], b=0, max=0, min=0;
    printf("\n\n"); 
    printf("\t\tHighest and Lowest Value Checker");
    printf("\n\n");
    printf("\tHow many items to be process? : ");
    scanf("%d",&b);
    printf("\n\n");
    printf("\tEnter items values : ");
    for (int a = 0; a < b; a++){
	     scanf("%d",&arr[a]);
      }
        max = arr[0];
    for (int a = 0; a < b; a++)
    {
        if (max < arr[a])
            max = arr[a];
    }
    min = arr[0];
    for (int a = 0; a < b; a++)
    {
        if (min > arr[a])
            min = arr[a];
    }
    printf("\n\n");
    printf("\t===== DISPLAY RESULT =====");
    printf("\n\n");
    printf("\tThe Largest Value is %d.",max);
    printf("\n\n");
    printf("\tThe Smallest Value is %d.",min);
    printf("\n\n");
 	printf("\tEnd of Program");
 	printf("\n\n");
}
