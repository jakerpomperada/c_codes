/*pass_fail.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 29, 2018  Thursday 8:05 PM
*/
#include <stdio.h>

int grades[6],a=0;
int count_pass=0, count_fail=0;

void display_title(void);
void get_data(void);
void display_pass(void);
void display_fail(void);
void display_result(void);

void display_title(void)
{
     printf("\n\n");
	 printf("\t\tStudent Grades Checker");
     printf("\n\n\n");
}

void get_data(void)
{
  for (a=1; a<=5; a+=1) {
  	      printf("\tEnter Grade No. %d : ",a);
  	      scanf("%d",&a[grades]);
      }
}

void display_pass(void)
{
     printf("\n\n");
     printf("\tList of PASSED Grades ");
     printf("\n\n");
        for (a=1; a<=5; a+=1) {
          if (a[grades] >= 75) {
          	printf("\t %d ",a[grades]);
               count_pass++;
              }
         }
  }

void display_fail(void)
{
      printf("\n\n");
      printf("\tList of FAILED Grades ");
      printf("\n\n");
       for (a=1; a<=5; a+=1) {

           if (a[grades] < 75) {
               printf("\t %d ",a[grades]);
              count_fail++;
              }
       }
}

void display_result(void)
{
printf("\n\n");
printf("\tNumber of Passed Grades => %d ",count_pass);
printf("\n\n");
printf("\tNumber of Failed Grades => %d ",count_fail);
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
}
 int main() {
    display_title();
    get_data();
    display_pass();
    display_fail();
    display_result();
    }
 // End of Code

