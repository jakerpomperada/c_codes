 /* average.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 29, 2018  Thursday  9:28 PM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/
 #include <stdio.h>
 
 int main() {
     int numbers[5];
     int a=0,solve=0,sum=0;
     printf("\n\n");
     printf("\tAverage Grade Solver");
     printf("\n\n");
     for (a=0; a<=4; a+=1) {
         printf("\tEnter Grade No. %d : ",a+1);
         scanf("%d",&a[numbers]);    
     }
    printf("\n\n");
     for (a=0; a<=4; a+=1) {
         sum = sum + a[numbers];
         solve =( sum / 5);
     }
    printf("\tThe average grades is %d. ",solve);
    printf("\n\n");
      if (solve >=75) {
      	  printf("\n");
          printf("\tYou Passed the subject");
      }
      else {
      	  printf("\n");
          printf("\tYou Failed the subject");
      }
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
 }

