/*odd_even.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 29, 2018  Thursday 8:05 PM
*/
#include <stdio.h>
int a=0,r=0,data=0,b=0;
int values[10];
void get_data();
void display_even();
void display_odd();

void get_data(void)
{
    printf("\n\n");
    printf("\tODD and Even Numbers Checker");
	printf("\n\n"); 
    printf("\tHow Many Items To Be Process? :  ");
    scanf("%d",&data);
    printf("\n"); 
       for (b=1; b <= data; b++)
            {
            printf("\tEnter Item No. %d : ",b);
            scanf("%d",&b[values]);
            }
}

void display_even(void)
{
    printf("\n\n");
    printf("\tList of Even Numbers : ");
    printf("\n\n");
        for (a=1; a<=data; a++) {
            r = a[values] % 2;
            if (r ==0) {
            	printf("\t %d ",a[values]);
         }
     }
}

void display_odd(void)
 {
    printf("\n\n");
    printf("\tList of Odd Numbers : ");
    printf("\n\n");
     for (a=1; a<=data; a++) {
         r = a[values] % 2;
         if (r!=0) {
          printf("\t %d ",a[values]);
         }
     }
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
 }
int main() {
     get_data();
     display_even();
     display_odd();
 }


