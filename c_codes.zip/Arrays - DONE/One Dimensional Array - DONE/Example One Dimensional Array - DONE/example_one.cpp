/*example_array.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 29, 2018  Thursday 2:51 PM
*/
#include <stdio.h>
using namespace std;
int main()
{
int score[5] = {5,10,15,20,25};
int a=0;
printf("\n\n");
printf("\tOne Dimensional Array Demonstration");
printf("\n\n");
for(a=0; a<5; a++)
{
 printf("\t");
 printf("score[%d]  = %d\n ",a+1,score[a]);
}
 printf("\n\n");
 printf("\tEnd of Program");
 printf("\n\n");
}
