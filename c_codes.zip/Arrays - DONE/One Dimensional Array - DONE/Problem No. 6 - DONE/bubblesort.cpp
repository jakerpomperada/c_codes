/*bubblesort.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 29, 2018  Thursday 9:49 PM
*/
#include <stdio.h>
 
int main()
{
    int items[50],num_input,a=0,b=0,temp=0;
    printf("\n\n");
    printf("\tBubble Sort in C");
    printf("\n\n");
    printf("\tGive the size of array: ");
    scanf("%d",&num_input);
    printf("\n\n");
    printf("\tGive the array elements: ");
    for(a=0;a<num_input;a++) 
	{
	    scanf("%d",&items[a]);
    }
    printf("\n\n");
    printf("\tOriginal Array Arrangement");
    printf("\n\n");
    for(a=0;a<num_input;a++) {
	   printf("\t %d ",items[a]);    
    }    
   for(a=1;a<num_input;a++)
    {
        for(b=0;b<(num_input-a);b++)
            if(items[b]>items[b+1])
            {
                temp=items[b];
                items[b]=items[b+1];
                items[b+1]=temp;
            }
    }
  	printf("\n\n");
    printf("\tSorted Array Arrangement");
    printf("\n\n");
    for(a=0;a<num_input;a++) {
	   printf("\t %d ",items[a]);      
    }
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n");
}
