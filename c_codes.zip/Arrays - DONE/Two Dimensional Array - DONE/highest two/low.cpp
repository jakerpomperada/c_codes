/* Checks Highest and Lowest From 10 numbers*/
// Date Modified : November 29, 2009
// Sunday

// Created By: Mr. Jake Rodriguez Pomperada, MAED-Instructioanl Technology
// Email Address : jakerpomperada@yahoo.com

#include <iostream>
#include <cctype>

using namespace std;

 main()
{
	char reply;

	 do {
	int values[5][2],high=0,low=0, sum=0;

		cout<<"\n\n";
		cout<<"\t\tHighest and Lowest Number Checker 3.0";
		cout<<"\n\n\t      Created By: Mr. Jake R. Pomperada,MAED-IT";
		cout<<"\n\n";


       for (int row=0; row <5; row++) {
         for ( int col=0; col <2; col++) {
		{

			cout<<"Enter a value : ";

			cin>>values[row] [col];
	      sum+=values[row][col];
		}
     }

		high=values[0][0];
	   for (int row=0; row <5; row++) {
         for ( int col=0; col <2; col++) {

			if(high<values[row][col])
			{
				high=values[row][col];
			}
		}
	   }
		low=high;

for (int row=0; row <5; row++) {
         for (int col=0; col <2; col++) {

			if(low>values[row][col])
			{
				low=values[row][col];
			}
	 	}

     }


	}	// check for highest value
		cout<<"\nThe highest number is = "<<high;
		cout<<"\n";
		cout<<"The lowest number is = "<<low;
		cout<<"\n";
		cout<<"The Total Sum of Values is = "<<sum;
		cout<<"\n\n";
		cout<<"Do You want to Continue y/n :=> ";
		cin>>reply;

	 } while (toupper(reply) == 'Y');
	if (toupper(reply)== 'N')
	{
      cout << "\n\n";
      cout << "\t Thank You for Using This Program";
      cout << "\n\n";
	}
 system("PAUSE");
}
