/* input_demo.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 29,2018  Thursday  10:06 PM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/
#include <stdio.h>

int main(){
   /* Two Dimensional array declaration*/
   int score[3][3];
   /*Counter variables for the loop*/
   int i=0, j=0;
   printf("\n\n");
   printf("\tUser Input Demonstration in Two Dimensional Array in C");
   printf("\n\n");
   
   for(i=0; i<3; i++) {
      for(j=0;j<3;j++) {
      	printf("\tEnter element [%d][%d] : ",i,j);
      	scanf("%d",&score[i][j]);
      }
  }
      printf("\n\n");
      printf("\t===== DISPLAY RESULT =====");
      printf("\n\n");
      for(i=0; i<3; i++) {
      for(j=0;j<3;j++) {
      	printf("\tScore [%d][%d] : %d \n",i,j,score[i][j]);
      }
   }
printf("\n\n");
printf("\tEnd of Program");
printf("\n\n"); 
}
