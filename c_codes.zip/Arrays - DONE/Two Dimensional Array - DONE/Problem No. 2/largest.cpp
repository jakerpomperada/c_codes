/*biggest.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 30, 2018  Friday 6:38 AM
*/
#include <stdio.h>
int main(){
   int large=0, arr[100][1], size=0, i=0;
   printf("\n\n");
   printf("\tBiggest Number in the List");
   printf("\n\n");
   printf("\tEnter Array Size (max 100) : ");
   scanf("%d",&size);
   printf("\n\n");
   printf("\tEnter array elements : ");
	for(i=0; i<size; i++)
	{
		scanf("%d",&arr[i][1]);
	}
	printf("\n\n");
	printf("\tSearching for largest number .....");
	printf("\n\n");
	large=arr[0][1];
	for(i=0; i<size; i++)
	{
		if(large<arr[i][1])
		{
			large=arr[i][1];
		}
	}
	printf("\t===== DISPLAY RESULT =====");
	printf("\n\n");
	printf("\tThe Largest Number is %d.",large);
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}
