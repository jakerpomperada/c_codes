/*leap.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 30, 2018  Friday 7:28 AM
*/
#include <stdio.h>
int main()
{
int years[4][2];
int counter=0;
printf("\n\n");
printf("\n\n\t\t\t LEAP YEAR LISTER 1.O");
printf("\n\n");
for (int row=0; row <4; row++) {
    for (int col=0; col <2; col++) {	 
        printf("\tGive Year Number %d : ",(counter)+1);
        scanf("%d",&years[row][col]);
        ++counter;    
    }
 }
 printf("\n\n");
// Leap Year
printf("\tLIST OF LEAP YEAR");
printf("\n\n");
printf("\t");
for (int row=0; row <4; row++) {
  for (int col=0; col <2; col++) {
	if (years[row][col]%4==0)
	{
	printf(" %d ",years[row][col]);
	}
  }
}
printf("\n\n");
/* not a leap year */
printf("\tLIST OF NOT A LEAP YEAR");
printf("\n\n");
printf("\t");
for (int row=0; row <4; row++) {
    for (int col=0; col <2; col++) {
        if (years[row][col]%4==0)
{
}
  else {
      printf(" %d ",years[row][col]);
    }
  }
}
 printf("\n\n");
 printf("\t\t     End of Program");
 printf("\n\n");
}



