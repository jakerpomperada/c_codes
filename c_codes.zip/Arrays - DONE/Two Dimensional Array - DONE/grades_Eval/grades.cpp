#include <iostream>
#include <iomanip>

using namespace std;

main() {
     int grades[5][1],pass=0,failed=0,out_range=0;
     int row=0, col=0;
     string remarks;
     char letter_grade;

     cout << "\t Grades Evaluator Version 1.0";
     cout << "\n\n Created By: Mr. Jake Rodriguez Pomperada,MAED-IT";
     cout << "\n\n";
     
     for ( row=0; row < 5; row++) {
       for  (col=0; col < 1; col++) {
         cout << "Enter grade : " ;
         cin >> grades[row][col];
     }
}
    
  // Code to check for remarks
cout <<"\n" << setw(5) << "GRADES" <<
               setw(7) << " EQUIV " <<
               setw(10) << "REMARKS";
    cout << "\n\n";

     for ( row=0; row < 5; row++) {
       for (col=0; col < 1; col++) {

         if (grades[row][col] >= 75) {
             remarks = "PASSED";
             pass++;
         }
         else if (grades[row][col] < 50)
         {
           remarks= " Error Out of Range ";
           out_range++;
         }

         else  if (grades[row][col] < 75){
                 remarks = "FAILED";
                 failed++;
         }
 


  // Letter Grade Equivalent

     if (grades[row][col] >= 90 &&  grades[row][col] <= 100  ) {
           letter_grade = 'A';
         }
         else if (grades[row][col] >= 80 && grades[row][col] <= 89  ) {
           letter_grade = 'B';
         }
         else if (grades[row][col] >= 70 && grades[row][col] <= 79  ) {
           letter_grade = 'C';
         }
         else if (grades[row][col] >= 60 && grades[row][col] <= 69  ) {
           letter_grade = 'D';
         }
        else if (grades[row][col] >= 50 && grades[row][col] <= 59  ) {
           letter_grade = 'F';
         }
        else if (grades[row][col] < 50) {
            letter_grade = 'X';

         }

        cout <<"\n" << setw(5) << grades[row][col]
              << setw(6) << letter_grade << setw(12)
              << remarks;  
     } 
 }
      

     cout << "\n\n";
     cout << "\nNumber of Passed Grades " << pass << ".";
     cout << "\nNumber of Failed Grades " << failed << ".";
     cout << "\nNumber of Out of Range Grades "<< out_range << ".";
     cout << "\n\n";
     system("PAUSE"); 
 
}

