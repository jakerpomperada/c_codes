/*grades.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 30, 2018  Friday 7:40 AM
*/
#include <stdio.h>
main() {
     int grades[8][1],pass=0,failed=0,out_range=0;
     int row=0, col=0, counter=0;
     char *remarks[]={"PASSED","Error Out of Range","FAILED"};
     char *display;
     char letter_grade;
     printf("\n\n");
     printf("\t Grades Evaluator Using 2D Array");
     printf("\n\n");
     for ( row=0; row < 8; row++) {
       for  (col=0; col < 1; col++) {
         printf("\tEnter Grade Number %d : ",counter+1);
         scanf("%d",&grades[row][col]);
         counter++;
     }
}
    printf("\n\n");
	printf("\t  GRADES   \tEQUIV   \tREMARKS");
    printf("\n");
     for ( row=0; row < 8; row++) {
       for (col=0; col < 1; col++) {
         if (grades[row][col] >= 75) {
             display = remarks[0];
             pass++;
         }
         else if (grades[row][col] < 50)
         {
           display = remarks[1];
		   out_range++;
         }
         else  if (grades[row][col] < 75){
           display = remarks[2];
           failed++;
         }
   // Letter Grade Equivalent
     if (grades[row][col] >= 90 &&  grades[row][col] <= 100  ) {
           letter_grade = 'A';
         }
         else if (grades[row][col] >= 80 && grades[row][col] <= 89  ) {
           letter_grade = 'B';
         }
         else if (grades[row][col] >= 70 && grades[row][col] <= 79  ) {
           letter_grade = 'C';
         }
         else if (grades[row][col] >= 60 && grades[row][col] <= 69  ) {
           letter_grade = 'D';
         }
        else if (grades[row][col] >= 50 && grades[row][col] <= 59  ) {
           letter_grade = 'F';
         }
        else if (grades[row][col] < 50) {
            letter_grade = 'X';
         }
        printf("\n\t %4d  \t\t %c \t\t%s ",grades[row][col],letter_grade,display);
       } 
 }
     printf("\n\n");
     printf("\t===== DISPLAY RESULT =====");
     printf("\n");
     printf("\n\tNumber of Passed Grades  %d.",pass);
     printf("\n\tNumber of Failed Grades  %d.",failed);
     printf("\n\tNumber of Out of Range Grades %d.",out_range);
     printf("\n\n");
 	 printf("\t\tEnd of Program");
     printf("\n\n");
 }


