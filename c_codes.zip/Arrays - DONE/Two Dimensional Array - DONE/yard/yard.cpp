#include <iostream>
#include <iomanip>

using namespace std;

main() {
    int yards[5][1];

    cout << "\t\t    Yard To Feet Lister 1.0";
    cout << "\n";
    cout << "\t Created By: Mr. Jake R. Pomperada,MAED-IT";
    cout << "\n\n";

       for (int row=0; row < 5; row++) {
           for (int col=0; col <1; col++) {
               cout << "Enter a Value in Yard :=> ";
               cin >> yards[row][col];
           }
       }

       cout << "\n=============================";
       cout << "\n      GENERATED REPORT     ";
       cout << "\n=============================";
       cout << "\n";
       for (int row=0; row < 5; row++) {
           for (int col=0; col <1; col++) {
                 cout << "\n" <<setw(5) <<  yards[row][col] <<
                 " yard(s)" << setw(5)  << " ==> "
                 << (yards[row][col] * 3)
                 << " feet(s)";
                  }

       }
       cout << "\n\n";
       system("PAUSE");
}
