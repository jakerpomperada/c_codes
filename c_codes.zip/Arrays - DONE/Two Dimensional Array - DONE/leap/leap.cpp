#include <iostream>

using namespace std;


 main()
{

int years[2][2];

  cout << "\n\n\t\t\t LEAP YEAR LISTER 1.O";
  cout << "\n\n";
for (int row=0; row <2; row++) {
    for (int col=0; col <2; col++) {
        cout << "Enter Year :=> ";
        cin >> years[row][col];
    }
}
cout << "\n\n";
// Leap Year
cout << "LIST OF LEAP YEAR";
cout << "\n\n";
for (int row=0; row <2; row++) {
    for (int col=0; col <2; col++) {

if (years[row][col]%4==0)
{
cout << " " << years[row][col] << " ";
}

    }
}

cout << "\n\n";
// not a leap year
cout << "LIST OF NOT A LEAP YEAR";
cout << "\n\n";
for (int row=0; row <2; row++) {
    for (int col=0; col <2; col++) {
        if (years[row][col]%4==0)
{

}
  else {
      cout << " " << years[row][col] << " ";
    }
  }
}
cout << "\n\n";
system("PAUSE");
}


