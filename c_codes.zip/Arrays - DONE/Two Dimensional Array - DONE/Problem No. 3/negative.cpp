/*positive_negative.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 30,2018  Friday 7:18 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
int values[3][2];
int negative=0,positive=0;
int counter=1,row=0,col=0;
main() {
  printf("\n\n");
  printf("\tCount Positive and Negative Numbers");
  printf("\n\n");
    for ( row=0; row<3; row++) {
        for ( col=0; col<2; col++) {
          printf("\tEnter Item No. %d : ",counter++);
          scanf("%d",&values[row][col]);
        }
    }
    for (row=0; row<3; row++) {
        for ( col=0; col<2; col++) {
       if (values[row][col] >=0) {
           positive++;
       }
      else if   (values[row][col] <0) {
           negative++;
       }
        }
    }
    printf("\n\n");
    printf("\t===== DISPLAY RESULT =====");
	printf("\n\n");
    for ( row=0; row<3; row++) {
        for ( col=0; col<2; col++) {
    if (values[row][col] >=0) {
 			printf("\t %d ",values[row][col]);
         }
        }
    }
    printf("\n\n");
    printf("\tNumber of Postive Numbers : %d",positive);
    printf("\n\n");
    for ( row=0; row<3; row++) {
        for ( col=0; col<2; col++) {
    if (values[row][col] <0) {
           printf("\t %d ",values[row][col]);
           }
        }
    }
    printf("\n\n");
    printf("\tNumber of Negative Numbers : %d",negative);
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
   }

