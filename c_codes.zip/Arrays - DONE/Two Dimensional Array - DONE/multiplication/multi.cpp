#include <iostream>
#include <iomanip>

using namespace std;

int numbers[10][1] = {1,2,3,4,5
                  ,6,7,8,9,10};


main() {

     cout <<setw(31) << " MULTIPLICATION TABLE ";
     cout << "\n\n";
     for (int row1=0; row1 < 10; row1++ ) {
     for (int col1=0; col1 < 1; col1++ ) {
           cout << "\n";
          for (int row2=0; row2 < 10; row2++ ) {
           for (int col2=0; col2 < 1; col2++ )  {
               cout << setw(4) <<
                 numbers[row2][col2] * numbers[row1][col1];
                }
           } // Two Inner Loop
      } // Two Outter Loop
  }
    cout << "\n\n";
    system("PAUSE");
}
