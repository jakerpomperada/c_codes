#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int values[3][2], running_sum=0;
    
     cout << "\t\t RUNNING SUM VERSION 1.0";
     cout << "\n";
     cout << "\tCreated By: Mr. Jake R. Pomperada, MAED-IT"; 
          cout << "\n";
      for (int row=0; row< 3; row++) {
           for (int col=0; col< 2; col++) {

            cout << "\nEnter a Number :=> ";
            cin >> values[row][col];
          
            running_sum+=values[row][col];
            cout << "\nThe running sum is " <<       
                    running_sum << ".";
             }
             }
         cout << "\n\n";                     
    system("PAUSE");
    return EXIT_SUCCESS;
}
