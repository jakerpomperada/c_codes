/*pos_neg.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 30, 2018  Friday 6:23 AM
*/
#include <stdio.h>
int main()
{
	int countp=0, countn=0, countz=0, arr[10][1], i=0;
	printf("\n\n");
    printf("\tCount Positive, Zero and Negative Numbers ");
    printf("\n\n");
	printf("\tEnter ten numbers : ");
	printf("\n\n");
	for(i=0; i<10; i++)
	{
		printf("\tGive value in item no. %d : ",i+1);
		scanf("%d",&arr[i][0]);
	}
	for(i=0; i<10; i++)
	{
		if(arr[i][0]<0)
		{
			countn++;
		}
		else if(arr[i][0]==0)
		{
			countz++;
		}
		else
		{
			countp++;
		}
	}
	printf("\n\n");
	printf("\t===== DISPLAY RESULTS =====");
	printf("\n\n");
	printf("\tNumber of Positive Numbers : %d\n",countp);
	printf("\tNumber of Negative Numbers : %d\n",countn);
	printf("\tNumber of Zero             : %d",countz);
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}
