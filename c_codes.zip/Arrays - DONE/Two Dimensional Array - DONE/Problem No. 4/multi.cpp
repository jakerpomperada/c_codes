/*multiplication.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 30,2018 Friday 7:20 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
int numbers[10][1] = {1,2,3,4,5
                  ,6,7,8,9,10};
main() {
     printf("\n\n");
	 printf("\t    MULTIPLICATION TABLE USING 2D ARRAY ");
     printf("\n\n");
     printf("\t");
     for (int row1=0; row1 < 10; row1++ ) {
     for (int col1=0; col1 < 1; col1++ ) {
          printf("\n");
          printf("\t");
          for (int row2=0; row2 < 10; row2++ ) {
           for (int col2=0; col2 < 1; col2++ )  {
               printf("%4d",numbers[row2][col2] * numbers[row1][col1]);
                }
           } // Two Inner Loop
      } // Two Outter Loop
  }
    printf("\n\n");
    printf("\t\t     End of Program");
    printf("\n\n");
}
