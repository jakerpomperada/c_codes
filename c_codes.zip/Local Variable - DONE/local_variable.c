/* local_variable.c
  Local Variable Program
  Author   : Kristine Trogani Soberano,Ph.D.
  Faculty, Northern Negros State College of Science and Technology
  Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
  Email    : missKsoberano@gmail.com
  Tool     : Dev C++ Version 5.11
  Date    : November 19, 2018   Monday  6:40 AM
*/

#include <stdio.h>

int main()

    {
     // Local variable declaration
    int a=0, b=0;
    int product=0;
     // actual variable initialization by assigning values.
     a = 5;
     b =  10;
     product = ( a * b);
     printf("\n\n");
     printf("\tLocal Variable Declaration Program");
     printf("\n\n");
     printf("\tThe product of %d and %d is %d.",a,b,product);
     printf("\n\n");
     printf("\tEnd of Program");
     printf("\n\n");
     return 0;
}

