#include <stdio.h>
#include <conio.h>

int main()

{
int bill500=0, bill200=0, bill100=0, total_balance=0;
int withdraw=0, money_left=0;
int reciv500=0, reciv200=0, reciv100=0;
char withdraw_again[2] = "N";

	     printf("\n\n");
         printf("\t Automatic Teller Machine Simulation in C");
		 printf("\n\n");
		 printf("\tHow many P500 bills: ");
		 scanf("%d", &bill500);
		 printf("\tHow many PHP 200 bills: ");
		 scanf("%d", &bill200);
		 printf("\tHow many PHP 100 bills: ");
		 scanf("%d", &bill100);
		 total_balance = 	(bill500 * 500) + (bill200 * 200) +  (bill100 * 100) ;

		 printf("\tTotal Balance: PHP %d", total_balance);

	 do

	 {
		 printf("\n");
		 printf("\n");

		 printf("\tEnter amount to withdraw: PHP ");
		 scanf("%d", &withdraw);
		 money_left = withdraw ;

		 if  (withdraw > total_balance)
				{
				printf("\tWithdraw amount greater than total balance.  ");
				printf("\n");
				}
		 if (withdraw < total_balance)
		 {
		 if  (money_left >= 500 )
				{
				 reciv500 = int(money_left / 500);
				 if (reciv500 > bill500 ) reciv500 = bill500;

				 money_left = money_left - (reciv500 * 500);
				 bill500 = bill500 - reciv500;
				}

		 if (money_left >= 200 )
			 {
				 reciv200 = int(money_left / 200);
				 if (reciv200 > bill200 ) reciv200 = bill200;
				 money_left = money_left - (reciv200 * 200);
				 bill200 = bill200 - reciv200;
			 }

		 if (money_left >= 100 )
			  {
				 reciv100 = int(money_left / 100);
				 if (reciv100 > bill100 ) reciv100 = bill100;
				 money_left = money_left - (reciv100 * 100);
				 bill100 = bill100 - reciv100;
				}

				printf("\n");
				printf("\n");
				printf("\tYou will receive:");
				printf("\n");
				printf("\t%d  PHP 500 bill", reciv500);
				printf("\n");
				printf("\t%d  PHP 200 bill", reciv200);
				printf("\n");
				printf("\t%d  PHP 100 bill", reciv100);
				printf("\n");


				total_balance = total_balance - withdraw;

				printf("\tYour current balance is: PHP %d", total_balance);

				printf("\n");
				printf("\n");
				printf("\tYou only have balance of:");
				printf("\n");
				printf("\t%d  PHP 500 bill", bill500);
				printf("\n");
				printf("\t%d  PHP 200 bill", bill200);
				printf("\n");
				printf("\t%d  PHP 100 bill", bill100);
				printf("\n");
 				printf("\n\n");
				printf("\tAnother Withdraw Again ? Y/N : ");
				scanf("%s", &withdraw_again);

		 }

	 }  while (withdraw_again == "Y" || withdraw_again == "y" );
     printf("\n\n");
     printf("\tEnd of Program");
     printf("\n\n");
}
