/*  incre_decre.c
  Enum Example Program
  Author   : Kristine Trogani Soberano,Ph.D.
  Faculty, Northern Negros State College of Science and Technology
  Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
  Email    : missKsoberano@gmail.com
  Tool     : Dev C++ Version 5.11
  Date    : November 19, 2018   Monday  10:57 AM
*/

#include <stdio.h>

int main() {
   	 
   	int a=0,b=0;

	a=9;
	b = a++ + 5;  /* a=10  b=14 */
	printf("\n");
  	printf("\tConditional ternary operator ( ? )");
  	printf("\n\n");
	printf("The result is of a = %d and b = %d",a,b);
	printf("\n\n");
	a = 3;
	b = ++a + 6; /* a = 4 b = 10 */
	printf("\n\n");
	printf("The result is of a = %d and b = %d",a,b);
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}

