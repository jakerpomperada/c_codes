/*replace.c
 Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
 Date      : December 1, 2018  Saturday 7:41 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
#include <string.h>
int main()
{
	char str[100],s[100],r[100],result[100];
	int a=0,b=0,c=0,m=0,k=0;
 	printf("\n\n");
    printf("\tSearch and Replace a String");
    printf("\n\n");
    printf("\tGive a String : ");
    gets(str);
    printf("\n");	
    printf("\tGive the string to be search : ");
    gets(s);
    printf("\n");
    printf("\tEnter replace string : ");
    gets(r);
	a = m = c = b = 0;
	while ( str[c] != '\0')
	{
		if (str[m] == s[a] ) 
		{
			a++;
			m++;
		if ( s[a] == '\0') 
		{
	
		for(k=0; r[k] != '\0';k++,b++)
			result[b] = r[k];
			a=0;
			c=m;
		}
		}
		else 
		{
			result[b] = str[c];
			b++;
			c++;
			m = c;
			a=0;
		}
	}
    result[b] = '\0';
	printf("\n\n");
	printf("\tDISPLAY RESULT");
    printf("\n\n");
	printf("\tThe result string :=> %s",result);
	printf("\n\n");
	return 0;
} // End of Program
