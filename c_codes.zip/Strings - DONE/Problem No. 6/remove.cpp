/*remove.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : December 1, 2018  Saturday 9:50 AM
*/
#include <stdio.h>
#include <stdlib.h>
int main(){
   char str[200];
    printf("\n\n");
    printf("\tRemove Vowels in a String");
    printf("\n\n");
    printf("\tGive a String : ");
    gets(str);
    printf("\n\n"); 
    printf("\tDISPLAY RESULT");
    printf("\n\n"); 
    printf("\tOriginal String : %s ",str);
    for(int z=0; str[z]!='\0'; z++) 
        {
       if (str[z]=='a' || str[z]=='e' || str[z]=='i' ||
	    str[z]=='o' || str[z]=='u' || str[z]=='A' ||
	    str[z]=='E' || str[z]=='I' || str[z]=='O' || str[z]=='U') 
                {
                  str[z]=' ';
                }
        }
    printf("\n\n");    
    printf("\tString After Deleting Vowels : %s ",str);
    printf("\n\n");
    printf("\tThank you for Using This Software.");
    printf("\n\n");
    system("PAUSE");
}


