/*demo.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 30, 2018  Friday 8:59 AM
*/
#include <stdio.h>
int main () {
   char str1[10] = "Kristine";
   char str2[10] = "Somberano";
   char str3[10];
   int  len ;
   // copy str1 into str3
   strcpy( str3, str1);
   printf("\n\n");
   printf("\tstrcpy(str3, str1) : %s ",str3);
   printf("\n");
   // concatenates str1 and str2
   strcat( str1, str2);
   printf("\tstrcat( str1, str2): %s  ",str1);
      // total lenghth of str1 after concatenation
   len = strlen(str1);
   printf("\n");
   printf("\tstrlen(str1) :  %d ",len);
   printf("\n\n");
   printf("\t\tEnd of Program");
   printf("\n\n");
}

