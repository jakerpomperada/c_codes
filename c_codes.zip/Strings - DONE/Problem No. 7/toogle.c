/*toogle.c
 Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
 Date      : December 1, 2018  Saturday 10:32 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
  	char Str1[200];
  	int i=0;
 	printf("\n\n");
 	printf("\t\tToggle a String");
	printf("\n\n");
  	printf("\tEnter any String to Toggle :  ");
  	gets(Str1);
  	for (i = 0; Str1[i]!='\0'; i++)
  	{
  		if(Str1[i] >= 65 && Str1[i] <= 90)
  		{
  			Str1[i] = Str1[i] + 32;
		}
		else if(Str1[i] >= 97 && Str1[i] <= 122)
  		{
  			Str1[i] = Str1[i] - 32;
		}
  	}
  	printf("\n");
  	printf("\tThe Given String after Toggling Case of all Characters");
  	printf("\n\n");
  	printf("\t%s",Str1);
  	printf("\n\n");
    printf("\tThank you for Using This Software.");
    printf("\n\n");
    system("PAUSE");
 
}
