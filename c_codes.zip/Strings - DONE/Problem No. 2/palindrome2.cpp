/*palindrome.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : December 1, 2018  Saturday 8:14 AM
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>

#define size 50
int main()
    {
   	char strsrc[size];
    char strtmp[size];
    char reply=0;
    do {
    	system("cls");
        printf("\n\n");
    	printf("\t\t PALINDROME CHECKER 1.0");
        printf("\n\n");
    	printf("\tEnter a String : => ");
       	gets(strsrc);
    	strcpy(strtmp,strsrc);
    	strrev(strtmp);
        printf("\n\n");
	    if(strcmpi(strsrc,strtmp)==0) {
    	printf("\tEntered String %s is Palindrome.",strsrc);
    	}
    	else {
    	printf("\tEntered String %s is Not a Palindrome.",strsrc);
    	}
		printf("\n\n");
		printf("\tDo You Want to Continue? Y/N : ");
		reply = getch();
	} while (toupper(reply) =='Y');
    printf("\n\n");
	printf("\tThank you for Using This Software !!!");
    printf("\n\n");
	system("PAUSE");
 } /* End of Code */


