// palindrome.cpp
// Author    : Mr. Jake R. Pomperada, BSCS,MAED-IT
// Date      : August 31, 2018   Friday  3:11 PM
// Location  : Bacolod City, Negros Occidental Philippines.
// Website   : http://www.jakerpomperada.com
// Email     : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com

#include <iostream>
#include <string.h>

using namespace std;

int main()
{
    char str1[20], str2[20];
    int i, j, len = 0, flag = 0;
    cout << "Enter the string : ";
    gets(str1);
    
    len = strlen(str1) - 1;
    for (i = len, j = 0; i >= 0 ; i--, j++)
        str2[j] = str1[i];
        
    if (strcmpi(str1,str2))
        flag = 1;
    if (flag == 1)
        cout << str1 << " is a palindrome";
    else
        cout << str1 << " is not a palindrome";
    return 0;
}
