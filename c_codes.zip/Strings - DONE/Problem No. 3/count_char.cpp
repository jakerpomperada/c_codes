/*count_char.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : December 1, 2018  Saturday 8:33 AM
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()  {
        char str[200];
    	int i=0, VowelCount=0, ConsonantCount=0;
    	int whitespace=0, digits=0;
    	int specialCharacters=0;
	    printf("\n\n");
    	printf("\tVowels,Consonants,Digits,WhiteSpace and Special Characters Counter");
    	printf("\n\n");
    	printf("\tEnter a String :=> ");
    	gets(str);
		for(i=0;str[i]!='\0';i++)  {
        if(str[i]=='a' || str[i]=='e' || str[i]=='i' ||str[i]=='o' || str[i]=='u' || str[i]=='A' ||str[i]=='E' || str[i]=='I' || str[i]=='O' ||str[i]=='U')
        {
            VowelCount++;
        }
        else if((str[i]>='a'&& str[i]<='z') || (str[i]>='A'&& str[i]<='Z'))
        {
            ConsonantCount++;
        }
        else if(str[i]>='0' && str[i]<='9')
        {
            digits++;
        }
        else if (str[i]==' ')
        {
            whitespace++;
        }
        else
        {
            specialCharacters++;
        }
    }
    printf("\n");
	printf("\n\t===  SUMMARY OF REPORTS ===== ");
    printf("\n\n");
    printf("\n\tNumber of Vowels             :=> %d ", VowelCount);
    printf("\n\tNumber of Consonants         :=> %d ",ConsonantCount);
    printf("\n\tNumber of Digits             :=> %d ",digits);
    printf("\n\tNumber of WhiteSpace         :=> %d ",whitespace);
    printf("\n\tNumber of Special Characters :=> %d ",specialCharacters);
    printf("\n\n");
    printf("\tThank you for Using This Software.");
    printf("\n\n");
    system("PAUSE");
}

