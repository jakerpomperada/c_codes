
/*count.c
 Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
 Date      : December 1, 2018  Saturday 7:41 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
void main()
{
	char str[200];
	int len=0,a=0,word=1;
	printf("\n");
 	printf("\tCount Number of Words in a given Sentence");
 	printf("\n\n");
	printf("\tGive a Sentence : ");
	gets(str);
	len=strlen(str);
	for(a=0;a<len;a++)
	{
		if(str[a]!=' ' && str[a+1]==' ')
			word+=1;
	}
	printf("\n\n");
	printf("\t===== DISPLAY RESULT =====");
	printf("\n\n");
	printf("\tThere are %d words in a given sentence.",word);
	printf("\n\n");
 	printf("\tEnd of Program");
 	printf("\n\n"); 
}
