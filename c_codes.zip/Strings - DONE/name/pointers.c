/*pointers.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 30,2018  Wednesday 5:10 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>

int main(void) {
  
  char dad[] = "Virgilio";
  char mom[] = "Lydia";
  
  printf("\n");
  printf("\t");
  printf("%c", *dad);     
  printf("%c", *(dad+1));  
  printf("%c", *(dad+2));  
  printf("\n\n");
  
  char *namePtr;
  namePtr = mom;
  
  printf("\t");
  printf("%c", *namePtr);    
  printf("%c", *(namePtr+1));   
  printf("%c", *(namePtr+2)); 
  printf("\n\n");
  printf("  End of Program");
  printf("\n\n");  
}
