/*name.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 30,2018  Wednesday 4:25 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
int main()
{
    char name[100];
    printf("\n\n");
    printf("\tWhat is your name?  ");
    scanf("%s",&name);
    printf("\n\n");
    printf("\tYour name is %s.", name);
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}
