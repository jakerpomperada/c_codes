/*functions.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 30, 2018  Friday 5:02 PM
*/
#include <stdio.h>
void displayString(char str[]);
int main()
{
    char str[50];
    printf("\n\n");
	printf("\tGive me your name? ");
    gets(str);             
    displayString(str);     // Passing string to a function.    
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}
void displayString(char str[])
{
    printf("\n\n");
	printf("\tYour name is ");
    puts(str);
}
