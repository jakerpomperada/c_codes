/*gets.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 30, 2018  Friday 7:28 AM
*/
#include <stdio.h>
int main()
{
    char name[100];
    printf("\n\n");
    printf("\tWhat is your name? ");
    gets(name);     /* read string using gets statement */
    printf("\n\n");
    printf("\tHi %s. How are you today? ",name);
	printf("\n\n");
	printf("\t");
	puts(name);    /* display string using puts statement*/
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}
