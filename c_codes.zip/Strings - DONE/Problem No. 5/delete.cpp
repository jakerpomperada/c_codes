/*delete.c
 Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
 Date      : December 1, 2018  Saturday 9:40 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
#include <stdlib.h>
int search(char[], char[]);
int delete_word(char[], char[], int);
int main()
{
    char str[80], word[50];
    int index=0;
	printf("\n\n");
 	printf("\t\tDelete a Specific Word From a Sentence");
	printf("\n\n");
    printf("\tEnter a Sentence  :  ");
    gets(str);
    printf("\n");
    printf("\tEnter Word to Delete : ");
    gets(word);
    printf("\n");
    index = search(str, word);
    if (index !=  - 1)
    {
        delete_word(str, word, index);
        printf("\tString without word: %s", str);
    }
    else
    {
        printf("\n");
		printf("\tThe word not present in the string.");
    }
    printf("\n\n");
    printf("\tThank you for Using This Software.");
    printf("\n\n");
    system("PAUSE");
}
int search(char str[], char word[])
{
    int l, i, j;
    for (l = 0; word[l] != '\0'; l++);
    for (i = 0, j = 0; str[i] != '\0' && word[j] != '\0'; i++)
    {
        if (str[i] == word[j])
        {
            j++;
        }
        else
        {
            j = 0;
        }
    }

    if (j == l)
    {
     return (i - j);
    }
    else
    {
        return  - 1;
    }
}

int delete_word(char str[], char word[], int index)
{
    int i, l;
    for (l = 0; word[l] != '\0'; l++);
    for (i = index; str[i] != '\0'; i++)
    {
        str[i] = str[i + l + 1];
    }
}
