#include <stdio.h>
#include <conio.h>
#include <string>

#define int PASSLEN = 4;
void passget();
void start()
	{
	char password[4];
	printf("\n\n");
	printf("\t PASSWORD SECURITY VERSION 1.0");
	printf("\n\n");
	printf("Enter Your Password: ");
	password = passget();
	if (password == "jake") {
	printf("\n\n");
	printf("Password Accepted");
	printf("\n\n\n");
	cout << "\t\t Thank You For Using this Software";
	cout << "\n\n\t Created By: Mr. Jake Rodriguez Pomperada, MAED-IT";
    cout << "\n\n\t\t Date : September 26, 2009 Saturday";
	}
	else {
     printf("\n\n");
	cout << "Password Denied Try Again !!!";
	start();
	}
	} // End of Start Function
int main()
{
start();
	getch();
}
void passget()
{
	char password[PASSLEN], letter;
	int loop;
	int len;
	char password2[50];
		loop = 0;
		while(loop != PASSLEN)
		{
			password[loop] = '\0';
			loop++;
		}
		loop = 0;
		len = 0;
		letter = '\0';
		while( letter != '\r' )
		{
			letter = getch();
			if( letter == '\b' && password[0] == '\0')
			{
				loop = 0;
				len = 0;
			}
			else
			{
				if( letter == '\b' && password[0] != '\0')
				{
					cout << "\b";
					cout << " ";
					cout << "\b";
					loop--;
					password[loop] = '\0';
					len--;
				}
				else
				{
					if( isprint( letter ) != 0 && loop < PASSLEN)
					{
						password[loop] = tolower(letter);
						cout << "*" ;
					}
					loop++;
					if (loop <= PASSLEN)
						len++;
				}
			}
		}
		//Convert Password from character array to string
		loop = 0;
		len = len;
		password2 = "";
		while (loop != len)
		{
		password2 = password2+password[loop];
		loop++;
		}
	return password2;
 } // End of Function Password
