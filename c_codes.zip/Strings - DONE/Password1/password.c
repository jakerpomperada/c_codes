#include <stdio.h>
#include <conio.h>

void main()
{
char pasword[10],usrname[10], ch;
int i;

printf("Enter User name: ");
gets(usrname);
printf("Enter the password <any 5 characters>: ");

for(i=0;i<5;i++)
{
ch = getch();
pasword[i] = ch;
ch = '*' ;
printf("%c",ch);
}

pasword[i] = '\0';

printf("\nYour password is :");

/*for(i=0;i<5;i++)
{
printf("%c",pasword[i]);
} */

if (password[i]=="admin")
	{
		printf("Correct password");
	
    }
    else
    {
       printf("Wrong Password");
}
