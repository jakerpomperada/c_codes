/* logical.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 19, 2018  Monday 2:18 PM
   Location : Bacolod City, Negros Occidental
   Website  : http://www.jakerpomperada.com
   Emails   : jakerpomperada@jakerpomperada.com
              jakerpomperada@gmail.com
              jakerpomperada@yahoo.com
              jakerpomperada@aol.com
*/

#include <stdio.h>

int main()
{
    int a=10, b=4, c=10, d=20;
    // logical AND example
    printf("\n\n");
    printf("\tLogical Operators Demonstration");
    printf("\n\n");
     if (a>b && c==d) {
      printf("\n");	
      printf("\tA is greater than B AND C is equal to D.\n");
    }
    else {
    printf("\n");	
    printf("\tAND condition not satisfied.\n");
   }
     // logical OR example
    if (a>b || c==d) {
    	printf("\n");
   		printf("\tA is greater than B OR C is equal to D.\n");
       }
    else 
    {
     printf("\n");	
     printf("\tNeither A is greater than B nor C is equal to D.\n");
    }
    // logical NOT example
    if (!a) {
    	printf("\n");
        printf("\tA is zero.\n");
    }
    else {
    printf("\n");	
    printf("\tA is not zero.");
 }
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}

