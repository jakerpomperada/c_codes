/* alphabets.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 20, 2018  Tuesday  3:49 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>

int main()
{
	char ch;
	printf("\n\n");
	printf("\tVowels and Consonants Character Checker");
    printf("\n\n");
    printf("\tEnter any character: ");
    scanf("%c",&ch);
   
     if((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
    {
        printf("\n\n");
        printf("\t%c is an Alphabet",ch);
   }
    else if(ch >= '0' && ch <= '9')
    {
        printf("\n\n");
        printf("\t%c is a Digit.",ch);
    }
    else
    {
        printf("\n\n");
        printf("\t%c is a Special Character.",ch);
    }
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");  
}
