/* biggest.c
 Find the Biggest Number
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  2:32 PM
*/
#include <stdio.h>

int main()
{
	int a=0,b=0,c=0;
	printf("\n\n");
	printf("\tFind the Biggest Number");
	printf("\n\n");
    printf("\tEnter Three Numbers : ");
	scanf("%d%d%d",&a,&b,&c);
	if(a >= b)
    {
        if(a>= c) {
		    printf("\n\n");
            printf("\t%d is the largest number.",a);
        }
        else {
        	 printf("\n\n");
		     printf("\t%d is the largest number.",c);
		 }
    }
    else if(b >= c) {
    	printf("\n\n");
	    printf("\t%d is the largest number.",b);
     }
    else {
    	printf("\n\n");
        printf("\t%d is the largest number.",c);
    }
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");   
}
