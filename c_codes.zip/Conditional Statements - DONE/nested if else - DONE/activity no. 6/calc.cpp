/* calc.c
 Basic Calculator Program
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  4:23 PM
*/

#include <stdio.h>         
int main() {
	
	int menu_num=0;
    float first_num=0,second_num=0;
	float sum=0,difference=0;
	float multiply=0,quotient=0;

   	printf("\n\n");
    printf("\t===== MAIN MENU =====");
    printf("\n\n");
    printf("\t[1] ADDITION \n");
	printf("\t[2] SUBTRACTION\n");
	printf("\t[3] MULTIPLICATION\n");
	printf("\t[4] DIVISION\n");
	printf("\t[5] QUIT PROGRAM\n");
    printf("\n\n");
    printf("\tSelect your option : ");
    scanf("%d",&menu_num);
	
	//Addition
	if(menu_num == 1) {
		printf("\n\tEnter the first number to Add: ");
		scanf("%f",&first_num);
		printf("\n\tEnter the second number to Add: ");
		scanf("%f",&second_num);
		printf("\n\n");
		sum =(first_num + second_num);
		printf("\n\tThe result is %.2f. ",sum);	
	 }

 //Subtraction
      else  if(menu_num == 2) {
		printf("\n\tEnter the first number to Subtract: ");
		scanf("%f",&first_num);
		printf("\n\tEnter the second number to Subtract: ");
		scanf("%f",&second_num);
		difference = (first_num - second_num);
		printf("\n\tThe result is %.2f. ",difference);	
	}

	   // Multiplication
      else  if(menu_num == 3) {
		printf("\n\tEnter the first number to Multiply: ");
		scanf("%f",&first_num);
		printf("\n\tEnter the second number to Multiply: ");
		scanf("%f",&second_num);
		multiply =(first_num * second_num);
		printf("\n\tThe result is %.2f.",multiply);	
	 
	}
	   //Division
      else  if(menu_num == 4) {
		printf("\n\tEnter the first number to Divide: ");
		scanf("%f",&first_num);
		printf("\n\tEnter the second number to Divide: ");
		scanf("%f",&second_num);
		quotient =(first_num / second_num);
		printf("\n\tThe result is %.2f. ",quotient);	
	}
	
   //Quit Program
      else  if(menu_num == 5) {
		printf("\n\n");
		printf("\tThank you for using this Program.");
	    printf("\n");
	}
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");   	
}

