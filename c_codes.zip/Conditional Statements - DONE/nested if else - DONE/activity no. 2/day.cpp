/* days.c
 Find the Day of the Week
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  3:37 PM
*/
#include <stdio.h>

int main()
{
    int week=0;
    printf("\n\n");
	printf("\tFind the Day of the Week");
	printf("\n\n");
	printf("\tEnter Week Number (1-7) : ");
	scanf("%d",&week);
   if(week == 1)
    {
        printf("\n\n");
		printf("\tThe day is Monday.");
    }
    else if(week == 2)
    {
        printf("\n\n");
	    printf("\tThe day is Tuesday.");
    }
    else if(week == 3)
    {
        printf("\n\n");
		printf("\tThe day is Wednesday.");
    }
    else if(week == 4)
    {
        printf("\n\n");
		printf("\tThe day is Thursday.");
    }
    else if(week == 5)
    {
       	printf("\n\n");
	    printf("\tThe day is Friday.");
    }
    else if(week == 6)
    {
        printf("\n\n");
		printf("\tThe day is Saturday.");
    }
    else if(week == 7)
    {
        printf("\n\n");
		printf("\tThe day is Sunday.");
    }
    else
    {
        printf("\n\n");
		printf("\tInvalid Input! Please enter week in between 1-7.");
    }
   	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");   
}
