/* civil_status.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 20, 2018  Tuesday  9:37 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/

#include <stdio.h>

int main()
{
    char status[][100] = {"SINGLE","MARRIED","ANNULLED",
	                    "SEPARATED","WINDOW",
						"Invalid Civil Status Try Again."};
	char civil_status;
	char *display_status;
	char reply;
	char name[200];
	int i=0;
do {
	system("cls");
	printf("\n\n");
    printf("\tCivil Status Checker Program");
    printf("\n\n");
	printf("\tWhat is your name : ");
	gets(name);
	printf("\n\n");
	printf("\t\t===== CIVIL STATUS =====");
	printf("\n\n");
	printf("\t1-Single,2-Married,3-Annulled,4-Separated and 5-Widow");
	printf("\n\n");
	printf("\tWhat is your Civil Status? : ");
    scanf("%c",&civil_status);
    
    if (civil_status == '1') {
    	display_status =  status[0];
	}
	else if (civil_status == '2') {
    	display_status =  status[1];
	}
	else if (civil_status == '3') {
    		display_status =  status[2];
	}
	else if (civil_status == '4') {
    		display_status=  status[3];
	}
	else if (civil_status == '5') {
    		display_status =  status[4];
	}
	
	else {
			display_status =  status[5];
	}
	printf("\n\n");
	printf("\t===== DISPLAY RESULT =====");
	printf("\n\n");;
	printf("\tHi %s ",name);
	printf("\n\n");
	printf("\tYour Civil Status is %s.",display_status);
	printf("\n\n");
	printf("\tDo you want to continue Y/N? : ");
	scanf("%s",&reply);
   } while(reply=='Y' || reply =='y');
  	printf("\n\n");
    printf("\tThank you for using this software.");
	printf("\n\n");  
	}

