/* letter.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 20, 2018  Tuesday  3:49 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>

int main()
{
    char ch;
    printf("\n\n");
	printf("\tVowels and Consonants Character Checker");
    printf("\n\n");
    printf("\tEnter any character: ");
    scanf("%c",&ch);
   
    if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' || ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U')
    {
        printf("\n\n");
        printf("\t%c is a VOWEL.",ch);
	}
    else if((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
    {
        printf("\n\n");
		printf("\t%c is a CONSONANT.",ch);
    }
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");  
}
