// nested.cpp
// Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
// Date      : August 18, 2018  Saturday
// Location  : Bacolod City, Negros Occidental
// Website   : http://www.jakerpomperada.com
// Email     : jakerpomperada@jakerpomperada.com

#include <iostream>

using namespace std;

int main() 
{
    int number=0;
    
    cout << "\n\n";
	cout << "\tPositive and Negative Number Checker";
	cout << "\n\n";
    cout << "\tEnter an integer: ";
    cin >> number;

    if ( number > 0)
    {
        cout << "\n\n";
		cout << "\tYou entered " << number << " a positive integer.";
    }
    else if (number < 0)
    {
        cout << "\n\n";
		cout<<"\tYou entered " << number <<  " a negative integer.";
    }
    else
    {
        cout << "\n\n";
		cout << "\tYou entered 0.";
    }
    cout << "\n\n";
	cout << "\tEnd of Program";
	cout << "\n\n";
	return 0;
}
