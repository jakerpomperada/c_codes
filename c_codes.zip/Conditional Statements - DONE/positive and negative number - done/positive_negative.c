/* positive_negative.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 19, 2018  Monday 4:16 PM
   Location : Bacolod City, Negros Occidental
   Website  : http://www.jakerpomperada.com
   Emails   : jakerpomperada@jakerpomperada.com
              jakerpomperada@gmail.com
              jakerpomperada@yahoo.com
              jakerpomperada@aol.com
*/

#include <stdio.h>

int main()
{
    int num_value=0;
	printf("\n\n");
    printf("\tPositve and Negative Number Checker");
    printf("\n\n");
	printf("\tGive a Number : ");
	scanf("%d",&num_value);
	if (num_value >=0) {
	 printf("\n\n");
	 printf("\tYour Given Number %d is a POSITIVE Number.",num_value);
	}
	else {
	 printf("\n\n");
	 printf("\tYour Given Number %d is a NEGATIVE Number.",num_value);
	}
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}

