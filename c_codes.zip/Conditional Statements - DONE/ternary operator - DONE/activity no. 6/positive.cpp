/*positive.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 20, 2018  Tuesday 9:20 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/

#include <stdio.h>

int main()
{
 int num=0;
 printf("\n");
 printf("\tPositive and Negative Number Using Ternary Operator");
 printf("\n\n");
 printf("\tGive a Number : ");
 scanf("%d",&num);
 printf("\n");
 num>=0?
 printf("\tThe given number %d is a POSITIVE Number.",num):
 printf("\tThe given number %d is a is a NEGATIVE Number.",num);
 printf("\n\n");
 printf("\tEnd of Program");
 printf("\n\n"); 
}
