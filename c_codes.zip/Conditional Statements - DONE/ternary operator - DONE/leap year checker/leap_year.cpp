/* leap_year.c
 Leap Year Checker Using Ternary Operator
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  8:12 PM
*/
#include <stdio.h>

int main()
{
	int year=0;

    printf("\n\n");
	printf("\tLeap Year Checker Using Ternary Operator");
	printf("\n\n");
	printf("\tWhat is the Year? : ");
	scanf("%d",&year);
	printf("\n\n");	
	((year%100!=0 && year%4==0) || (year%400==0)) ?
		printf("\tThe year %d is a Leap year.\n",year) :
	    printf("\tThe year %d is Not a Leap year.\n",year);
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");	
    	
}

