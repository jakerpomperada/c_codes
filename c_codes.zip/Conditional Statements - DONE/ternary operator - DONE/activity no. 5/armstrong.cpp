/*armstrong.c
 Palindrome Number Using Ternary Operator
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  9:09 PM
*/
#include <stdio.h>
int main()
{
	
 int num=0;
 int sum=0,temp=0,remainder=0;
 printf("\n\n");
 printf("\tArmstrong Number Checker Using Ternary Operator");
 printf("\n\n");
 printf("\tGive a Number : ");
 scanf("%d",&num);
 temp = num;
 while(temp !=0)
 {
 	remainder = temp % 10;
 	sum = sum + remainder * remainder * remainder;
 	temp=temp/10;
 } 
 printf("\n");
 num==sum?
 printf("\tThe given number %d is Armstrong Number.",num):
 printf("\tThe given number %d is NOT a Armstrong Number.",num);
 printf("\n\n");
 printf("\tEnd of Program");
 printf("\n\n");
}
