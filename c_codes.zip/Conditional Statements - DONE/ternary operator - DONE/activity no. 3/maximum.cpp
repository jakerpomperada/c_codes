/* age.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 20, 2018  Tuesday  8:52 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/

#include <stdio.h>

int main()
{
 int a=0,b=0,c=0;
 int max_num=0;
 printf("\n\n");
 printf("\tBiggest of Three Numbers Using Ternary Operator");
 printf("\n\n");
 printf("\tGive three numbers : ");
 scanf("%d%d%d",&a,&b,&c);
 printf("\n");
 max_num = ((a>b) ? ((a>c)?a:c):((b>c)?b:c));
 printf("\tThe Biggest Number is %d.",max_num);
 printf("\n\n");
 printf("\tEnd of Program");
 printf("\n\n");
}
