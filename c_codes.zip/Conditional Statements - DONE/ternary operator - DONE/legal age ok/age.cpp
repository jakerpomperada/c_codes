/* age.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 20, 2018  Tuesday  8:16 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
int main()
{
 int age=0;
 
 printf("\n\n");
 printf("\tLegal Age Checker Using Ternary Operator");
 printf("\n\n");
 printf("\tEnter your age : ");
 scanf("%d",&age);
 printf("\n\n");
 age>=18?printf("\tYour age %d you are already an Adult.",age)
 : printf("\tYour age %d you are still a Minor.",age);
 printf("\n\n");
 printf("\tEnd of Program");
 printf("\n\n");	
}
