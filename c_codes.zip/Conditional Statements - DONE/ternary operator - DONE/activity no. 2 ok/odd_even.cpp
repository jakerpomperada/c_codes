/* odd_even.c
 Odd and Even Number Checker Using Ternary Operator"
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  8:36 PM
*/
#include <stdio.h>

int main()
{
 int num=0;
 printf("\n\n");
 printf("\tOdd and Even Number Checker Using Ternary Operator");
 printf("\n\n");
 printf("\tGive a Number : ");
 scanf("%d",&num);
 printf("\n\n");
 num%2==0?
 printf("\tThe given number %d is EVEN Number.",num):
 printf("\tThe given number %d is ODD Number.",num);
 printf("\n\n");
 printf("\tEnd of Program");
 printf("\n\n");
}
