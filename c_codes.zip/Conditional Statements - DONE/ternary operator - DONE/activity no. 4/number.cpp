/*palindrome.c
 Palindrome Number Using Ternary Operator
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  9:01 PM
*/
#include <stdio.h>
int main()
{
 int num=0;
 int reverse=0,temp=0;
 printf("\n\n");
 printf("\tPalindrome Number Using Ternary Operator");
 printf("\n\n");
 printf("\tGive a Number : ");
 scanf("%d",&num);
 temp = num;
 while(temp !=0)
 {
 	reverse = reverse * 10;
 	reverse = reverse + temp % 10;
 	temp = temp / 10;
 }
 printf("\n\n");
 num==reverse?
 printf("\tThe given number %d is Palindrome Number.",num):
 printf("\tThe given number %d is NOT a Palindrome Number.",num);
 printf("\n\n");
 printf("\tEnd of Program");
 printf("\n\n");

}
