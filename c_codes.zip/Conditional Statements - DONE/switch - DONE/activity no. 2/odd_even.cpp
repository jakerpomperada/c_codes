/* odd_even.c
 Odd and Even Number Checker Using Switch Statement
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  6:05 PM
*/
#include <stdio.h>

int main()
{
	int num_input=0;
	printf("\n");
	printf("\tOdd and Even Number Checker Using Switch Statement");
	printf("\n\n");
	printf("\tGive a Number : ");
	scanf("%d",&num_input);
	printf("\n\n");
	switch(num_input%2) 
    {
        case 0:
            printf("\tThe given number %d is EVEN number.",num_input);
            break;
        case 1:
            printf("\tThe given number %d is ODD number.",num_input);
            break;
    }
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");   
 }
