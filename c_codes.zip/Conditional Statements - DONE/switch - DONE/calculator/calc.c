/* calc.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 20, 2018  Tuesday  6:39 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>

int main()
{
    char opt;
    float num1=0.00, num2=0.00;

	printf("\n");
    printf("\tSwitch Calculator");
    printf("\n\n");
    printf("\tEnter an operator (+, -, *, /): ");
    scanf("%c",&opt);
    printf("\n");
    printf("\tEnter two operands: ");
    scanf("%f%f",&num1,&num2);
    printf("\n\n");
    switch (opt) 
    {
        case '+':
            printf("\t%.2f + %.2f = %.2f",num1,num2,num1+num2);
            break;
        case '-':
            printf("\t%.2f - %.2f = %.2f",num1,num2,num1-num2);
            break;
        case '*':
            printf("\t%.2f * %.2f = %.2f",num1,num2,num1*num2);
            break;
        case '/':
            printf("\t%.2f / %.2f = %.2f",num1,num2,num1/num2);
            break;
        default:
            printf("\t Error! operator is not correct. Try Again");
            break;
    }
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}

