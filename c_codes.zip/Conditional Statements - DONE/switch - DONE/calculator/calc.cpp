#include <iostream>

using namespace std;

int main()
{
    char opt;
    float num1, num2;

    cout << "\t Switch Calculator in C++";
    cout << "\n\n";
    cout << "\t Enter an operator (+, -, *, /): ";
    cin >> opt;

    cout << "Enter two operands: ";
    cin >> num1 >> num2;
    cout << "\n\n";
    
    switch (opt) 
    {
        case '+':
            cout <<"\t " << num1 << " + " << num2 << " = " << num1+num2;
            break;
        case '-':
            cout << num1 << " - " << num2 << " = " << num1-num2;
            break;
        case '*':
            cout <<"\t " << num1 << " * " << num2 << " = " << num1*num2;
            break;
        case '/':
            cout <<"\t " <<num1 << " / " << num2 << " = " << num1/num2;
            break;
        default:
              cout << "\t Error! operator is not correct. Try Again";
            break;
    }
    
    cout << "\n\n";
    cout << " End of Program ";
    cout << "\n\n";
    return 0;
}
