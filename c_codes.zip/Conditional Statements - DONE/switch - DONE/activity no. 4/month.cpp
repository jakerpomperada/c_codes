/* month.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 20, 2018  Tuesday  5:51 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>

int main()
{
	int month=0;
	int days=0;
	
	printf("\n");
	printf("\tFind Number of Days in a Month Using Switch Statement");
	printf("\n\n");
    printf("\tEnter Month : ");
    scanf("%d",&month);
    switch(month)
	{
		case  4:
		case  6:
		case  9:
		case 11:
			days=30;
			break;
		case  1:
		case  3:
		case  5:
		case  7:
		case  8:
		case 10:
		case 12:
			days=31;
			break;
			
		case 2:
			days=28;
			break;
		
		default:
			days=0;
			break;		
	}
	printf("\n\n");
	if(days)
		printf("\tNumber of days in %d is %d.",month,days);
	else
		printf("\tYou have entered an invalid month!!!\n");
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
    
}
	
	
