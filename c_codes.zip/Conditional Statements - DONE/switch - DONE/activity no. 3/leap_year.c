/* leap_year.c
 Odd and Even Number Checker Using Switch Statement
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  6:05 PM
*/
#include <stdio.h>

int main()
{
	int year=0;
	printf("\n");
	printf("\tLeap Year Checker Using Switch Statement");
	printf("\n\n");
	printf("\tWhat is the year? : ");
	scanf("%d",&year);
	printf("\n\n");
	switch((year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0)) 
    {
        case 1:
            printf("\tThe given year %d is a LEAP year.",year);
            break;
        case 0:
            printf("\tThe given year %d is NOT a LEAP year.",year);
            break;
    }
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n"); 
 }
