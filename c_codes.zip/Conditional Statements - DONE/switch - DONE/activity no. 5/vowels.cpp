/* vowels.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 20, 2018  Tuesday  5:51 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>

int main()
{
	char ch;
    printf("\n");
	printf("\tVowels and Consonant Checker Using Switch Statement");
	printf("\n\n");
    printf("\tGive a character : ");
    scanf("%c",&ch);
    printf("\n\n");
    if((ch>='A' && ch<='Z') || (ch>='a' && ch<='z'))
    {
        switch(ch)
        {
            case 'A':
            case 'E':
            case 'I':
            case 'O':
            case 'U':
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
                printf("\t%c is a VOWEL.",ch);
                break;
            default:
                printf("\t%c is a CONSONANT.",ch);      
        }
    }
    else
    {
        printf("\t%c is not an Alphabet.",ch);
    }
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}
