/* number.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 20, 2018  Tuesday  5:51 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>

int main()
{
  int i=0;
  printf("\n\n");
  printf("\tEnter an integer : ");
  scanf("%d",&i);
  printf("\n\n");
  
 switch(i)
	{
 	case 4: printf("\tfour");
            break;
	case 3: printf("\tthree");
            break;
	case 2: printf("\ttwo");
	case 1: printf("\tone");
	default:printf("\tsomething else!");
}
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");  
}

