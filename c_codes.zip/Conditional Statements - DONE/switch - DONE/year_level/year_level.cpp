/* year_level.c
 Year Level Checker Using Switch Statement
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  6:05 PM
*/
#include <stdio.h>

int main()
{
	int year_level=0;
	
	printf("\n");
	printf("\tYear Level Checker Using Switch Statement");
	printf("\n\n");
	printf("\tWhat is your year level? : ");
	scanf("%d",&year_level);
	printf("\n\n");
	switch(year_level)
	{
		case 1  : printf("\tYou are belong to Freshmen.");
		          break;
	    case 2  : printf("\tYou are belong to Sophomore.");
	              break;
	    case 3  : printf("\tYou are belong to Juniors.");
		          break;
	    case 4  : printf("\tYou are belong to Seniors.");
	              break;
	    default : printf("\tSorry Invalid Year Level. Try Again.");
    }
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");  
}
