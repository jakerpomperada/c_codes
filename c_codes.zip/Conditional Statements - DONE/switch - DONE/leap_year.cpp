// leap_year.cpp
// Author    : Mr. Jake R. Pomperada, BSCS,MAED-IT
// Date      : August 20, 2018   Monday
// Location  : Bacolod City, Negros Occidental Philippines.
// Website   : http://www.jakerpomperada.com
// Email     : jakerpomperada@jakerpomperada.com

#include <iostream>

using namespace std;


int main()
{
	int year=0;
	
	cout <<"\n";
	cout << "\tLeap Year Checker Using Switch Statement";
	cout << "\n\n";
	cout << "\tWhat is the year? : ";
	cin >> year;
	
	cout << "\n\n";
	
	switch((year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0)) 
    {
        case 1:
            cout <<"\tThe given year " << year << " is LEAP year.";
            break;
        case 0:
            cout <<"\tThe given number " << year << " is NOT a LEAP year.";
            break;
    }
     
    cout <<"\n\n";
    cout << "\tEnd of Program";
    cout <<"\n\n";
}
