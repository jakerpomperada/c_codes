/* divisible.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 20, 2018  Tuesday  8:43 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/

#include <stdio.h>
int main()
{
	int number_given=0;
	printf("\n\n");
    printf("\tDivisible Number Determiner");
    printf("\n\n");
    printf("\tGive a Number : ");
    scanf("%d",&number_given);

	 if((number_given % 5 == 0) && (number_given % 11 == 0))
    {
	    printf("\n\n");
		printf("\tThe given number %d is divisible by 5 and 11.",number_given);
    }
    else
    {
        printf("\n\n");
		printf("\tThe given number %d is not divisible by 5 and 11.",number_given);
    }

    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");   
}
