/* leap_year.c
 Leap Year Checker Program
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  8:13 AM
*/

#include <stdio.h>

int main()
{
	int year=0;
	printf("\n\n");
    printf("\tLeap Year Checker Program");
    printf("\n\n");
    printf("\tGive a Year : ");
    scanf("%d", &year);
		
	if(((year % 4 == 0) && (year % 100 !=0)) || (year % 400==0))
    {
        printf("\n\n");
        printf("\tThe Given Year %d is a LEAP year.",year);
    }
    else
    {
        printf("\n\n"); 
        printf("\tThe Given Year %d is NOT a LEAP year.",year);
    }
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");   
}
