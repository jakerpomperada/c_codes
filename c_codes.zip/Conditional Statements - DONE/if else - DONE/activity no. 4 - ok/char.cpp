/* char.c
 Leap Year Checker Program
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  8:28 AM
*/
#include <stdio.h>

int main()
{
	char ch;
	char screen_display;
	printf("\n\n");
    printf("\tCharacter Checker Program");
    printf("\n\n");
    printf("\tGive a Character : ");
    scanf("%c", &ch);
	screen_display = ch;
	
	if((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
    {
    	printf("\n\n");
		printf("\tThe given character %c is an Alphabet.",screen_display);
      }
    else
    {
      	printf("\n\n");
		printf("\tThe given character %c is Not an Alphabet.",screen_display);  
    }
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");  
}
