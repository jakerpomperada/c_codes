/* bigger.c
 Bigger Number Checker
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 20, 2018   Tuesday  7:40 AM
*/

#include <stdio.h>

int main()
{
	int a=0,b=0;
	printf("\n\n");
    printf("\tBigger Number Program");
    printf("\n\n");
    printf("\tGive Two Numbers : ");
    scanf("%d%d", &a,&b);
	if (a > b) {
		printf("\n\n");
		printf("\t%d is much bigger than %d.",a,b);
	   }
	else {
		printf("\n\n");
		printf("\t%d is much bigger than %d.",b,a);
		}
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");   
}

