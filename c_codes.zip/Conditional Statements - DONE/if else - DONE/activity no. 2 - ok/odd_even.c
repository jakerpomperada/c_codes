/* odd_even.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 20, 2018  Tuesday  7:54 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>

int main()
{	
	int a=0, check_number=0;
	printf("\n\n");
    printf("\tOdd and Even Number Checker");
    printf("\n\n");
    printf("\tGive a Number : ");
    scanf("%d",&a);
	check_number = (a % 2);
	if (check_number == 0) {
	    printf("\n\n");
	    printf("\tThe given number %d is an EVEN number.",a);
	}
	else {
		 printf("\n\n");
		 printf("\tThe given number %d is an ODD number.",a);
	}
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");   
}
