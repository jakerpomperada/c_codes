/* highest.c
 Highest of the Three Numbers
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 16, 2018   Friday  5:03 PM
*/

#include <stdio.h>

int main()
{    
    int n1=0,n2=0,n3=0;

    system("COLOR F0");
    printf("\n\n");
    printf("\tHighest of the Three Numbers");
    printf("\n\n");
    printf("\tGive Three Numbers : ");
    scanf("%d%d%d",&n1,&n2,&n3);

    printf("\n\n");
    if(n1 >= n2 && n1 >= n3)
    {
        printf("\tThe highest number is %d.",n1);
    }

    if(n2 >= n1 && n2 >= n3)
    {
        printf("\tThe highest number is %d.",n2);
    }

    if(n3 >= n1 && n3 >= n2) {
        printf("\tThe highest number is %d.",n3);
    }
   printf("\n\n");
   printf("\tEnd of Program");
   printf("\n\n");
}

