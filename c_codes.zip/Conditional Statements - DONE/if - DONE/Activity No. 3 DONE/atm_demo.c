/* atm.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 18,2018  Sunday   7:22 AM
   Location : Bacolod City, Negros Occidental
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com
              jakerpomperada@gmail.com
              jakerpomperada@yahoo.com
*/

#include <stdio.h>

int main()

{
int bill1000=0,bill500=0, bill200=0, bill100=0, total_balance=0;
int withdraw=0, money_left=0;
int recieve1000=0,recieve500=0, recieve200=0, recieve100=0;
char withdraw_again[2] = "N";

	     printf("\n\n");
         printf("\tAutomatic Teller Machine Simulation");
		 printf("\n\n");
		 printf("\tHow many P1000 bills: ");
		 scanf("%d", &bill1000);
		 printf("\tHow many P500 bills: ");
		 scanf("%d", &bill500);
		 printf("\tHow many PHP 200 bills: ");
		 scanf("%d", &bill200);
		 printf("\tHow many PHP 100 bills: ");
		 scanf("%d", &bill100);
		 total_balance = (bill1000 * 1000)+(bill500 * 500) + (bill200 * 200) +  (bill100 * 100) ;
	     printf("\n\n");
		 printf("\tTotal Balance: PHP %d", total_balance);

	 do

	 {
		 printf("\n\n");
		 printf("\tEnter amount to withdraw: PHP ");
		 scanf("%d", &withdraw);
		 money_left = withdraw ;

		 if  (withdraw > total_balance)
				{
				printf("\tWithdraw amount greater than total balance.  ");
				printf("\n");
				}
		 if (withdraw < total_balance)
		 {
		 	
		if  (money_left >= 1000 )
				{
				 recieve1000 = (money_left / 1000);
				 if (recieve1000 > bill1000 ) recieve1000 = bill1000;

				 money_left = money_left - (recieve1000 * 1000);
				 bill1000 = bill1000 - recieve1000;
				}

		 if  (money_left >= 500 )
				{
				 recieve500 = (money_left / 500);
				 if (recieve500 > bill500 ) recieve500 = bill500;

				 money_left = money_left - (recieve500 * 500);
				 bill500 = bill500 - recieve500;
				}

		 if (money_left >= 200 )
			 {
				 recieve200 = (money_left / 200);
				 if (recieve200 > bill200 ) recieve200 = bill200;
				 money_left = money_left - (recieve200 * 200);
				 bill200 = bill200 - recieve200;
			 }

		 if (money_left >= 100 )
			  {
				 recieve100 =(money_left / 100);
				 if (recieve100 > bill100 ) recieve100 = bill100;
				 money_left = money_left - (recieve100 * 100);
				 bill100 = bill100 - recieve100;
				}

				printf("\n");
				printf("\n");
				printf("\tYou will receive:");
				printf("\n");
				printf("\tPHP 1000 bill :=> %d ", recieve1000);
				printf("\n");
				printf("\tPHP 500 bill :=> %d ", recieve500);
				printf("\n");
				printf("\tPHP 200 bill :=> %d ", recieve200);
				printf("\n");
				printf("\tPHP 100 bill :=> %d ", recieve100);
				printf("\n\n");


				total_balance = total_balance - withdraw;

				printf("\tYour current balance is: PHP %d", total_balance);

				printf("\n\n");
				printf("\tYou only have balance of:");
				printf("\n");
				printf("\tPHP 1000 bill :=> %d",bill1000);
				printf("\n");
				printf("\tPHP 500 bill  :=> %d",bill500);
				printf("\n");
				printf("\tPHP 200 bill  :=> %d",bill200);
				printf("\n");   
				printf("\tPHP 100 bill  :=> %d",bill100);
				printf("\n");
 				printf("\n\n");
				printf("\tAnother Withdraw Again ? Y/N : ");
				scanf("%s", &withdraw_again);

		 }

	 }  while (toupper(withdraw_again == "Y"));
     printf("\n\n");
     printf("\tEnd of Program");
     printf("\n\n");
}

