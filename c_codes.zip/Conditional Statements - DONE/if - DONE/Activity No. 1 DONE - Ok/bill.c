/* bills.c
 Money Bill Checker
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 16, 2018   Friday  5:15 PM
*/

#include <stdio.h>

int main()
{
    int amount=0;
    int note500, note100, note50, note20, note10, note5, note2, note1;
    
    note500 = note100 = note50 = note20 = note10 = note5 = note2 = note1 = 0;

    system("COLOR F0");
    printf("\n\n");
    printf("\tMoney Bill Checker");
    printf("\n\n");
    printf("\tEnter amount: ");
    scanf("%d", &amount);

    if(amount >= 500)
    {
        note500 = amount/500;
        amount -= note500 * 500;
    }
    if(amount >= 100)
    {
        note100 = amount/100;
        amount -= note100 * 100;
    }
    if(amount >= 50)
    {
        note50 = amount/50;
        amount -= note50 * 50;
    }
    if(amount >= 20)
    {
        note20 = amount/20;
        amount -= note20 * 20;
    }
    if(amount >= 10)
    {
        note10 = amount/10;
        amount -= note10 * 10;
    }
    if(amount >= 5)
    {
        note5 = amount/5;
        amount -= note5 * 5;
    }
    if(amount >= 2)
    {
        note2 = amount /2;
        amount -= note2 * 2;
    }
    if(amount >= 1)
    {
        note1 = amount;
    }

    printf("\n\n");
    printf("\t===== DISPLAY RESULT =====");
    printf("\n\n");
    printf("\tTotal number of notes = \n");
    printf("\n\n");
    printf("\t500 = %d\n",note500);
    printf("\t100 = %d\n",note100);
    printf("\t50 = %d\n",note50);
    printf("\t20 = %d\n",note20);
    printf("\t10 = %d\n",note10);
    printf("\t5 = %d\n",note5);
    printf("\t2 = %d\n",note2);
    printf("\t1 = %d\n",note1);
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");    
}

