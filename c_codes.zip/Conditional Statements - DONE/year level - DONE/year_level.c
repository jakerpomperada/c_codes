/* year_level.c
   Year Level Checker Program
  Author   : Kristine Trogani Soberano,Ph.D.
  Faculty, Northern Negros State College of Science and Technology
  Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
  Email    : missKsoberano@gmail.com
  Tool     : Dev C++ Version 5.11
  Date    : November 19, 2018   Monday  3:53 PM
*/

#include <stdio.h>

int main()
{
	int year_level=0;
	printf("\n\n");
    printf("\tYear Level Checker Program");
    printf("\n\n");
	printf("\tWhat is your year level? : ");
	scanf("%d",&year_level);
	if (year_level==1) {
		printf("\n\n");
		printf("\tYou Belong to Freshmen.");
	}
	if (year_level==2) {
		printf("\n\n");
		printf("\tYou Belong to Sophomore.");
	}
	if (year_level==3) {
		printf("\n\n");
		printf("\tYou Belong to Juniors.");
	}
	if (year_level==4) {
		printf("\n\n");
		printf("\tYou Belong to Seniors.");
	}
	if (year_level <1 || year_level >4) {
		printf("\n\n");
		printf("\tInvalid Year Level. Try Again !!!");
	}
	printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}


