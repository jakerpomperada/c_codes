/*record.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 29, 2018  Thursday 10:02 AM
*/
#include <stdio.h>
union student
{
   char name[200],subject[200];
   int age;
   float grade;
};
int main()
{
 union student records;
 printf("\n\n");
 printf("\tUnion Sample Program");
 printf("\n\n");
 printf("\t===== DISPLAY RECORD =====");
 printf("\n\n");
 strcpy(records.name,"Juan Dela Cruz");
 printf("\tStudent Name    :  %s\n ",records.name);
 records.age = 17;
 printf("\tStudent Age     :  %d\n ",records.age);
 strcpy(records.subject,"Linear Algebra");
 printf("\tStudent Subject :  %s\n ",records.subject);
 records.grade =89.03;
 printf("\tStudent Grade   :  %.2f\n ",records.grade);
 printf("\n");
 printf("\tEnd of Program");
 printf("\n\n");
}
