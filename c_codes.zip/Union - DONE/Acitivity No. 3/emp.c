/*employee.c
 Author    : Mr. Jake Rodriguez Pomperada,BSCS,MAED-IT
 Date      : December 1, 2018  Saturday 10:31 PM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h> 
#include <string.h> 

union Employee 
{
  int age;  
  char Name[100];
  char Department[100];
  float Salary;
};

int main() 
{
  union Employee emp1;
  union Employee emp2;
    
    emp1.age = 28;
    strcpy(emp1.Name, "Julianna Rae Pomperada");
    strcpy(emp1.Department, "Computer Science");
    emp1.Salary = 32000.70;
  printf("\n\n");
  printf("\tDetails of the First Employee \n");
  printf("\tEmployee Age = %d \n", emp1.age);
  printf("\tEmployee Name = %s \n", emp1.Name);
  printf("\tEmployee Department = %s \n", emp1.Department);
  printf("\tEmployee Salary = %.2f \n\n", emp1.Salary);

  printf("\tDetails of the Second Employee \n" );
  emp2.age = 30;
  printf("\tEmployee Age = %d \n", emp2.age );
  strcpy(emp2.Name, "Julianna Rae Pomperada");
  printf("\tEmployee Name = %s \n", emp2.Name );
  strcpy(emp2.Department, "Information Technology" );
  printf("\tEmployee Department = %s \n ", emp2.Department );
  emp2.Salary = 35000.20;
  printf("\tEmployee Salary = %.2f \n ", emp2.Salary );
  printf("\n\n");
  printf("\t\tEnd of Program");
  printf("\n\n");
  system("pause");
}

