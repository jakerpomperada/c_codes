/* emp_profile.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 29, 2018  Thursday  2:33 PM
   Location : Bacolod City, Negros Occidental
   Tool     : Dev C++ Version 5.11
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com
*/
#include<stdio.h>
union emp
{
	char emp_name[100];
	char emp_position[100];
	int age;
    float salary;
}; 
void main()
{
 union emp profile;
 printf("\n\n");
 printf("\tEmployee's Profile Using Union");
 printf("\n\n");
 printf("\tEmployees Name     : ");
 gets(profile.emp_name);
 printf("\n");
 printf("\tName         :  %s\n",profile.emp_name);
 printf("\n");
 printf("\tEmployees Position : ");
 gets(profile.emp_position);
 printf("\n");
 printf("\tYour position is %s.\n",profile.emp_position);
 printf("\n");
 printf("\tEmployees Age : ");
 scanf("%d",&profile.age);
 printf("\n");
 printf("\tYour age is %d year(s) old.\n",profile.age);
 printf("\n");
 printf("\tEmployees Salary : PHP ");
 scanf("%f",&profile.salary);
 printf("\n");
 printf("\tYour salary is PHP %.2f",profile.salary);
 printf("\n\n");
 printf("\tEnd of Program");
 printf("\n\n");
}
