
/* hello.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 15, 2018  Thursday  6:49 AM
   Location : Bacolod City, Negros Occidental
   Website  : http://www.jakerpomperada.com
   Email    : jakerpomperada@jakerpomperada.com
*/

#include <stdio.h>

int main()
{
   	printf("\n\n");
    printf("\tHello World !!!");
	printf("\n\n");
	printf("\tWelcome To C Programming");
    printf("\n\n");
    return 0;
  }



