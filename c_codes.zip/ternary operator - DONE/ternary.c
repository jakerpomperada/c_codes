/* ternary.c
   Author   : Jake Rodriguez Pomperada,BSCS,MAED-IT
   Date     : November 19, 2018   11:39 AM
   Location : Bacolod City, Negros Occidental
   Website  : http://www.jakerpomperada.com
   Emails   : jakerpomperada@jakerpomperada.com
              jakerpomperada@gmail.com
              jakerpomperada@yahoo.com
              jakerpomperada@aol.com
*/

#include <stdio.h>

int main ()
{
  int a=0,b=0,c=0;
  a=10;
  b=5;
  
  c = (a>b) ? a : b;
  
  printf("\n");
  printf("\tConditional ternary operator ( ? )");
  printf("\n\n");
  printf("\tThe result is %d.",c);
  printf("\n\n");
  printf("\tEnd of Program");
  printf("\n\n");
  }



