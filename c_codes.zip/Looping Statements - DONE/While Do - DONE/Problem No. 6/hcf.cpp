/*hcf.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 23, 2018  Tuesday 9:53 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
int main()
{
    int n1=0,n2=0;
    printf("\n\n");
    printf("\tHCF Solver Using While Loop Statement");
    printf("\n\n");
    printf("\tGive two Numbers     : ");
    scanf("%d%d",&n1,&n2);
	while (n1 != n2) {
		if (n1 > n2) {
		 n1 -= n2;
	  } else {
	  	n2 -= n1;
	  }
   }
    printf("\n\n");
	printf("\tThe HCF values is %d. ",n1);
    printf("\n\n");
    printf("\t\t End of Program");
    printf("\n\n");
}

