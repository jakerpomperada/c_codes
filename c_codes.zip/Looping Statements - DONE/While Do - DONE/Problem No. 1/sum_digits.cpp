/*sum_digits.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 23, 2018   Friday 8:08 AM
*/
#include <stdio.h>
int main()
{
    long int num=0, r=0, sum=0;
    printf("\n\n");
    printf("\tSum of Digits Using While Loop Statement");
	printf("\n\n");
	printf("\tGive a Number : ");
	scanf("%d",&num);
    sum = 0;
    while (num !=0){
    	r = num % 10;
    	sum+=r;
    	num/=10;
	}
    printf("\n");
    printf("\tThe total sum of the digits is %d.",sum);
    printf("\n\n");
    printf("\t\t End of Program");
    printf("\n\n");
}

