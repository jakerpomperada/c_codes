/*reverse_number.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 23, 2018   Friday 9:01 AM
*/
#include <stdio.h>
int main()
{
    int num=0, reversedNumber=0;
    int remainder=0;
    printf("\n\n");
	printf("\tReverse a Number Using While Loop Statement");
    printf("\n\n");    
	printf("\tGive a Number     : ");
	scanf("%d",&num);
    printf("\n\n"); 
	while (num !=0)
	{
	 remainder = (num % 10);
	 reversedNumber = reversedNumber * 10 + remainder;
	 num /= 10;	
	}
	printf("\tThe Reversed Number is  %d.",reversedNumber);
    printf("\n\n");
    printf("\t\t End of Program");
    printf("\n\n");
}

