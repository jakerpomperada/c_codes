/*armstrong.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 23, 2018   Friday 8:24 AM
*/
#include <stdio.h>
int main()
{
    int i=0,x=0,num=0,r=0,sum=0;  
    printf("\n\n");
	printf("\tArmstrong Number Checker Using While Loop Statement");
	printf("\n\n");
	printf("\tGive a Number : ");
	scanf("%d",&num);
    x=num;
    sum = 0;
    while (num !=0){
    	r = num % 10;
    	sum = sum + (r * r *r);
    	num/=10;
	}
    printf("\n");
     if (sum == x) {
     	printf("\tThe given number %d is a Armstrong Number.",x);
     } 
	 else
	 {
	    printf("\tThe given number %d is Not a Armstrong Number.",x);
	 }
    printf("\n\n");
    printf("\t\t End of Program");
    printf("\n\n");
}

