/*power_number.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 23, 2018  Tuesday 8:52 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
int main()
{
    int exponent=0;
    int base=0.00, result=1;
    printf("\n\n");
	printf("\tPower of a Number Solver Using While Loop Statement");
    printf("\n\n");
	printf("\tGive value for base     : ");
	scanf("%d",&base);
	printf("\n");
	printf("\tGive value for exponent : ");
	scanf("%d",&exponent);
	printf("\n\n");
	printf("\tTHE RESULT");
	printf("\n\n");
	printf("\t %d ^ %d = ",base,exponent);
	 while (exponent !=0) {
	 	result *= base;
	 	--exponent;
	 }
    printf("%d",result);
    printf("\n\n");
    printf("\t\t End of Program");
    printf("\n\n");
}

