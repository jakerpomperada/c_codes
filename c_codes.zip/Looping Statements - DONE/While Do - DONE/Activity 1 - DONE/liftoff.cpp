/* liftoff.c
 Lift Off Program
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 23, 2018   Friday 7:03 AM
*/

#include <stdio.h>

int main() 
{
	int n=15;
	
    printf("\n\n");
    printf("\t\tLift Off Program");
    printf("\n\n");
	while (n>0) {
	  printf(" %d ",n);
	  n--;	
	}
	printf("\n\n");
    printf("\t\tLIFTOFF !!!");
    printf("\n\n");
    printf("\t\t End of Program");
    printf("\n\n");
}
