/*strong_number.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 23, 2018  Tuesday 8:38 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
int main()
{
    int n=0,x=0,r=0,sum=0,i=0,f=0;  
    printf("\n\n");
	printf("\tStrong Number Checker Using While Loop Statement");
	printf("\n\n");
	printf("\tGive a Number : ");
	scanf("%d",&n);
    x=n;
    sum = 0;
    while (n !=0){
    	r = n % 10;
    	f=1;
        for (i=1; i<=r; i++) {
        	f*=i;
		}
		sum+=f;
		n/=10;
	}
     printf("\n");
     if (sum == x) {
     printf("\tThe given number %d is a Strong Number.",x);
	 } 
	 else
	 {
	 printf("\tThe given number %d is Not a Strong Number.",x);
	 }
    printf("\n\n");
    printf("\t\t End of Program");
    printf("\n\n");
}

