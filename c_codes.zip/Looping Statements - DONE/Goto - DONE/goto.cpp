/*goto.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 23, 2018   Friday 11:39 AM
*/
#include <stdio.h>
int main()
{
	int a=1;
	printf("\n\n");
	printf("\tGoto Statement in C");
	printf("\n\n");
    printf("\t");
    jump:
    	printf(" %d",a);
    	a++;
    	if (a<=34){
    		goto jump;
		}
	printf("\n\n");	
    printf("\tThank you for Using This Software.");
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
} 
