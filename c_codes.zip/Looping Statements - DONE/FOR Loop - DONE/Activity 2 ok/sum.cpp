// sum.cpp
// Author    : Mr. Jake R. Pomperada, BSCS,MAED-IT
// Date      : August 24, 2018   Friday  6:47 AM
// Location  : Bacolod City, Negros Occidental Philippines.
// Website   : http://www.jakerpomperada.com
// Email     : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n=0,sum_all=0;
  
    cout << "\n\n";
	cout << "\tSum of Numbers Using For Loop Statement";
	cout << "\n\n";
	cout << "\tGive a Number : ";
	cin >> n;
	for (int a=1; a<=n; ++a)
	{
		sum_all +=a;
	}
	cout <<"\n";
	cout <<"\tThe total sum is " << sum_all <<".";
	cout <<"\n\n";
    cout << "\tEnd of Program";
    cout <<"\n\n"; 
}

