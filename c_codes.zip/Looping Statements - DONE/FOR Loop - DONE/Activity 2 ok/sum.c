/* sum.c
 Sum of Numbers Using For Loop Statement
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 21, 2018   Tuesday  6:09 AM
*/
#include <stdio.h>

int main()
{
    int a=0,n=0,sum_all=0;
  
    printf("\n\n");
	printf("\tSum of Numbers Using For Loop Statement");
    printf("\n\n");
	printf("\tGive a Number : ");
    scanf("%d",&n);
	for (a=1; a<=n; ++a)
	{
		sum_all +=a;
	}
	printf("\n");
	printf("\tThe total sum is %d.",sum_all);
	printf("\n\n");
 	printf("\t\t\tEnd of Program");
 	printf("\n\n");
}

