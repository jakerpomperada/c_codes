/*perfect_number.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 21 2018  Wednesday 6:32 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/

#include <stdio.h>
int main()
{
    int n=0,i=0,sum=0;
    printf("\n\n");
	printf("\tPerfect Number Checker Using For Loop Statement");
	printf("\n\n");
	printf("\tGive a Number : ");
    scanf("%d",&n);
	sum = 0;
	for (i=1; i<=n/2; i++) {
		if (n%i == 0) {
			sum+=i;
		}
	}
	printf("\n");
	if (sum == n) {
		printf("\t%d is a Perfect Number.",n);
	}
	else {
		printf("\t%d is NOT a Perfect Number.",n);
	}
	printf("\n\n");
 	printf("\t\t\tEnd of Program");
 	printf("\n\n");
}

