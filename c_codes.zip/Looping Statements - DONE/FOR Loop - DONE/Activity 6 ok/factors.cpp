/*factors.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 21 2018  Wednesday 6:32 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
int main()
{
    int num=0,i=0;
    printf("\n\n");
    printf("\tFactors of a Number Using For Loop Statement");
    printf("\n\n");	
	printf("\tGive a Number : ");
    scanf("%d",&num);
    printf("\n");
    printf("\tThe factors of %d as follows below.",num);
    printf("\n\n");
    for (i=1; i<=num; ++i){
    	if (num % i ==0)
    	{
    	printf("\t%d ",i);
		}
	}
    printf("\n\n");
 	printf("\t\t\tEnd of Program");
 	printf("\n\n");
    
}

