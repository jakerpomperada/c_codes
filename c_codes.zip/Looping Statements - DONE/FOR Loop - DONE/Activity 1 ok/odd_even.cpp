/* odd_even.c
 Odd and Even Number Checker Using For Loop Statement
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 21, 2018   Tuesday  6:09 AM
*/
#include <stdio.h>

int main()
{
    int number=0;
    int n=0;
    printf("\n\n");
    printf("\tOdd and Even Numbers Using For Loop Statement");
    printf("\n\n");
    printf("\tGive a Number : ");
    scanf("%d",&n);
	printf("\n");
    printf("\tThe ODD numbers are:");
    printf("\n\n");
    for (number=1; number<=n; number+=2)
    {
        printf("\t%d",number);
    }
	printf("\n\n");
	printf("\tThe EVEN numbers are:");
    printf("\n\n");
    for (number=0; number<=n; number+=2)
    {
        printf("\t%d",number);
    } 
   	printf("\n\n");
 	printf("\t\t\tEnd of Program");
 	printf("\n\n"); 
}

