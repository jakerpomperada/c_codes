/* sum_odd_even.c
 Sum of Odd and Even Number Using For Loop Statement
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 21, 2018   Tuesday  6:37 AM
*/
#include <stdio.h>
int main()
{
    int i=0,num=0;
    int odd_sum=0,even_sum=0;
    printf("\n\n");
	printf("\tSum of Odd and Even Number Using For Loop Statement");
	printf("\n\n");
	printf("\tGive a Number : ");
    scanf("%d",&num);
    for (i=1; i<=num; i++){
    	if (i % 2 ==0) {
    		even_sum+=i;
		}
		else {
			odd_sum+=i;
		}
    }
    printf("\n\n");
    printf("\tSum of all ODD Numbers  is %d.\n\n",odd_sum);
    printf("\tSum of all EVEN Numbers is %d.",even_sum);
    printf("\n\n");
 	printf("\t\t\tEnd of Program");
 	printf("\n\n");
}

