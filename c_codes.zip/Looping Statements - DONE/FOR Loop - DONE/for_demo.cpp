/*for_loop.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 21 2018  Wednesday 5:52 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/

#include <stdio.h>

int main()
{
    int a=0;
	printf("\n\n");
    printf("\t\tFor Loop Statement Demonstration");
    printf("\n\n");
	for ( a=1; a<=20; a+=1) {
		printf(" %d ",a);
	}
	printf("\n\n");
 	printf("\t\t\tEnd of Program");
 	printf("\n\n"); 
}

