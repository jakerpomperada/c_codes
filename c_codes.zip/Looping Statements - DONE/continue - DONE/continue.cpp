/*continue.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 23, 2018   Friday 11:55 AM
*/
#include <stdio.h>
int main()
{
	int a = 1;
	printf("\n\n");
	printf("\tContinue Statement Demonstration");
	do {
		if (a==5) {
			a+=1;
			continue;
		}
		printf("\n\n");
		printf("\tThe value of a: %d.",a);
		a+=1;
	} while (a <=10);
	printf("\n\n");	
    printf("\tThank you for Using This Software.");
    printf("\n\n");
    printf("\tEnd of Program");
    printf("\n\n");
}




