/*prime.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 23, 2018   Friday 10:48 AM
*/
#include <stdio.h>
int main()
{
	int no=0;
    printf("\n\n");
    printf("\tDisplay Prime Numbers Using Do While Statement");
	printf("\n\n");
    do {
    	int i=0;
    	for (i=2; i<no; i++) 
    		if (no % i == 0) 
    			break;
			
			if (i==no) 
			    printf(" %d ",no);
				no++;
			
		
	} while (no !=100);
	printf("\n\n");
    printf("\tThank you for Using This Software.");
    printf("\n\n");
    printf("\t\t End of Program");
    printf("\n\n");
}

