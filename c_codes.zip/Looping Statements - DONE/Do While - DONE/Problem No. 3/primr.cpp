// prime.cpp
// Author    : Mr. Jake R. Pomperada, BSCS,MAED-IT
// Date      : August 24, 2018   Friday  9:59 PM
// Location  : Bacolod City, Negros Occidental Philippines.
// Website   : http://www.jakerpomperada.com
// Email     : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com

#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
	
    int no=0;
 
    cout << "\n\n";
	cout << "\tDisplay Prime Numbers Using Do While Statement";
	cout << "\n\n";
    do {
    	int i=0;
    	for (i=2; i<no; i++) {
    		if (no % i == 0) {
    			break;
			}
			if (i==n0) {
				cout <<"\t"<<no<<",";
				no++''
			}
		}
	} while (no !=100);
	cout <<"\n\n";
    cout <<"\tThank you for Using This Software";
    cout <<"\n\n";
    cout << "\tEnd of Program";
    cout <<"\n\n"; 
}

