/*lcm.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 23, 2018   Friday 10:48 AM
*/
#include <stdio.h>
int main()
{
	int a=0,b=0,max=0;
 	printf("\n\n");
    printf("\tLCM Solver Using Do While Statement");
	printf("\n\n");
	printf("\tGive Two Numbers     : ");
	scanf("%d%d",&a,&b);
    max = (a < b) ? a : b;
    do {
    	if (max % a == 0 && max % b == 0) {
    		printf("\n");
    		printf("\tThe LCM is %d.",max);
    		break;
		}
		else {
			max++;
		} 
   } while(true);
	printf("\n\n");
    printf("\tThank you for Using This Software.");
    printf("\n\n");
    printf("\t\t End of Program");
    printf("\n\n");
}

