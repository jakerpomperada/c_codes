// lcm.cpp
// Author    : Mr. Jake R. Pomperada, BSCS,MAED-IT
// Date      : August 24, 2018   Friday  9:46 PM
// Location  : Bacolod City, Negros Occidental Philippines.
// Website   : http://www.jakerpomperada.com
// Email     : jakerpomperada@jakerpomperada.com and jakerpomperada@gmail.com

#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
	
    int a=0,b=0,max=0;
 
    cout << "\n\n";
	cout << "\tLCM Solver Using Do While Statement";
	cout << "\n\n";
	cout << "\tGive Two Numbers     : ";
	cin >> a >> b;
    cout <<"\n\n";
    
    max = (a < b) ? a : b;
    do {
    	if (max % a == 0 && max % b == 0) {
    		cout << "\tThe LCM is " << max;
    		break;
		}
		else {
			max++;
		} 
   } while(true);
	
	cout <<"\n\n";

    cout <<"\tThank you for Using This Software";
    cout <<"\n\n";
    cout << "\tEnd of Program";
    cout <<"\n\n"; 
}

