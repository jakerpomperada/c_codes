/*addition.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 23, 2018  Tuesday 9:53 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
int main()
{
	int a=0,b=0,sum=0;
    char reply;
   	do {
	system("cls");
	printf("\n\n");
	printf("\tAddition of Two Numbers");
	printf("\n\n");
    printf("\tGive Two Numbers     : ");
    scanf("%d%d",&a,&b);
	sum = (a+b);
	printf("\n\n");
	printf("\tThe sum of %d and %d is %d.",a,b,sum);
	printf("\n\n");
	printf("\tDo you want to continue? Y/N : ");
	reply = getch();
    } while (reply=='y' || reply=='Y');
    printf("\n\n");
    printf("\tThank you for Using This Software.");
    printf("\n\n");
    printf("\t\t End of Program");
    printf("\n\n");
}

