/*do_while.c
 Author   : Kristine Trogani Soberano,Ph.D.
 Faculty, Northern Negros State College of Science and Technology
 Address  : Brgy. Old Sagay, Sagay City, Negros Occidental, Philippines
 Email    : missKsoberano@gmail.com
 Tool     : Dev C++ Version 5.11
 Date     : November 23, 2018   Friday 10:13 AM
*/
#include <stdio.h>
int main()
{
    int num=0;
    int a=1;
    printf("\n\n");
	printf("\tDo While Loop Statement Demonstration");
    printf("\n\n");
	printf("\tGive a Number     : ");
	scanf("%d",&num);
	printf("\n\n");
    do {
	 	printf("%d ",a);
	 	a++;
	 } while (a<=num);
    printf("\n\n");
    printf("\t\t End of Program");
    printf("\n\n");
}

