/*multiply.c
 Author    : Mr. Jake R. Pomperada,BSCS,MAED-IT
 Date      : November 23, 2018  Tuesday 11:25 AM
 Location  : Bacolod City, Negros Occidental
 Website   : http://www.jakerpomperada.com
 Emails    : jakerpomperada@jakerpomperada.com
             jakerpomperada@gmail.com
             jakerpomperada@yahoo.com
             jakerpomperada@aol.com
*/
#include <stdio.h>
int main()
{
	int a=0,b=0;
	printf("\n\n");
	printf("\t   MULTIPLICATION TABLE IN C");
	printf("\n");
		for (a=1; a<=12; a++){
		printf("\n");
		for (b=1; b<=12; b++) {
			printf("%4d",a*b);
		
		}
	}
	printf("\n\n");
    printf("\tThank you for Using This Software.");
    printf("\n\n");
    printf("\t\t End of Program");
    printf("\n\n");
}

