#include <iostream>

using namespace std;

int main()
{
	int a = 1;
	cout << "\n\n";
	cout <<"\tContinue Statement Demonstration";
	cout << "\n\n";
	do {
		if (a==5) {
			a+=1;
			continue;
		}
		cout <<"\n";
		cout << "\tThe value of a: " << a << "\n";
		a+=1;
	} while (a <=10);
}
